package com.kooo.evcam.zeekr;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.SurfaceTexture;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;

import com.kooo.evcam.AppConfig;
import com.kooo.evcam.AppLog;
import com.kooo.evcam.CameraForegroundService;
import com.kooo.evcam.WakeUpHelper;
import com.kooo.evcam.blackbox.BlackBox;
import com.kooo.evcam.camera.CameraManagerHolder;
import com.kooo.evcam.camera.CameraNeeds;
import com.kooo.evcam.camera.MultiCameraManager;
import com.kooo.evcam.camera.SingleCamera;
import com.kooo.evcam.screen.ScreenState;
import com.kooo.evcam.telemetry.Readings;
import com.kooo.evcam.telemetry.Signal;
import com.kooo.evcam.telemetry.Telemetry;
import com.kooo.evcam.telemetry.VehicleState;

/**
 * 打转向灯弹侧视：听车辆信号，左灯弹左侧那一路、右灯弹右侧那一路，灯灭就收（可设再留几秒）；
 * 原厂画面优先。弹不弹的规则在 {@link SideViewDecision}。
 *
 * <h3>相机</h3>
 *
 * <p>和超级后视镜走同一条路（见 {@link RearViewMirrorService}）：窗口的 Surface 交给
 * {@code SingleCamera.setMainFloatingSurface()}，当一路附加输出。两者共用这一个槽位，
 * 所以<b>超级后视镜开着时不弹</b>。窗口挂着就登记 {@link CameraNeeds.Holder#SIDE_POPUP}，拿掉就注销。</p>
 *
 * <h3>即时弹出</h3>
 *
 * <p>每次从无到有挂窗口都要重建一次会话，画面比窗口晚到零点几秒（相机没开时更久）。
 * 「即时弹出」开着时，D 档下窗口一直挂着但完全透明，相机照推（见 {@link SideViewPopupView} 的三种状态），
 * 打灯只是把它拨亮。离开 D 档 {@link #READY_GRACE_MS} 后才拿掉，等红灯挂 N 不至于来回重建。</p>
 *
 * <h3>车辆信号</h3>
 *
 * <p>亮屏时向 {@link Telemetry} 登记，熄屏就注销、窗口拿掉：熄屏后车机六秒就深睡，不该留着监听和相机过去。</p>
 */
public class SideViewPopupService extends Service {

    private static final String TAG = "SideViewPopupSvc";
    private static final String TELEMETRY_USER = "side-popup";

    private static final long RETRY_DELAY_MS = 500L;
    private static final int MAX_RETRY = 20;
    /** 环视在恢复、录像在开时，过多久再试着接相机。 */
    private static final long WAIT_FOR_CAMERA_MS = 3_000L;
    /** 离开 D 档多久才把备着的窗口拿掉。 */
    static final long READY_GRACE_MS = 30_000L;
    /**
     * 多久没有新帧就不再当实时画面给人看。最慢的流也有 10fps，半秒是五帧没来：已经不是卡一下，是停了
     * （2.11.0 驾驶安全审查）。
     */
    static final long STALE_AFTER_MS = 500L;
    /** 显示时多久看一次帧还来不来。 */
    private static final long STALE_TICK_MS = 100L;

    private static volatile SideViewPopupService instance;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private AppConfig appConfig;
    private SideViewPopupView popup;
    /** 投到 HUD 的那一路：设置选了 HUD 或「两边」才有；和主屏弹窗各管各的相机槽位。 */
    private SideViewHudOutput hud;
    private SingleCamera boundCamera;
    /** 交给相机的是哪一个 SurfaceTexture：放手时确认槽位还是自己的。 */
    private SurfaceTexture boundTexture;
    private boolean listening;
    private int retryCount;
    private Runnable retryRunnable;
    /** 上一次判定时该不该备着。 */
    private boolean lastReady;
    /** 最近显示过哪一边：备着时窗口停在那一边，下次多半还是它。 */
    private int lastLane = LaneCycle.LEFT;
    /** 这一次显示的时刻和第一帧来没来：黑匣子里看「弹了多久才有画面」。 */
    private long shownAtMs;
    private boolean firstFrameSeen;
    /** 最近一帧新画面的时刻（单调时钟）；这个窗口还一帧都没有是 0。 */
    private long lastFrameMs;

    /** 显示着的时候每 {@link #STALE_TICK_MS} 看一次：帧停了就盖上，别把停住的那一帧当实时画面。 */
    private final Runnable staleTick = new Runnable() {
        @Override
        public void run() {
            if (popup == null || !popup.isShowing()) {
                return;
            }
            updateCover();
            handler.postDelayed(this, STALE_TICK_MS);
        }
    };

    /** 灯灭后再留几秒：到点收起。 */
    private final Runnable delayedClose = () -> {
        AppLog.i(TAG, "侧视收起：灯灭后多留的时间到了");
        closeNow();
    };
    private boolean closePending;
    /** 离开 D 档宽限期满：拿掉备着的窗口。 */
    private final Runnable readyExpired = () -> {
        readyExpiryArmed = false;
        if (!lastReady && popup != null && !popup.isShowing()) {
            AppLog.i(TAG, "侧视弹窗：离开 D 档，不再备着");
            detachPopup();
        }
    };

    /**
     * 「不再备着」的倒计时已经排上了。车辆信号每 200 ms 就推一次，以前每推一次都把 30 秒重新排一遍，
     * 在 P / N 挡里它几乎走不完 —— 看不见的窗口一直挂着、相机一直开着、前台服务也一直留着（审查 2026-10-08）。
     */
    private boolean readyExpiryArmed;

    private void armReadyExpiry(long delayMs) {
        if (readyExpiryArmed && delayMs > 0) {
            return;
        }
        handler.removeCallbacks(readyExpired);
        handler.postDelayed(readyExpired, delayMs);
        readyExpiryArmed = true;
    }

    private void disarmReadyExpiry() {
        handler.removeCallbacks(readyExpired);
        readyExpiryArmed = false;
    }

    public static void start(Context context) {
        context.startService(new Intent(context, SideViewPopupService.class));
    }

    public static void stop(Context context) {
        context.stopService(new Intent(context, SideViewPopupService.class));
    }

    /** 设置页改了侧视的任何一项：窗口套用新的大小位置拉直，再按新规则判一次。 */
    public static void applyConfig() {
        SideViewPopupService svc = instance;
        if (svc != null) {
            if (svc.popup != null) {
                svc.popup.applyConfig();
            }
            if (svc.hud != null) {
                svc.hud.applyConfig();
            }
            svc.evaluate();
        }
    }

    private final Telemetry.Listener readingsListener = readings -> evaluate();

    private final ScreenState.Listener screenListener = new ScreenState.Listener() {
        @Override
        public void onScreenOff() {
            stopListening();
        }

        @Override
        public void onScreenOn() {
            startListening();
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        appConfig = new AppConfig(this);
        instance = this;
        ScreenState.addListener(screenListener);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (com.kooo.evcam.UserExit.blocks(this, "SideViewPopupService")) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!appConfig.isSidePopupEnabled()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!WakeUpHelper.hasOverlayPermission(this)) {
            AppLog.e(TAG, "没有悬浮窗权限，侧视弹窗无法显示");
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!ScreenState.dark()) {
            startListening();
        }
        return CameraForegroundService.stickiness(this);
    }

    // ================================================================= 信号

    private void startListening() {
        if (listening) {
            return;
        }
        listening = true;
        Telemetry.get().acquire(this, TELEMETRY_USER);
        Telemetry.get().addListener(readingsListener);
        AppLog.i(TAG, "侧视弹窗：开始听转向灯");
        evaluate();
    }

    private void stopListening() {
        if (!listening) {
            return;
        }
        listening = false;
        Telemetry.get().removeListener(readingsListener);
        Telemetry.get().release(TELEMETRY_USER);
        lastReady = false;
        detachPopup();
        dropHud();
        AppLog.i(TAG, "侧视弹窗：停止听转向灯");
    }

    /** 主线程上：按最新的读数决定弹 / 收 / 换边 / 备着。 */
    private void evaluate() {
        if (!listening) {
            return;
        }
        Readings r = Telemetry.get().readings();
        VehicleState s = Telemetry.get().latest();
        int output = appConfig.getSideOutput();
        if (output == AppConfig.SIDE_OUTPUT_SCREEN) {
            dropHud();
        }
        boolean hudOn = output != AppConfig.SIDE_OUTPUT_SCREEN && !ScreenState.dark() && hudOutput().available();
        if (hudOn) {
            // HUD 不看车速门槛：低速也出，只有主屏弹窗才等车速。也不让原厂的 360、侧方小窗、泊车辅助：
            // 它们只在主屏上，而低速打灯原厂一弹，这三个信号同一毫秒一起变 1 —— 让了 HUD 低速就永远不出
            // （2.12.0 实车：30 以下不显示；2.12.1 只放开了小窗，360 和泊车辅助还在拦）。只让 R 档
            SideViewDecision.Input hudIn = inputFrom(r, s, 0, hud.showingLane());
            hudIn.yieldToScreenViews = false;
            hud.followIndicator(r.code(Signal.INDICATOR_DISPLAY));
            hud.setNight(Integer.valueOf(Signal.NIGHT).equals(r.code(Signal.DAY_NIGHT)));
            hudOn = hud.update(SideViewDecision.decide(hudIn), SideViewDecision.factoryViewActive(hudIn),
                    appConfig.isSidePopupInstant() && SideViewDecision.shouldStayReady(hudIn),
                    appConfig.getSidePopupCloseDelayMs());
        } else if (hud != null) {
            // 出不来（熄屏、找不到屏、开窗刚失败）：窗口收掉，对象留着 —— 开窗失败后的间隔记在它身上
            hud.detach();
        }
        // 只选了 HUD、而 HUD 此刻出不来（找不到屏、开窗失败）：主屏弹窗顶上
        boolean screenOn = output != AppConfig.SIDE_OUTPUT_HUD || !hudOn;

        SideViewDecision.Input in = inputFrom(r, s, appConfig.getSidePopupMinSpeed(),
                popup != null && popup.isShowing() ? popup.lane() : SideViewDecision.NONE);
        if (popup != null) {
            popup.setIndicatorLit(SideViewDecision.indicatorLit(r.code(Signal.INDICATOR_DISPLAY), popup.lane()));
        }

        boolean blocked = ScreenState.dark() || RearViewMirrorService.isRunning() || !screenOn;
        int want = blocked ? SideViewDecision.NONE : SideViewDecision.decide(in);
        lastReady = !blocked && appConfig.isSidePopupInstant() && SideViewDecision.shouldStayReady(in);

        if (want != SideViewDecision.NONE) {
            cancelDelayedClose();
            disarmReadyExpiry();
            if (want != in.showing) {
                AppLog.i(TAG, "转向灯：弹出「" + LaneCycle.labelOf(want) + "」路");
                BlackBox.note("侧视弹窗 弹出「" + LaneCycle.labelOf(want) + "」路："
                        + (popup == null ? "没有窗口" : "窗口此前在「" + LaneCycle.labelOf(popup.lane()) + "」路"
                        + (popup.isShowing() ? "，显示中" : "，备着")));
                showPopup(want);
            }
            return;
        }

        if (in.showing != SideViewDecision.NONE) {
            boolean factory = SideViewDecision.factoryViewActive(in);
            int delayMs = appConfig.getSidePopupCloseDelayMs();
            if (factory || blocked || delayMs <= 0) {
                AppLog.i(TAG, "侧视收起：" + (factory ? "原厂画面在" : blocked ? "超级后视镜开着、熄屏或只投 HUD" : "转向灯灭"));
                closeNow();
            } else if (!closePending) {
                closePending = true;
                handler.postDelayed(delayedClose, delayMs);
            }
            return;
        }

        // 没在显示：管「备着」
        if (lastReady) {
            disarmReadyExpiry();
            if (popup == null || !popup.isAttached()) {
                AppLog.i(TAG, "侧视弹窗：D 档，窗口备着");
                attachPopup(lastLane, false);
            }
        } else if (popup != null && popup.isAttached() && !closePending) {
            armReadyExpiry(blocked ? 0 : READY_GRACE_MS);
        }
    }

    private SideViewDecision.Input inputFrom(Readings r, VehicleState s, int minSpeedKmh, int showing) {
        SideViewDecision.Input in = new SideViewDecision.Input();
        in.turnSignal = s.turnSignal;
        in.hazard = s.hazard;
        in.gear = r.text(Signal.GEAR);
        in.stock360Shown = r.bool(Signal.STOCK_360);
        in.stockPopupShown = r.bool(Signal.STOCK_POPUP);
        in.parkAssistOn = r.bool(Signal.PARK_ASSIST);
        in.speedKmh = s.speedKmh;
        in.minSpeedKmh = minSpeedKmh;
        in.showing = showing;
        return in;
    }

    private SideViewHudOutput hudOutput() {
        if (hud == null) {
            hud = new SideViewHudOutput(this, appConfig);
        }
        return hud;
    }

    private void dropHud() {
        if (hud != null) {
            hud.detach();
            hud = null;
        }
    }

    // ================================================================= 窗口

    private void showPopup(int lane) {
        lastLane = lane;
        shownAtMs = SystemClock.uptimeMillis();
        firstFrameSeen = false;
        if (popup != null) {
            // 拨亮之前先定好盖不盖：备着时帧要是早就停了，拨亮的第一帧就不能是那张旧的
            popup.setCover(coverNow());
        }
        attachPopup(lane, true);
        updateCover();
        handler.removeCallbacks(staleTick);
        handler.postDelayed(staleTick, STALE_TICK_MS);
    }

    /**
     * 按帧来的时间该怎么盖：最近 {@link #STALE_AFTER_MS} 内来过新帧就不盖；没有的话，刚弹出那一小会儿只是黑着
     * （冷启动等第一帧是正常的，不必吓人），再久就写「没有实时画面」。
     */
    private int coverNow() {
        long now = SystemClock.uptimeMillis();
        if (lastFrameMs > 0 && now - lastFrameMs <= STALE_AFTER_MS) {
            return SideViewPopupView.COVER_NONE;
        }
        return now - shownAtMs < STALE_AFTER_MS
                ? SideViewPopupView.COVER_BLACK : SideViewPopupView.COVER_NO_PICTURE;
    }

    private void updateCover() {
        SideViewPopupView view = popup;
        if (view == null || !view.isShowing()) {
            return;
        }
        int cover = coverNow();
        if (cover == SideViewPopupView.COVER_NO_PICTURE && view.cover() != cover) {
            AppLog.w(TAG, "侧视弹窗：" + (lastFrameMs == 0 ? "一帧都还没来"
                    : (SystemClock.uptimeMillis() - lastFrameMs) + "ms 没有新帧") + "，盖上「没有实时画面」");
        }
        view.setCover(cover);
    }

    /** 收起：该备着就只拨暗（相机照推），不该就整个拿掉。 */
    private void closeNow() {
        cancelDelayedClose();
        if (popup == null || !popup.isShowing()) {
            return;
        }
        noteIfNoFrame();
        if (lastReady) {
            popup.conceal();
        } else {
            detachPopup();
        }
    }

    private void cancelDelayedClose() {
        if (closePending) {
            closePending = false;
            handler.removeCallbacks(delayedClose);
        }
    }

    private void attachPopup(int lane, boolean show) {
        if (popup != null && popup.isAttached()) {
            if (show) {
                popup.show(lane);
                rebindIfLost();
            } else {
                popup.attachHidden(lane);
            }
            return;
        }
        popup = new SideViewPopupView(this, appConfig);
        lastFrameMs = 0;   // 新窗口：上一个窗口的帧不算
        popup.getTextureView().setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
                bindCamera(st);
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
                restoreBufferSize(st);
            }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                // 只放自己这一块：旧窗口的画面晚一步销毁时，别把新窗口接上的相机摘掉
                if (st == boundTexture || boundTexture == null) {
                    unbindCamera();
                }
                return true;
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture st) {
                onFrame();
            }
        });
        if (show) {
            popup.show(lane);
        } else {
            popup.attachHidden(lane);
        }
    }

    private void detachPopup() {
        cancelDelayedClose();
        disarmReadyExpiry();
        cancelRetry();
        handler.removeCallbacks(staleTick);
        if (popup != null && popup.isShowing()) {
            noteIfNoFrame();
        }
        unbindCamera();
        if (popup != null) {
            popup.detach();
            popup = null;
        }
    }

    /** 显示过、到收起时一帧都没来：记下来，诊断报告里看得到。 */
    private void noteIfNoFrame() {
        if (firstFrameSeen) {
            return;
        }
        SingleCamera camera = boundCamera;
        BlackBox.note("侧视弹窗收起：显示了 " + (SystemClock.uptimeMillis() - shownAtMs) + "ms 一帧都没来；"
                + (camera == null ? "没接上相机" : "相机" + (camera.isCameraOpened() ? "开着" : "没开")
                + "，最近错误 " + camera.lastErrorName()));
    }

    /**
     * 每来一帧响一次。挂窗口时相机要是还没开过，那一刻它的预览尺寸是 null（开相机时才选），
     * 窗口就不知道该裁哪一块；帧来了说明相机已经开好，这时补上。
     */
    private void onFrame() {
        SideViewPopupView view = popup;
        SingleCamera camera = boundCamera;
        if (view == null) {
            return;
        }
        lastFrameMs = SystemClock.uptimeMillis();
        if (view.isShowing()) {
            view.setCover(SideViewPopupView.COVER_NONE);
        }
        if (!view.hasGeometry() && camera != null) {
            view.setSourceSize(camera.getPreviewSize());
            if (view.hasGeometry()) {
                AppLog.i(TAG, "侧视弹窗：相机开好后补上了预览尺寸 " + camera.getPreviewSize());
            }
        }
        if (view.isShowing() && !firstFrameSeen) {
            firstFrameSeen = true;
            BlackBox.note("侧视弹窗出画面：打灯后 " + (SystemClock.uptimeMillis() - shownAtMs) + "ms，几何"
                    + (view.hasGeometry() ? "已知" : "未知"));
        }
    }

    // ================================================================= 相机

    /**
     * 备着的窗口再弹出来时，看一眼它还接着相机没有：相机层可能把画面出口摘掉了（录像时会话配置失败、
     * 画面出口被丢弃后恢复），或者 bindCamera 重试到头放弃了 —— 那样之后每次打灯都是黑的，一整趟（审查 2026-10-08）。
     */
    private void rebindIfLost() {
        if (popup == null || popup.getTextureView() == null) {
            return;
        }
        SurfaceTexture st = popup.getTextureView().getSurfaceTexture();
        if (st == null) {
            return;   // 还没画出来：onSurfaceTextureAvailable 会去接
        }
        SingleCamera camera = boundCamera;
        boolean lost = camera == null || boundTexture != st
                || camera.getMainFloatingSurfaceTexture() != boundTexture;
        if (lost) {
            AppLog.i(TAG, "侧视弹窗：窗口的相机画面丢了，重新接");
            cancelRetry();
            retryCount = 0;
            bindCamera(st);
        }
    }

    private void bindCamera(SurfaceTexture surfaceTexture) {
        if (popup == null || !popup.isAttached() || surfaceTexture == null || ScreenState.dark()) {
            return;
        }
        MultiCameraManager manager = CameraManagerHolder.getInstance().getCameraManager();
        if (manager == null) {
            manager = CameraManagerHolder.getInstance().getOrInit(this);
        }
        SingleCamera camera = manager != null ? manager.getCamera("front") : null;
        if (camera == null) {
            scheduleRetry(surfaceTexture);
            return;
        }
        // 后台的相机只有前台服务在才给；录像不在时没人为侧视拉它，下面的 whenReady 只是排队等
        // （2026-10-08：不录像时侧视是空白的，开了录像才有画面）。要在下面「等一会儿再接」之前拉：
        // 那一条以前把这一步也跳过了，录像在等环视、环视在等前台服务，侧视跟着空白两分钟。放开时见 unbindCamera
        CameraForegroundService.ensureRunning(this, "side-popup");
        // 环视正在从连着出错里恢复、或者录像正在开：别在这时候再开相机、再重建会话（CAMCORDER 2026-10-07：
        // 实车卡死那两次，侧视弹窗在恢复中途又去开相机，每次都多一轮出错）。过一会儿再接
        if (camera.isRecovering() || com.kooo.evcam.recording.RecordingCoordinator.get(this).isAboutToStart()) {
            cancelRetry();
            retryRunnable = () -> bindCamera(surfaceTexture);
            handler.postDelayed(retryRunnable, WAIT_FOR_CAMERA_MS);
            return;
        }
        Size previewSize = camera.getPreviewSize();
        if (previewSize != null) {
            popup.setSourceSize(previewSize);
        }
        boundCamera = camera;
        boundTexture = surfaceTexture;
        restoreBufferSize(surfaceTexture);
        camera.setMainFloatingSurface(new Surface(surfaceTexture), surfaceTexture);
        boolean wasOpen = camera.isCameraOpened();
        if (wasOpen) {
            camera.recreateSession(false);
        } else {
            CameraForegroundService.whenReady(this, "side-popup-open", camera::openCamera);
        }
        retryCount = 0;
        CameraNeeds.current().claim(CameraNeeds.Holder.SIDE_POPUP);
        BlackBox.note("侧视弹窗接相机：「" + LaneCycle.labelOf(popup.lane()) + "」路，"
                + (popup.isShowing() ? "显示中" : "备着") + "，相机" + (wasOpen ? "已开" : "未开，现在开")
                + "，预览尺寸 " + previewSize + "，几何" + (popup.hasGeometry() ? "已知" : "未知（等第一帧补）"));
    }

    /** 窗口尺寸一变 TextureView 会改缓冲区尺寸，拨回会话用的那个（同后视镜）。 */
    private void restoreBufferSize(SurfaceTexture surfaceTexture) {
        if (surfaceTexture == null || boundCamera == null) {
            return;
        }
        Size buffer = boundCamera.getPreviewBufferSize();
        if (buffer != null && buffer.getWidth() > 0 && buffer.getHeight() > 0) {
            surfaceTexture.setDefaultBufferSize(buffer.getWidth(), buffer.getHeight());
        }
    }

    private void unbindCamera() {
        cancelRetry();
        CameraForegroundService.cancelWhenReady("side-popup-open");
        CameraNeeds.current().release(CameraNeeds.Holder.SIDE_POPUP);
        // 录像不用、保活没开，就让前台服务回去；录像在用就留着
        CameraForegroundService.releaseWhenIdle(this);
        if (boundCamera != null) {
            // 槽位要是已经被超级后视镜接走了，就别动它 —— 摘掉的会是后视镜的画面
            if (boundCamera.getMainFloatingSurfaceTexture() == boundTexture) {
                try {
                    boundCamera.setMainFloatingSurface(null, null);
                    boundCamera.recreateSession(false);
                } catch (Exception e) {
                    AppLog.w(TAG, "解绑相机失败: " + e);
                }
            }
            boundCamera = null;
            boundTexture = null;
        }
    }

    private void scheduleRetry(SurfaceTexture surfaceTexture) {
        if (retryCount >= MAX_RETRY) {
            AppLog.w(TAG, "相机始终不可用，侧视放弃绑定");
            return;
        }
        retryCount++;
        cancelRetry();
        retryRunnable = () -> bindCamera(surfaceTexture);
        handler.postDelayed(retryRunnable, RETRY_DELAY_MS);
    }

    private void cancelRetry() {
        if (retryRunnable != null) {
            handler.removeCallbacks(retryRunnable);
            retryRunnable = null;
        }
    }

    @Override
    public void onDestroy() {
        instance = null;
        ScreenState.removeListener(screenListener);
        stopListening();
        detachPopup();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
