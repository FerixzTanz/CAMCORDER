package com.kooo.evcam.zeekr;

/**
 * 打转向灯弹侧视：此刻该不该弹、弹哪一边。
 *
 * <h3>规则</h3>
 *
 * <ul>
 *   <li>左灯只弹左侧那一路，右灯只弹右侧那一路；双闪、不打灯、读不到都不弹。</li>
 *   <li><b>原厂画面优先</b>：挂 R 档、原厂 360 在显示、原厂画面弹着（360 或侧方小窗）、
 *       泊车辅助开着，任何一样成立都不弹；已经弹着的立刻收。
 *       HUD 那一路只让 R 档（{@link Input#yieldToScreenViews} 关）：原厂 360、侧方小窗、泊车辅助都只在主屏上，
 *       HUD 上没有东西和它们抢，而低速打灯原厂一弹，这三个信号<b>同一毫秒一起</b>变 1（2026-10-11 普查：
 *       26 km/h 右灯、10 km/h 左灯都是）—— 让的话 HUD 低速就永远不出（用户 2026-10-14 小窗、2026-10-15 360）。</li>
 *   <li>车速低于设定值不弹（默认 30 km/h：再慢原厂自己会弹侧方小窗）；车速读不到不拦。
 *       只在「还没弹」时看车速 —— 弹出来之后减速不收，免得在门槛上来回闪。</li>
 *   <li>灯一灭就收。</li>
 * </ul>
 *
 * <p>纯 Java，不碰 Android，见 {@code SideViewDecisionTest}。</p>
 */
public final class SideViewDecision {

    /** 不弹。 */
    public static final int NONE = -1;

    private SideViewDecision() {
    }

    /** 一份输入：信号读不到的都是 null。 */
    public static final class Input {
        /** {@code VehicleState.TURN_*}：0 不打、1 左、2 右；null 读不到。 */
        public Integer turnSignal;
        public Boolean hazard;
        public String gear;
        public Boolean stock360Shown;
        public Boolean stockPopupShown;
        public Boolean parkAssistOn;
        public Float speedKmh;
        /** 设置里的门槛，km/h；0 表示不看车速。 */
        public int minSpeedKmh;
        /** 此刻已经弹着的是哪一路（{@link LaneCycle#LEFT} / {@link LaneCycle#RIGHT}），没弹是 {@link #NONE}。 */
        public int showing = NONE;
        /**
         * 原厂只在主屏上的画面（360 {@link #stock360Shown}、侧方小窗 {@link #stockPopupShown}、
         * 泊车辅助 {@link #parkAssistOn}）弹着时让不让。主屏弹窗让（默认）：和它们在同一块屏上。
         * HUD 不让：它们不在 HUD 上。R 档照旧都让。
         */
        public boolean yieldToScreenViews = true;
    }

    /**
     * @return 该显示的那一路：{@link LaneCycle#LEFT} / {@link LaneCycle#RIGHT}，或 {@link #NONE}
     */
    public static int decide(Input in) {
        if (factoryViewActive(in)) {
            return NONE;
        }
        if (Boolean.TRUE.equals(in.hazard) || in.turnSignal == null) {
            return NONE;
        }
        int lane;
        if (in.turnSignal == 1) {
            lane = LaneCycle.LEFT;
        } else if (in.turnSignal == 2) {
            lane = LaneCycle.RIGHT;
        } else {
            return NONE;
        }
        if (in.showing == lane) {
            // 已经弹着同一边：不再看车速
            return lane;
        }
        if (in.minSpeedKmh > 0 && in.speedKmh != null && in.speedKmh < in.minSpeedKmh) {
            return NONE;
        }
        return lane;
    }

    /**
     * 「即时弹出」开着时，该不该把窗口备着（透明、相机照推）。
     *
     * <p>只看 D 档：开车时才会打灯变道，P / N / R 都不必为它开着相机。
     * 档位读不到就不备（退回打灯时再接相机，慢一点而已）。</p>
     */
    public static boolean shouldStayReady(Input in) {
        return "D".equals(in.gear);
    }

    /** 原厂有画面在屏幕上（或马上要有）：倒车；360、原厂弹窗、泊车辅助（{@link Input#yieldToScreenViews} 开时）。 */
    public static boolean factoryViewActive(Input in) {
        return "R".equals(in.gear)
                || (in.yieldToScreenViews && (Boolean.TRUE.equals(in.stock360Shown)
                        || Boolean.TRUE.equals(in.stockPopupShown)
                        || Boolean.TRUE.equals(in.parkAssistOn)));
    }

    /**
     * 窗口角上的箭头这一下亮不亮：转向指示显示跟着灯闪，左 0 / 1、右 0 / 2、双闪 0 / 3。
     * 读不到返回 null（箭头常亮）。
     */
    public static Boolean indicatorLit(Integer display, int lane) {
        if (display == null) {
            return null;
        }
        if (display == 3) {
            return true;
        }
        if (lane == LaneCycle.LEFT) {
            return display == 1;
        }
        if (lane == LaneCycle.RIGHT) {
            return display == 2;
        }
        return null;
    }
}
