package com.kooo.evcam.share;

import android.content.Context;

import com.kooo.evcam.AppLog;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.SecureRandom;
import java.util.Locale;

import fi.iki.elonen.NanoHTTPD;

/**
 * 把<b>一个</b>文件通过局域网发给手机。
 *
 * <h3>为什么是 HTTP + 二维码，而不是配套 App</h3>
 *
 * <p>手机上不用装任何东西：扫码 → 浏览器打开 → 长按保存。
 * 上游 EVCam 用的就是这条路（NanoHTTPD + ZXing），这里沿用。</p>
 *
 * <h3>一次只放一个文件</h3>
 *
 * <p>不做文件浏览器。分享的是「你正在看的这张照片 / 这一段录像」，
 * 把整块盘的目录暴露到局域网上是另一回事，风险也完全不同。</p>
 *
 * <h3>路径带一段随机串</h3>
 *
 * <p>同一个热点下可能不止一台设备。猜不到路径不等于安全，但至少不是
 * 「谁连上来都能顺手拿走」。服务本身也是<b>用完就关</b>的。</p>
 */
public class FileShareServer extends NanoHTTPD {

    private static final String TAG = "FileShareServer";

    /** 端口交给系统分配：写死一个端口迟早撞上别的服务。 */
    private static final int AUTO_PORT = 0;

    private static final SecureRandom RANDOM = new SecureRandom();

    private final Context context;
    private File file;
    private String token;
    private volatile Listener listener;

    /** 手机那边发生了什么：给对话框显示进度用。回调在服务的线程上，不是主线程。 */
    public enum Event {
        /** 手机打开了下载页（扫码成功、网是通的）。 */
        PAGE_OPENED,
        /** 开始传文件。 */
        DOWNLOAD_STARTED,
        /** 文件整份发完了。 */
        DOWNLOAD_DONE,
        /** 传到一半断了。 */
        DOWNLOAD_STOPPED,
        /** 有请求进来、像是这个链接，但随机串不对（链接没抄全、别的设备乱试）—— 至少说明网是通的。 */
        WRONG_LINK
    }

    public interface Listener {
        void onEvent(Event event, String remoteAddress);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    private void emit(Event event, String remote) {
        ShareLog.add(event + " from " + remote);
        AppLog.i(TAG, "share " + event + " from " + remote);
        Listener l = listener;
        if (l != null) {
            l.onEvent(event, remote);
        }
    }

    public FileShareServer(Context context) {
        super(AUTO_PORT);
        this.context = context.getApplicationContext();
        // 同时最多这么几个连接，多的直接关掉：默认一个连接一个线程、不封顶，
        // 同一个热点上有人狂开连接就能把线程、内存耗光，连带正在录的进程一起崩（安全审查 2026-10-08）
        setAsyncRunner(new BoundedRunner());
    }

    /** 同时最多几个连接（手机下载一个文件、再加几个预取，够了）。 */
    private static final int MAX_CLIENTS = 6;

    private static final class BoundedRunner implements AsyncRunner {
        private final java.util.List<ClientHandler> running =
                java.util.Collections.synchronizedList(new java.util.ArrayList<ClientHandler>());

        @Override
        public void closeAll() {
            for (ClientHandler handler : new java.util.ArrayList<>(running)) {
                handler.close();
            }
        }

        @Override
        public void closed(ClientHandler handler) {
            running.remove(handler);
        }

        @Override
        public void exec(ClientHandler handler) {
            if (running.size() >= MAX_CLIENTS) {
                handler.close();
                return;
            }
            running.add(handler);
            Thread thread = new Thread(handler, "share-client");
            thread.setDaemon(true);
            thread.start();
        }
    }

    /**
     * 换成分享这个文件。
     *
     * <p>每换一次都换一段新的随机串 —— 上一张照片的链接就此失效。</p>
     */
    public synchronized void share(File target) {
        this.file = target;
        this.token = randomToken();
    }

    public synchronized File sharedFile() {
        return file;
    }

    /**
     * 手机要访问的地址。
     *
     * @param host 从 {@link LocalNetwork} 里选出来的那个 IPv4 地址
     */
    public synchronized String urlFor(String host) {
        if (host == null || token == null) {
            return null;
        }
        return String.format(Locale.US, "http://%s:%d/s/%s", host, getListeningPort(), token);
    }

    private static String randomToken() {
        // 128 位（以前 48 位）：链接一直有效到分享结束，多几位不花什么（安全审查 2026-10-08）
        byte[] bytes = new byte[16];
        RANDOM.nextBytes(bytes);
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format(Locale.US, "%02x", b));
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ 请求

    @Override
    public Response serve(IHTTPSession session) {
        String uri = session.getUri() == null ? "" : session.getUri();
        String remote = session.getRemoteIpAddress();
        File shared;
        String expected;
        synchronized (this) {
            shared = file;
            expected = token;
        }
        if (shared == null || expected == null) {
            return text(Response.Status.NOT_FOUND, "没有正在分享的文件 / Nothing is being shared");
        }

        // HEAD 只问不拿：不算「开始 / 发完」。真实的类型和长度、空正文（不压缩，见 useGzipWhenAccepted）
        if (session.getMethod() == Method.HEAD) {
            if (uri.equals("/f/" + expected)) {
                return newFixedLengthResponse(Response.Status.OK, mimeTypeOf(shared.getName()),
                        new ByteArrayInputStream(new byte[0]), shared.length());
            }
            return newFixedLengthResponse(uri.equals("/s/" + expected) ? Response.Status.OK
                            : Response.Status.NOT_FOUND, "text/html; charset=utf-8",
                    new ByteArrayInputStream(new byte[0]), 0);
        }
        if (uri.equals("/s/" + expected)) {
            emit(Event.PAGE_OPENED, remote);
            return landingPage(shared, expected);
        }
        if (uri.equals("/f/" + expected)) {
            emit(Event.DOWNLOAD_STARTED, remote);
            return fileResponse(shared, remote);
        }
        // 浏览器自己会来要图标（favicon、iOS 的 apple-touch-icon），不算「链接不对」，只记一笔
        if (uri.startsWith("/s/") || uri.startsWith("/f/")) {
            emit(Event.WRONG_LINK, remote);
        } else {
            ShareLog.add("other request from " + remote);
        }
        // 路径不对就当没有这个东西，不提示「token 错了」——
        // 那等于告诉对方「猜对格式了，继续猜」
        return text(Response.Status.NOT_FOUND, "Not found");
    }

    private Response fileResponse(File shared, String remote) {
        try {
            InputStream body = new Watched(new FileInputStream(shared), shared.length(),
                    done -> emit(done ? Event.DOWNLOAD_DONE : Event.DOWNLOAD_STOPPED, remote));
            Response response = newFixedLengthResponse(Response.Status.OK,
                    mimeTypeOf(shared.getName()), body, shared.length());
            // 图片、视频用 inline：手机浏览器直接显示出来，用户长按就能存 ——
            // attachment 会变成一次下载，反而多一步。诊断报告这种文件正相反：
            // 显示出来是一屏看不懂的字，直接下载才对
            response.addHeader("Content-Disposition",
                    (isMedia(shared.getName()) ? "inline" : "attachment")
                            + "; filename=\"" + shared.getName() + "\"");
            return response;
        } catch (IOException e) {
            AppLog.e(TAG, "读不到要分享的文件", e);
            return text(Response.Status.INTERNAL_ERROR, "读取失败 / Cannot read file");
        }
    }

    /**
     * 不压缩：局域网上省不了多少，而 2.3.1 对 text/* 的 HEAD 回应会照样把压缩后的正文跟在后面，
     * 同一条连接上的下一个请求就读乱了（2026-10-11 实测）。
     */
    @Override
    protected boolean useGzipWhenAccepted(Response r) {
        return false;
    }

    /**
     * 数着读了多少字节的输入流：读满整份算发完，没读满就被关掉算断了。只报一次。
     * NanoHTTPD 发完（或者连接断了）都会关这个流。
     */
    static final class Watched extends FilterInputStream {
        interface End {
            void ended(boolean complete);
        }

        private final long length;
        private final End end;
        private long read;
        private boolean reported;

        Watched(InputStream in, long length, End end) {
            super(in);
            this.length = length;
            this.end = end;
        }

        @Override
        public int read() throws IOException {
            int b = super.read();
            if (b >= 0) {
                read++;
            }
            return b;
        }

        @Override
        public int read(byte[] buf, int off, int len) throws IOException {
            int n = super.read(buf, off, len);
            if (n > 0) {
                read += n;
            }
            return n;
        }

        @Override
        public void close() throws IOException {
            try {
                super.close();
            } finally {
                if (!reported) {
                    reported = true;
                    end.ended(read >= length);
                }
            }
        }
    }

    /** 一个极简页面：内容本身 + 怎么存。 */
    private Response landingPage(File shared, String tokenValue) {
        if (!isMedia(shared.getName())) {
            return downloadPage(shared, tokenValue);
        }
        boolean video = isVideo(shared.getName());
        String media = video
                ? "<video src=\"/f/" + tokenValue + "\" controls playsinline></video>"
                : "<img src=\"/f/" + tokenValue + "\" alt=\"\">";
        String howTo = video
                ? "长按视频 → 选择「保存视频」或「下载」<br>"
                  + "Long-press the video → Save video / Download"
                : "长按图片 → 选择「保存图片」或「下载」<br>"
                  + "Long-press the image → Save image / Download";

        String html = "<!doctype html><html lang=\"zh\"><head>"
                + "<meta charset=\"utf-8\">"
                + "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                + "<title>" + escape(shared.getName()) + "</title><style>"
                + "body{margin:0;padding:16px;background:#1a1a1a;color:#fff;"
                + "font-family:system-ui,-apple-system,sans-serif;text-align:center}"
                + "img,video{max-width:100%;height:auto;border-radius:8px;background:#000}"
                + ".name{margin:12px 0 4px;font-size:15px;word-break:break-all}"
                + ".size{color:#999;font-size:13px}"
                + ".tip{margin-top:20px;padding:14px;background:#2a2a2a;border-radius:8px;"
                + "font-size:14px;line-height:1.7;color:#ddd}"
                + "a{color:#4a90d9}"
                + "</style></head><body>"
                + media
                + "<div class=\"name\">" + escape(shared.getName()) + "</div>"
                + "<div class=\"size\">" + readableSize(shared.length()) + "</div>"
                + "<div class=\"tip\">" + howTo
                + "<br><br>存不下来时，点这里直接下载<br>If saving fails, download it here:<br>"
                + "<a href=\"/f/" + tokenValue + "\" download>" + escape(shared.getName()) + "</a>"
                + "</div></body></html>";
        return newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", html);
    }

    /** 不是图片、视频的文件（诊断报告）：页面上只有一个下载按钮。 */
    private Response downloadPage(File shared, String tokenValue) {
        String html = "<!doctype html><html lang=\"zh\"><head>"
                + "<meta charset=\"utf-8\">"
                + "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                + "<title>" + escape(shared.getName()) + "</title><style>"
                + "body{margin:0;padding:24px 16px;background:#1a1a1a;color:#fff;"
                + "font-family:system-ui,-apple-system,sans-serif;text-align:center}"
                + ".name{margin:12px 0 4px;font-size:15px;word-break:break-all}"
                + ".size{color:#999;font-size:13px}"
                + ".btn{display:inline-block;margin-top:24px;padding:16px 32px;background:#4a90d9;"
                + "color:#fff;border-radius:10px;font-size:17px;text-decoration:none}"
                + ".tip{margin-top:20px;font-size:14px;line-height:1.7;color:#ddd}"
                + "</style></head><body>"
                + "<div class=\"name\">" + escape(shared.getName()) + "</div>"
                + "<div class=\"size\">" + readableSize(shared.length()) + "</div>"
                + "<a class=\"btn\" href=\"/f/" + tokenValue + "\" download>下载 / Download</a>"
                + "<div class=\"tip\">点上面的按钮，文件就存到手机里了<br>"
                + "Tap the button to save the file to your phone</div>"
                + "</body></html>";
        return newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", html);
    }

    private Response text(Response.Status status, String body) {
        return newFixedLengthResponse(status, "text/plain; charset=utf-8", body);
    }

    // ------------------------------------------------------------------ 小工具

    /** 图片或视频：手机浏览器能直接显示、长按就能存的那种。 */
    static boolean isMedia(String name) {
        String lower = name == null ? "" : name.toLowerCase(Locale.US);
        return isVideo(name) || lower.endsWith(".png") || lower.endsWith(".jpg")
                || lower.endsWith(".jpeg");
    }

    static boolean isVideo(String name) {
        String lower = name == null ? "" : name.toLowerCase(Locale.US);
        return lower.endsWith(".mp4") || lower.endsWith(".mkv") || lower.endsWith(".webm");
    }

    static String mimeTypeOf(String name) {
        String lower = name == null ? "" : name.toLowerCase(Locale.US);
        if (lower.endsWith(".mp4")) {
            return "video/mp4";
        }
        if (lower.endsWith(".mkv")) {
            return "video/x-matroska";
        }
        if (lower.endsWith(".webm")) {
            return "video/webm";
        }
        if (lower.endsWith(".png")) {
            return "image/png";
        }
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) {
            return "image/jpeg";
        }
        if (lower.endsWith(".json")) {
            return "application/json; charset=utf-8";
        }
        if (lower.endsWith(".txt") || lower.endsWith(".log")) {
            return "text/plain; charset=utf-8";
        }
        return "application/octet-stream";
    }

    static String readableSize(long bytes) {
        if (bytes <= 0) {
            return "—";
        }
        if (bytes < 1024L * 1024L) {
            return String.format(Locale.US, "%.0f KB", bytes / 1024.0);
        }
        if (bytes < 1024L * 1024L * 1024L) {
            return String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
        }
        return String.format(Locale.US, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }

    static String escape(String raw) {
        if (raw == null) {
            return "";
        }
        return raw.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;");
    }
}
