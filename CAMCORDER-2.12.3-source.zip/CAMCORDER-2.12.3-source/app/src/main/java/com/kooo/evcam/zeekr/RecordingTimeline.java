package com.kooo.evcam.zeekr;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * 把一串分段录像拼成一条连续时间轴。
 *
 * <p>现在的回放是一堆文件挨个找、挨个放。行车记录仪的实际使用方式却是
 * 「我想看 20 分钟前那一段」—— 用户不关心它落在第几个文件里。
 * 这个类把连续录制的分段合并成一条虚拟时间轴，拖动进度条时可以跨文件定位。</p>
 *
 * <p>纯逻辑，不碰 Android API，可以直接跑 JVM 单元测试 —— 时间轴换算错了
 * 表现就是"拖到哪播到哪不对"，很难靠肉眼在车上发现，所以这部分必须能测。</p>
 */
public final class RecordingTimeline {

    /**
     * 相邻两段之间允许的最大空隙。
     *
     * <p>分段切换本身有零点几秒的写文件间隙，所以不能要求严丝合缝；
     * 但停止录制再重新开始会留下明显的断档，那属于两次不同的录制，
     * 不该接在同一条时间轴上。</p>
     */
    public static final long DEFAULT_MAX_GAP_MS = 5_000L;

    private RecordingTimeline() {
    }

    /** 时间轴上的一段，对应一个文件。 */
    public static final class Segment {
        /** 文件路径，播放时用。 */
        public final String path;
        /** 录制起始时刻（毫秒），来自文件名。 */
        public final long startEpochMs;
        /** 该段时长（毫秒）。 */
        public final long durationMs;
        /** 该段在所属时间轴上的起始偏移（毫秒）。 */
        public final long timelineOffsetMs;
        /** 该段的文件大小（字节）；未知时为 0。 */
        public final long sizeBytes;

        Segment(String path, long startEpochMs, long durationMs, long timelineOffsetMs,
                long sizeBytes) {
            this.path = path;
            this.startEpochMs = startEpochMs;
            this.durationMs = durationMs;
            this.timelineOffsetMs = timelineOffsetMs;
            this.sizeBytes = sizeBytes;
        }

        /** 该段在时间轴上的结束偏移（不含）。 */
        public long timelineEndMs() {
            return timelineOffsetMs + durationMs;
        }

        @Override
        public String toString() {
            return String.format(Locale.US, "Segment[%s +%dms len=%dms]",
                    path, timelineOffsetMs, durationMs);
        }
    }

    /** 一次连续录制：若干首尾相接的分段。 */
    public static final class Session {
        public final List<Segment> segments;
        /** 整条时间轴的总长度（毫秒）。 */
        public final long totalDurationMs;
        /** 第一段的起始时刻，用于给会话命名。 */
        public final long startEpochMs;
        /** 本条时间轴所有分段的文件大小之和（字节）。 */
        public final long totalSizeBytes;

        Session(List<Segment> segments, long totalDurationMs, long startEpochMs) {
            this.segments = Collections.unmodifiableList(segments);
            this.totalDurationMs = totalDurationMs;
            this.startEpochMs = startEpochMs;
            long bytes = 0L;
            for (Segment segment : segments) {
                bytes += segment.sizeBytes;
            }
            this.totalSizeBytes = bytes;
        }

        public int segmentCount() {
            return segments.size();
        }

        /** 最后一段结束的真实时刻。 */
        public long endEpochMs() {
            if (segments.isEmpty()) {
                return startEpochMs;
            }
            Segment last = segments.get(segments.size() - 1);
            return last.startEpochMs + last.durationMs;
        }

        /**
         * 时间轴上的位置 → 真实时刻。
         *
         * <p>座舱各路按真实时刻去对（见 {@link LaneTrack}），所以先换算过去。
         * 时间轴把段与段之间那零点几秒的空隙挤掉了，两者不是简单地差一个起点。</p>
         */
        public long epochAt(long positionMs) {
            Locator locator = locate(positionMs);
            if (locator == null) {
                return startEpochMs;
            }
            return locator.segment.startEpochMs + locator.offsetInSegmentMs;
        }

        /**
         * 真实时刻 → 时间轴上的位置，{@link #epochAt} 反过来。
         *
         * <p>落在两段之间的空隙里，算下一段的开头；早于第一段算 0，晚于最后一段算末尾。</p>
         */
        public long positionAt(long epochMs) {
            for (Segment seg : segments) {
                if (epochMs < seg.startEpochMs) {
                    return seg.timelineOffsetMs;
                }
                if (epochMs < seg.startEpochMs + seg.durationMs) {
                    return seg.timelineOffsetMs + (epochMs - seg.startEpochMs);
                }
            }
            return totalDurationMs;
        }

        /**
         * 把时间轴上的位置换算成「哪个文件 + 文件内偏移」。
         *
         * @param positionMs 时间轴位置，会被夹到 [0, totalDurationMs)
         * @return 定位结果；会话为空时返回 null
         */
        public Locator locate(long positionMs) {
            if (segments.isEmpty()) {
                return null;
            }
            long clamped = Math.max(0L, Math.min(positionMs, Math.max(0L, totalDurationMs - 1)));
            // 段数不多（一次录制通常几十段），线性扫描足够，且不易写错
            for (int i = 0; i < segments.size(); i++) {
                Segment seg = segments.get(i);
                if (clamped < seg.timelineEndMs()) {
                    return new Locator(i, seg, clamped - seg.timelineOffsetMs);
                }
            }
            Segment last = segments.get(segments.size() - 1);
            return new Locator(segments.size() - 1, last, Math.max(0L, last.durationMs - 1));
        }

        @Override
        public String toString() {
            return String.format(Locale.US, "Session[%d segments, %dms]",
                    segments.size(), totalDurationMs);
        }
    }

    /** {@link Session#locate} 的结果。 */
    public static final class Locator {
        public final int segmentIndex;
        public final Segment segment;
        /** 在该文件内部的偏移（毫秒）。 */
        public final long offsetInSegmentMs;

        Locator(int segmentIndex, Segment segment, long offsetInSegmentMs) {
            this.segmentIndex = segmentIndex;
            this.segment = segment;
            this.offsetInSegmentMs = offsetInSegmentMs;
        }

        @Override
        public String toString() {
            return String.format(Locale.US, "Locator[#%d %s +%dms]",
                    segmentIndex, segment.path, offsetInSegmentMs);
        }
    }

    /** 构建时间轴的输入：一个文件的路径、起始时刻与时长。 */
    public static final class Source {
        public final String path;
        public final long startEpochMs;
        public final long durationMs;

        /** 文件大小（字节）；未知时为 0。 */
        public final long sizeBytes;

        public Source(String path, long startEpochMs, long durationMs) {
            this(path, startEpochMs, durationMs, 0L);
        }

        public Source(String path, long startEpochMs, long durationMs, long sizeBytes) {
            this.path = path;
            this.startEpochMs = startEpochMs;
            this.durationMs = durationMs;
            this.sizeBytes = sizeBytes;
        }
    }

    /**
     * 把一批分段按时间排序，并切分成若干条连续时间轴。
     *
     * <p>相邻两段的空隙小于 {@code maxGapMs} 就算连续，接在同一条时间轴上；
     * 超过就另起一条 —— 那通常意味着中间停过录制。</p>
     *
     * @param sources  分段列表，顺序不限
     * @param maxGapMs 允许的最大空隙；传 &lt;= 0 用 {@link #DEFAULT_MAX_GAP_MS}
     * @return 按时间先后排列的会话；输入为空时返回空列表
     */
    public static List<Session> build(List<Source> sources, long maxGapMs) {
        final long gapLimit = maxGapMs > 0 ? maxGapMs : DEFAULT_MAX_GAP_MS;
        return build(sources, (previousEndEpochMs, nextStartEpochMs) ->
                nextStartEpochMs - previousEndEpochMs <= gapLimit);
    }

    /** 前一段结束、后一段开始：两段接不接在同一条时间轴上。 */
    public interface Joiner {
        boolean joins(long previousEndEpochMs, long nextStartEpochMs);
    }

    /**
     * 同 {@link #build(List, long)}，接不接由 {@code joiner} 定（按行车日志分趟，见 {@link DriveGrouping}）。
     * 中间的空隙不占时间轴：跳过去接着放。
     */
    public static List<Session> build(List<Source> sources, Joiner joiner) {
        List<Session> sessions = new ArrayList<>();
        if (sources == null || sources.isEmpty()) {
            return sessions;
        }

        List<Source> sorted = new ArrayList<>(sources);
        Collections.sort(sorted, new Comparator<Source>() {
            @Override
            public int compare(Source a, Source b) {
                return Long.compare(a.startEpochMs, b.startEpochMs);
            }
        });

        List<Segment> current = new ArrayList<>();
        long offset = 0L;
        long sessionStart = 0L;
        long previousEndEpoch = 0L;

        for (Source src : sorted) {
            if (src == null || src.durationMs <= 0) {
                continue;  // 时长读不出来的文件跳过，宁可少一段也不要把时间轴算错
            }
            boolean startsNewSession = current.isEmpty()
                    || !joiner.joins(previousEndEpoch, src.startEpochMs);

            if (startsNewSession && !current.isEmpty()) {
                sessions.add(new Session(current, offset, sessionStart));
                current = new ArrayList<>();
                offset = 0L;
            }
            if (current.isEmpty()) {
                sessionStart = src.startEpochMs;
            }

            current.add(new Segment(src.path, src.startEpochMs, src.durationMs, offset,
                    src.sizeBytes));
            offset += src.durationMs;
            previousEndEpoch = src.startEpochMs + src.durationMs;
        }

        if (!current.isEmpty()) {
            sessions.add(new Session(current, offset, sessionStart));
        }
        return sessions;
    }

    /** @see #build(List, long) */
    public static List<Session> build(List<Source> sources) {
        return build(sources, DEFAULT_MAX_GAP_MS);
    }

    /**
     * 录像文件名里的摄像头槽位。
     *
     * <p>文件名形如 {@code 20260829_100000_front.mp4}，最后一段下划线之后就是槽位名
     * （front / back / left / right）。</p>
     *
     * @return 槽位名；解析不出来返回 null
     */
    public static String parseCameraSlot(String fileName) {
        if (fileName == null) {
            return null;
        }
        int dot = fileName.lastIndexOf('.');
        if (dot <= 0) {
            return null;
        }
        String stem = fileName.substring(0, dot);
        int underscore = stem.lastIndexOf('_');
        if (underscore < 0 || underscore == stem.length() - 1) {
            return null;
        }
        return stem.substring(underscore + 1);
    }

    /**
     * 这个文件是不是指定槽位的录像。
     *
     * <p>连续回放只看环视那一路。三路录制时同一分段会写出三个文件，
     * 它们的时间戳前缀完全相同 —— 全都收进来的话，会被当成时间上前后相接的三段，
     * 于是环视和座舱画面被接在同一条时间轴上。</p>
     */
    public static boolean isSlot(String fileName, String slot) {
        String parsed = parseCameraSlot(fileName);
        if (parsed == null || slot == null) {
            return false;
        }
        // 两边都归一：改名之前录的 _front 和现在的 _surround 是同一路
        return com.kooo.evcam.camera.CameraSlots.canonical(parsed.toLowerCase(Locale.US))
                .equals(com.kooo.evcam.camera.CameraSlots.canonical(slot.toLowerCase(Locale.US)));
    }

    /**
     * 从 {@code yyyyMMdd_HHmmss} 开头的文件名里解析起始时刻。
     *
     * <p>录制文件名形如 {@code 20260828_221530_front.mp4}。</p>
     *
     * @return 毫秒时间戳；解析不出来返回 -1
     */
    public static long parseStartEpochMs(String fileName) {
        if (fileName == null || fileName.length() < 15) {
            return -1L;
        }
        String stamp = fileName.substring(0, 15);
        if (stamp.charAt(8) != '_') {
            return -1L;
        }
        try {
            int year = Integer.parseInt(stamp.substring(0, 4));
            int month = Integer.parseInt(stamp.substring(4, 6));
            int day = Integer.parseInt(stamp.substring(6, 8));
            int hour = Integer.parseInt(stamp.substring(9, 11));
            int minute = Integer.parseInt(stamp.substring(11, 13));
            int second = Integer.parseInt(stamp.substring(13, 15));
            if (month < 1 || month > 12 || day < 1 || day > 31
                    || hour > 23 || minute > 59 || second > 59) {
                return -1L;
            }
            java.util.Calendar cal = java.util.Calendar.getInstance();
            cal.clear();
            cal.set(year, month - 1, day, hour, minute, second);
            return cal.getTimeInMillis();
        } catch (NumberFormatException e) {
            return -1L;
        }
    }
}
