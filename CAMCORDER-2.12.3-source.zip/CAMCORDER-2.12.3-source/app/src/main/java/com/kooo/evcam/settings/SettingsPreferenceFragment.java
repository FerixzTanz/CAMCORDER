package com.kooo.evcam.settings;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import com.kooo.evcam.profile.ProfileMigration;
import com.kooo.evcam.profile.ProfileStore;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import androidx.annotation.Nullable;
import androidx.preference.EditTextPreference;
import androidx.preference.ListPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.SeekBarPreference;
import androidx.preference.SwitchPreferenceCompat;
import androidx.appcompat.app.AlertDialog;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import com.kooo.evcam.AppConfig;
import com.kooo.evcam.AppLog;
import com.kooo.evcam.MainActivity;
import com.kooo.evcam.R;
import com.kooo.evcam.StorageHelper;
import com.kooo.evcam.WakeUpHelper;
import com.kooo.evcam.overlay.OverlayCoordinator;
import com.kooo.evcam.overlay.FloatingAction;
import com.kooo.evcam.service.RecordingFloatingService;
import com.kooo.evcam.zeekr.DiagnosticsActivity;
import com.kooo.evcam.zeekr.RearViewMirrorService;

/**
 * 设置界面。
 *
 * <h3>为什么换成 PreferenceScreen</h3>
 *
 * <p>之前是一千九百多行手写的 LinearLayout 卡片，加上两千八百行的接线代码。
 * 每加一个设置都要重复写一遍「卡片 + 标题 + 说明 + 控件 + 找 id + 读值 + 写值 +
 * 联动显隐」，而分类、摘要、启用依赖这些框架本来就提供。</p>
 *
 * <p>其中<b>启用依赖</b>尤其值得换：以前「息屏录制要先开启动自动录制」这类关系
 * 是手写显隐逻辑维持的，写漏一处就会出现「开关能点但不生效」。
 * 现在用 {@code android:dependency} 声明，框架负责置灰。</p>
 *
 * <h3>取值一律走 AppConfig</h3>
 *
 * <p>所有 Preference 都 {@code setPersistent(false)} —— 它们<b>不自己往
 * SharedPreferences 里写</b>，读写全部经过 {@link AppConfig}。</p>
 *
 * <p>这一点是刻意的。AppConfig 的 getter/setter 里带着夹取、默认值和联动，
 * 而且它是这些设置在整个应用里唯一的读取入口。如果让 Preference 自己持久化，
 * 就多了一条写入路径，key 稍有出入就会变成「设置看着改了、实际没生效」——
 * 这个项目在这类问题上已经栽过好几次。所以 XML 里的 key 只是标识符，不是存储键。</p>
 */
public class SettingsPreferenceFragment extends PreferenceFragmentCompat {

    private static final String TAG = "SettingsPreference";

    private AppConfig appConfig;
    /** 绑定这一页时开发者选项开没开；回到这一页时变了就重绑（见 {@link #onResume}）。 */
    private boolean boundUnlocked;
    /** 外置卷的取值前缀，后面接它在探测结果里的下标。 */
    private static final String EXTERNAL_PREFIX = "external:";
    /**
     * 设置里选的是 U 盘、眼下却一个都没探测到时那一项的取值。故意不带 {@link #EXTERNAL_PREFIX}：
     * 它后面没有下标，不能当成某个卷去解析；选它什么都不改。
     */
    private static final String EXTERNAL_MISSING = "external-missing";
    private List<StorageHelper.VolumeInfo> storageVolumes;

    private static final String ARG_SECTION = "section";

    /**
     * 只显示某一个分区。
     *
     * <p>分区在 {@code preferences.xml} 里是嵌套的 PreferenceScreen，
     * {@code setPreferencesFromResource} 的 rootKey 参数就是按 key 取子树用的 ——
     * 所以不需要把 XML 拆成八个文件。</p>
     */
    public static SettingsPreferenceFragment forSection(String screenKey) {
        SettingsPreferenceFragment fragment = new SettingsPreferenceFragment();
        Bundle args = new Bundle();
        args.putString(ARG_SECTION, screenKey);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreatePreferences(@Nullable Bundle savedInstanceState, @Nullable String rootKey) {
        String section = rootKey;
        if (section == null && getArguments() != null) {
            section = getArguments().getString(ARG_SECTION);
        }
        setPreferencesFromResource(R.xml.preferences, section);
        if (getContext() == null) {
            return;
        }
        appConfig = new AppConfig(getContext());
        boundUnlocked = DeveloperMode.isUnlocked();

        bindRecording();
        bindStorage();
        bindRearView();
        bindSidePopup();
        bindFloating();
        bindInterface();
        bindSystem();
        // 开发者选项分区：没开时不接线。左栏已经把整块拿掉了；万一是直接跳进来的，点了也不起作用 ——
        // 里面的设置这时本来就按没存过算（AppConfig.DEVELOPER_KEYS）
        if (boundUnlocked) {
            bindAdvanced();
            bindDeveloper();
        }
        bindUpdate();

        linkSubPages();

        // 行样式在交给列表之前套上（车机系统式：卡片行、开关在前、值在后）
        PreferenceRows.apply(getPreferenceScreen());
    }

    /**
     * 子页面那一行跟着本页的总开关置灰（2.11.0）。不写在 XML 里：子页面单独打开时它自己是根，
     * 总开关不在它那棵树里，XML 里的 dependency 会在加载时找不到而崩。
     */
    private void linkSubPages() {
        String[][] pairs = {
                {"sub_rearview_view", "pref_rearview"},
                {"sub_side_picture", "pref_side_popup"},
                {"sub_floating_look", "pref_recording_floating"},
        };
        for (String[] pair : pairs) {
            Preference sub = findPreference(pair[0]);
            if (sub != null && sub != getPreferenceScreen() && findPreference(pair[1]) != null) {
                sub.setDependency(pair[1]);
            }
        }
    }

    /**
     * 点了本页里的子页面（嵌套的 PreferenceScreen）：在右栏往下开一层，标题是它的名字，返回键回到本页（2.11.0）。
     */
    @Override
    public void onNavigateToScreen(androidx.preference.PreferenceScreen screen) {
        if (screen == null || screen.getKey() == null) {
            return;
        }
        androidx.fragment.app.Fragment next = forSection(screen.getKey());
        CharSequence title = screen.getTitle();
        if (getParentFragment() instanceof SettingsShellFragment) {
            ((SettingsShellFragment) getParentFragment()).openDetail(next, title);
            return;
        }
        if (getActivity() != null) {
            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, next, next.getClass().getName())
                    .addToBackStack(null)
                    .commit();
        }
    }

    @Override
    public void onViewCreated(@androidx.annotation.NonNull android.view.View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        PreferenceRows.styleList(this, 28, 16);
    }

    @Override
    public void onResume() {
        super.onResume();
        // 停在开发者选项这一页时把它关了（「关于与致谢」里关的）：这一页不能再留着，换回默认分区
        if (!DeveloperMode.isUnlocked() && getArguments() != null
                && SettingsShellFragment.DEVELOPER_SECTION.equals(getArguments().getString(ARG_SECTION))
                && getParentFragment() instanceof SettingsShellFragment) {
            ((SettingsShellFragment) getParentFragment()).showSection(SettingsShellFragment.DEFAULT_SECTION);
            return;
        }
        // 开发者选项在「关于与致谢」（另一个 Activity）里开关：回来时变了就按新的状态整页重绑 ——
        // 中转写入能不能开、内置存储那一项怎么写、开发者分区接不接线都跟着它
        if (appConfig != null && boundUnlocked != DeveloperMode.isUnlocked()) {
            onCreatePreferences(null, null);
            return;
        }
        // 权限、存储用量这些可能在别处被改过，回到这个界面时重新读一次
        updateStorageUsage();
        refreshRearViewSize();
    }

    // ------------------------------------------------------------------ 录制

    private void bindRecording() {
        bindCarModel();

        // 相机与视频流的参数（每一路的三条流、每一格的摆法）都在下面这个
        // 「编辑视频流配置」里。同一件事只留一个入口：两个入口意味着
        // 迟早会出现「这边写着 30、那边写着 15」。
        onClick("pref_profile_editor",
                pref -> openFragment(new ProfileEditorFragment(), R.string.set_profile_editor_title));

        bindSwitch("pref_auto_record", appConfig.isAutoStartRecording(),
                value -> appConfig.setAutoStartRecording(value));
        bindSwitch("pref_drive_auto_start", appConfig.isDriveAutoStart(), value -> {
            appConfig.setDriveAutoStart(value);
            com.kooo.evcam.recording.DriveSessionWatcher.get(requireContext()).apply();
        });
        bindSwitch("pref_drive_auto_stop", appConfig.isDriveAutoStop(), value -> {
            appConfig.setDriveAutoStop(value);
            com.kooo.evcam.recording.DriveSessionWatcher.get(requireContext()).apply();
        });
        // 停车省空间：录着的时候改也立刻生效（MultiCameraManager 每半秒看一次）
        bindSwitch("pref_still_save", appConfig.isStillSaveEnabled(), appConfig::setStillSaveEnabled);
        // 回放下次打开时按新的分
        bindSwitch("pref_group_by_drive", appConfig.isGroupByDriveEnabled(), appConfig::setGroupByDriveEnabled);

        bindSwitch("pref_photo_via_jpeg", appConfig.isPhotoViaJpegEnabled(),
                enabled -> {
                    appConfig.setPhotoViaJpegEnabled(enabled);
                    toast(getString(R.string.msg_restart_required));
                });


        bindSwitch("pref_license_plate_enabled", appConfig.isLicensePlateEnabled(),
                enabled -> {
                    appConfig.setLicensePlateEnabled(enabled);
                    showLicensePlate();
                });
        bindLicensePlate();

        // 应用名与版本（填了车牌号跟在后面）每一路 MediaCodec 录像、每一张照片都盖，和「时间水印」开不开无关
        // （录像见 EglSurfaceEncoder.drawBrandOverlay，照片见 SingleCamera.addWatermark；
        // 开发者选项里的 MediaRecorder 模式什么角标都画不了），
        // 这里只是把这件事摆在界面上：开着、灰着、点不动。
        // 给一个能关的开关，等于承诺一件代码里并不打算允许的事。
        SwitchPreferenceCompat brand = findPreference("pref_watermark_brand");
        if (brand != null) {
            brand.setPersistent(false);
            brand.setChecked(true);
            brand.setEnabled(false);
        }

        bindSwitch("pref_watermark", appConfig.isTimestampWatermarkEnabled(),
                value -> appConfig.setTimestampWatermarkEnabled(value));

        bindSwitch("pref_watermark_spec", appConfig.isWatermarkSpecEnabled(),
                value -> appConfig.setWatermarkSpecEnabled(value));

        // 行驶信息条（试验项目）：经纬度和 GPS 车速要定位权限，已经有了（比如车机预先授予）才用，
        // 不弹权限框（项目所有者 2026-10-06）；没有就不显示，见 LocationSource
        bindSwitch("pref_info_bar", appConfig.isInfoBarEnabled(),
                value -> appConfig.setInfoBarEnabled(value));
    }

    /**
     * 视频流配置。
     *
     * <p>「极氪7X（环视 + 前后座舱）」0.48 起对所有人开放：座舱那两路的旋转、镜像、
     * 画面适配都做完并在车上验证过了，它不再是半成品。</p>
     *
     * <p>「自定义」仍然只在开发者选项里 —— 那一档要手动指定每一路接哪个相机，
     * 用途是排查，不是日常使用。半成品混在正常选项里，选中之后出问题会让人
     * 以为是应用坏了。</p>
     *
     * <p><b>当前值一定保留</b>：万一已经停在某个隐藏选项上，把它从列表里抹掉
     * 会让下拉框显示空白，那才是真的没法收拾。</p>
     */
    private void bindCarModel() {
        ListPreference pref = findPreference("pref_car_model");
        if (pref == null) {
            return;
        }
        String current = SettingsRegistry.CAR_MODEL.sanitize(appConfig.getCarModel());
        String[] allValues = SettingsRegistry.CAR_MODEL.values();
        String[] allNames = localizedNames(SettingsRegistry.CAR_MODEL);

        pref.setPersistent(false);
        pref.setEntries(allNames);
        pref.setEntryValues(allValues);
        pref.setValue(current);
        pref.setSummary(pref.getEntry());
        pref.setOnPreferenceChangeListener((preference, newValue) -> {
            String value = String.valueOf(newValue);
            appConfig.setCarModel(value);
            // 「切换视频流配置」现在的含义就是「切换到另一份配置」——
            // 车型这个字段留着只是为了第一次翻译时有个输入。
            new ProfileStore(requireContext())
                    .select(ProfileMigration.presetIdFor(value));
            pref.setValue(value);
            pref.setSummary(pref.getEntry());
            toast(getString(R.string.msg_stream_changed, pref.getEntry()));
            return false;
        });
    }

    // ------------------------------------------------------------------ 存储

    private void bindStorage() {
        bindStorageLocation();

        // 中转写入是「先写内置再搬走」，本质上就是往内置存储规律性地写，
        // 所以和内置存储同一个门槛：开发者选项关着时置灰，值也按关算（AppConfig 那道门），写着关就是关
        SwitchPreferenceCompat relay = findPreference("pref_relay_write");
        if (relay != null) {
            relay.setPersistent(false);
            relay.setChecked(appConfig.isRelayWriteEnabled());
            if (!StorageHelper.isInternalStorageAllowed()) {
                relay.setEnabled(false);
                relay.setSummary(getString(R.string.msg_relay_dev_only));
            }
            relay.setOnPreferenceChangeListener((preference, newValue) -> {
                appConfig.setRelayWriteEnabled(Boolean.TRUE.equals(newValue));
                return true;
            });
        }

        bindGigabyteLimit("pref_video_limit", appConfig.getVideoStorageLimitGb(),
                value -> appConfig.setVideoStorageLimitGb(value));
        bindGigabyteLimit("pref_photo_limit", appConfig.getPhotoStorageLimitGb(),
                value -> appConfig.setPhotoStorageLimitGb(value));

        bindFootageLock();
        bindAutoLock();
        updateStorageUsage();
    }

    /**
     * 锁定影像下面的两个自动锁定（项目所有者 2026-10-04），默认关：自动锁的也占空间，锁满了就停录。
     * 「锁定影像」关着时闪远光那一项置灰、不起作用（XML 里的 dependency；{@code AutoLock.flashEnabled} 也看它）。
     * 急刹车那一项（2.10.8，默认开）同样跟着「锁定影像」置灰；原来的鸣笛那一项拿掉了（车上读不到喇叭信号）。
     */
    private void bindAutoLock() {
        bindSwitch("pref_footage_lock_flash", appConfig.isFlashLockEnabled(), value -> {
            appConfig.setFlashLockEnabled(value);
            com.kooo.evcam.storage.AutoLock.get().settingsChanged(getContext());
        });
        bindSwitch("pref_footage_lock_brake", appConfig.isBrakeLockEnabled(), value -> {
            appConfig.setBrakeLockEnabled(value);
            com.kooo.evcam.storage.AutoLock.get().settingsChanged(getContext());
        });
    }

    /**
     * 锁定影像。打开直接生效；关掉时如果锁着东西，先说清楚代价（项目所有者 2026-10-03）：
     * 关掉后它们不再受保护，空间不够时和别的录像一样从旧到新删，删掉的找不回来。
     */
    private void bindFootageLock() {
        SwitchPreferenceCompat pref = findPreference("pref_footage_lock");
        if (pref == null) {
            return;
        }
        pref.setPersistent(false);
        pref.setChecked(appConfig.isFootageLockEnabled());
        pref.setOnPreferenceChangeListener((preference, newValue) -> {
            if (Boolean.TRUE.equals(newValue)) {
                applyFootageLock(pref, true);
                return true;
            }
            // 先不拨：量完锁了多少再决定要不要问
            final Context context = getContext() != null ? getContext().getApplicationContext() : null;
            if (context == null) {
                return false;
            }
            new Thread(() -> {
                com.kooo.evcam.storage.FootageLocks.Usage videos =
                        com.kooo.evcam.storage.FootageLocks.usage(StorageHelper.getVideoDir(context));
                com.kooo.evcam.storage.FootageLocks.Usage photos =
                        com.kooo.evcam.storage.FootageLocks.usage(StorageHelper.getPhotoDir(context));
                if (!isAdded()) {
                    return;
                }
                requireActivity().runOnUiThread(() -> confirmFootageLockOff(pref,
                        videos.files + photos.files, videos.bytes + photos.bytes));
            }, "footage-lock-off").start();
            return false;
        });
        updateFootageLocked();
    }

    private void confirmFootageLockOff(SwitchPreferenceCompat pref, int files, long bytes) {
        if (files == 0 || getContext() == null) {
            applyFootageLock(pref, false);
            return;
        }
        com.kooo.evcam.ui.CamDialogs.showDestructive(new MaterialAlertDialogBuilder(getContext(), R.style.Theme_Cam_MaterialAlertDialog)
                .setTitle(R.string.dlg_footage_lock_off_title)
                .setMessage(getResources().getQuantityString(R.plurals.dlg_footage_lock_off_msg,
                        files, files, StorageHelper.formatSize(bytes)))
                .setPositiveButton(R.string.dlg_footage_lock_off_ok, (dialog, which) -> applyFootageLock(pref, false))
                .setNegativeButton(R.string.action_cancel, null));
    }

    private void applyFootageLock(SwitchPreferenceCompat pref, boolean on) {
        appConfig.setFootageLockEnabled(on);
        pref.setChecked(on);
        com.kooo.evcam.blackbox.BlackBox.noteImportant("开关变更: pref_footage_lock → " + (on ? "开" : "关"));
        // 闪远光自动锁定跟着它：正在录的话马上开始 / 不再看信号
        com.kooo.evcam.storage.AutoLock.get().settingsChanged(getContext());
        updateFootageLocked();
    }

    /** 「已锁定」那一行：录像几个文件多大、照片几张多大；开关关着时注明不受保护。 */
    private void updateFootageLocked() {
        Preference pref = findPreference("pref_footage_locked");
        if (pref == null || getContext() == null) {
            return;
        }
        pref.setSummary(getString(R.string.info_reading));
        final Context context = getContext().getApplicationContext();
        final boolean on = appConfig.isFootageLockEnabled();
        new Thread(() -> {
            com.kooo.evcam.storage.FootageLocks.Usage videos =
                    com.kooo.evcam.storage.FootageLocks.usage(StorageHelper.getVideoDir(context));
            com.kooo.evcam.storage.FootageLocks.Usage photos =
                    com.kooo.evcam.storage.FootageLocks.usage(StorageHelper.getPhotoDir(context));
            if (!isAdded()) {
                return;
            }
            String text = videos.files + photos.files == 0
                    ? getString(R.string.set_footage_locked_none)
                    : getString(R.string.set_footage_locked_summary,
                            videos.files, StorageHelper.formatSize(videos.bytes),
                            photos.files, StorageHelper.formatSize(photos.bytes));
            final String result = on || videos.files + photos.files == 0 ? text
                    : getString(R.string.set_footage_locked_unprotected, text);
            requireActivity().runOnUiThread(() -> pref.setSummary(result));
        }, "footage-locked").start();
    }

    /**
     * 换成内置存储之前先把代价说清楚。
     *
     * <p>行车记录是<b>一直在写</b>的，而闪存的写入寿命有限，车机存储通常也换不了。
     * 所以必须明确确认才生效，取消则把下拉框拨回原来那一项。</p>
     */
    private void confirmInternalStorage(ListPreference pref) {
        if (getContext() == null) {
            return;
        }
        // 主题显式传：Material 对话框 + 这个主题，是实车上唯一显示得出按钮的组合
        com.kooo.evcam.ui.CamDialogs.show(new MaterialAlertDialogBuilder(getContext(), R.style.Theme_Cam_MaterialAlertDialog)
                .setTitle(R.string.dlg_internal_title)
                .setMessage(R.string.dlg_internal_msg)
                .setPositiveButton(R.string.dlg_internal_ok, (dialog, which) ->
                        applyStorageLocation(pref, AppConfig.STORAGE_INTERNAL))
                .setNegativeButton(R.string.action_cancel, null));
    }

    /**
     * 存储位置：把<b>实际存在的卷</b>逐个列出来。
     *
     * <p>以前只有「U盘 / 内置」两项，插两个盘时没法指定是哪一个。
     * 这里按 {@link com.kooo.evcam.StorageHelper#listExternalVolumes} 的结果生成选项，
     * 每一项带上卷名和剩余/总容量 —— 要选到正确的那个盘，得先看得出它们的区别。</p>
     *
     * <p>选中某个外置卷时会把它的根目录钉到 {@code customSdCardPath}，
     * 否则检测逻辑永远落到第一个盘上。</p>
     */
    private void bindStorageLocation() {
        ListPreference pref = findPreference("pref_storage_location");
        if (pref == null || getContext() == null) {
            return;
        }
        pref.setPersistent(false);
        pref.setSummary(getString(R.string.info_checking_storage));

        final Context context = getContext().getApplicationContext();
        new Thread(() -> {
            final List<StorageHelper.VolumeInfo> volumes =
                    StorageHelper.listExternalVolumes(context);
            if (!isAdded()) {
                return;
            }
            requireActivity().runOnUiThread(() -> populateStorageLocation(pref, volumes));
        }, "storage-volumes").start();
    }

    private void populateStorageLocation(ListPreference pref,
                                         List<StorageHelper.VolumeInfo> volumes) {
        storageVolumes = volumes;

        List<String> labels = new ArrayList<>();
        List<String> values = new ArrayList<>();
        for (int i = 0; i < volumes.size(); i++) {
            labels.add(volumes.get(i).describe());
            // 用下标当取值：同一台车上插拔顺序会变，但选中的那一刻下标是确定的，
            // 真正被记住的是下面钉进 customSdCardPath 的根目录
            values.add(EXTERNAL_PREFIX + i);
        }
        // 选的是 U 盘、盘却不在：单列一项照实写。不列的话，选中项只能落到下面的
        // 「内置存储」上 —— 看着像设置被改过，其实一直是 U 盘
        String current = currentStorageValue(volumes);
        if (EXTERNAL_MISSING.equals(current)) {
            labels.add(getString(R.string.storage_external_missing));
            values.add(EXTERNAL_MISSING);
        }
        // 内置存储照样列出来 —— 藏起来只会让人以为软件没这个能力。
        // 但标明它要开发者选项，选中时也会被拦下。
        labels.add(getString(StorageHelper.isInternalStorageAllowed()
                ? R.string.opt_internal_storage : R.string.opt_internal_storage_locked));
        values.add(AppConfig.STORAGE_INTERNAL);

        pref.setEntries(labels.toArray(new String[0]));
        pref.setEntryValues(values.toArray(new String[0]));
        // 当前值一定在列表里：某个卷、「U 盘（未检测到）」，或者一直列着的内置存储
        pref.setValue(current);
        pref.setSummary(pref.getEntry());

        pref.setOnPreferenceChangeListener((preference, newValue) -> {
            String value = String.valueOf(newValue);
            if (EXTERNAL_MISSING.equals(value)) {
                // 没有卷可钉，也不该借这一下改成别的：原样不动
                return false;
            }
            if (AppConfig.STORAGE_INTERNAL.equals(value)) {
                if (!StorageHelper.isInternalStorageAllowed()) {
                    explainInternalStorageIsGated();
                    return false;
                }
                confirmInternalStorage(pref);
            } else {
                applyStorageLocation(pref, value);
            }
            return false;
        });
        updateStorageUsage();
    }

    /**
     * 当前生效的是哪一项。外置时要对上具体哪个卷，不能笼统算「外置」；
     * 选了外置却一个卷都没有时是 {@link #EXTERNAL_MISSING}，不能算成内置。
     * 开发者选项关着时，存着的内置存储按 U 盘算（{@code AppConfig.getStorageLocation}），这里写的也是 U 盘。
     */
    private String currentStorageValue(List<StorageHelper.VolumeInfo> volumes) {
        if (!appConfig.isUsingExternalSdCard()) {
            return AppConfig.STORAGE_INTERNAL;
        }
        if (volumes.isEmpty()) {
            return EXTERNAL_MISSING;
        }
        String pinned = appConfig.getCustomSdCardPath();
        if (pinned != null && !pinned.isEmpty()) {
            for (int i = 0; i < volumes.size(); i++) {
                if (pinned.equals(volumes.get(i).root.getAbsolutePath())) {
                    return EXTERNAL_PREFIX + i;
                }
            }
        }
        return EXTERNAL_PREFIX + "0";
    }

    /** 说清楚为什么内置存储点不动，而不是让它默默没反应。 */
    private void explainInternalStorageIsGated() {
        if (getContext() == null) {
            return;
        }
        com.kooo.evcam.ui.CamDialogs.show(new MaterialAlertDialogBuilder(getContext(), R.style.Theme_Cam_MaterialAlertDialog)
                .setTitle(R.string.dlg_internal_locked_title)
                .setMessage(R.string.dlg_internal_locked_msg)
                .setPositiveButton(R.string.action_got_it, null));
    }

    private void applyStorageLocation(ListPreference pref, String value) {
        if (value.startsWith(EXTERNAL_PREFIX)) {
            int index = Integer.parseInt(value.substring(EXTERNAL_PREFIX.length()));
            if (storageVolumes != null && index < storageVolumes.size()) {
                appConfig.setCustomSdCardPath(
                        storageVolumes.get(index).root.getAbsolutePath());
            }
            appConfig.setStorageLocation(AppConfig.STORAGE_EXTERNAL_SD);
        } else {
            // 回到内置存储时清掉钉住的卷，否则下次选外置还会认着旧盘
            appConfig.setCustomSdCardPath(null);
            appConfig.setStorageLocation(AppConfig.STORAGE_INTERNAL);
        }
        // 盘的探测结果有 5 秒缓存：不清的话，回到主界面时状态条还写着换之前那个盘的余量
        StorageHelper.clearCache();
        com.kooo.evcam.storage.StorageState.refresh(pref.getContext(), "storage-setting");
        pref.setValue(value);
        pref.setSummary(pref.getEntry());
        toast(getString(R.string.msg_storage_changed, pref.getEntry()));
        updateStorageUsage();
    }

    /** 上限用 GB 存，界面上是个数字输入框；留空或 0 表示不限制。 */
    private void bindGigabyteLimit(String key, int current, IntSetter setter) {
        EditTextPreference pref = findPreference(key);
        if (pref == null) {
            return;
        }
        pref.setPersistent(false);
        pref.setText(current > 0 ? String.valueOf(current) : "");
        pref.setSummary(describeLimit(current));
        pref.setOnPreferenceChangeListener((preference, newValue) -> {
            int parsed = 0;
            String text = String.valueOf(newValue).trim();
            if (!text.isEmpty()) {
                try {
                    parsed = Math.max(0, Integer.parseInt(text));
                } catch (NumberFormatException e) {
                    toast(getString(R.string.msg_enter_number));
                    return false;
                }
            }
            setter.set(parsed);
            pref.setText(parsed > 0 ? String.valueOf(parsed) : "");
            pref.setSummary(describeLimit(parsed));
            return false;
        });
    }

    /**
     * 熄屏录制最多不让车机睡多久：用户自己填小时数，可带小数（24、30 都行），存成分钟。
     * 填错、留空、填 0 或负数（折成分钟四舍五入为 0 的也算）都不收，提示「请输入大于 0 的数字」；
     * 大到分钟数存不下的，按能存的最大值收。
     */
    private void bindScreenOffWakeHours() {
        EditTextPreference pref = findPreference("pref_screen_off_wake_hours");
        if (pref == null) {
            return;
        }
        pref.setPersistent(false);
        pref.setText(hoursText(appConfig.getScreenOffWakeMinutes()));
        pref.setSummary(getString(R.string.unit_hours, hoursText(appConfig.getScreenOffWakeMinutes())));
        pref.setOnPreferenceChangeListener((preference, newValue) -> {
            int minutes;
            try {
                double hours = Double.parseDouble(String.valueOf(newValue).trim());
                // 先夹在 int 范围里再收窄：直接强转，太大的正数会绕成负数被当成「填了负数」，
                // 太小的负数反倒绕成正数被收下
                minutes = (int) Math.max(0, Math.min(Integer.MAX_VALUE, Math.round(hours * 60)));
            } catch (NumberFormatException e) {
                minutes = 0;
            }
            if (minutes <= 0) {
                toast(getString(R.string.msg_enter_positive_number));
                return false;
            }
            appConfig.setScreenOffWakeMinutes(minutes);
            pref.setText(hoursText(minutes));
            pref.setSummary(getString(R.string.unit_hours, hoursText(minutes)));
            return false;
        });
    }

    /** 分钟数写成小时：整点写「2」，不整写「1.5」。 */
    private static String hoursText(int minutes) {
        if (minutes % 60 == 0) {
            return String.valueOf(minutes / 60);
        }
        return String.format(java.util.Locale.US, "%.1f", minutes / 60.0);
    }

    /**
     * 车牌号输入框。
     *
     * <p>输入的东西一律先过 {@link LicensePlate#sanitize}：小写转大写，
     * 空格连字符之类去掉，超过十位截断。清洗结果直接显示在下面 ——
     * 录进画面的就是这一串，不能让人以为自己敲的原样进去了。</p>
     */
    private void bindLicensePlate() {
        EditTextPreference pref = findPreference("pref_license_plate");
        if (pref == null) {
            return;
        }
        pref.setPersistent(false);
        pref.setText(appConfig.getLicensePlateRaw());
        showLicensePlate();
        pref.setOnPreferenceChangeListener((preference, newValue) -> {
            String raw = String.valueOf(newValue);
            String clean = LicensePlate.sanitize(raw);
            appConfig.setLicensePlate(clean);
            pref.setText(clean);
            showLicensePlate();
            if (!clean.equals(raw.trim()) && !clean.isEmpty()) {
                toast(getString(R.string.msg_plate_cleaned, clean));
            }
            return false;
        });
    }

    /** 摘要写当前车牌号；没填就说没填，并把规则写在后面。 */
    private void showLicensePlate() {
        EditTextPreference pref = findPreference("pref_license_plate");
        if (pref == null) {
            return;
        }
        String plate = appConfig.getLicensePlateRaw();
        pref.setSummary(plate.isEmpty()
                ? getString(R.string.set_plate_empty) + " · " + getString(R.string.set_plate_hint)
                : plate + " · " + getString(R.string.set_plate_hint));
    }

    private String describeLimit(int gigabytes) {
        return gigabytes > 0 ? gigabytes + " GB" : getString(R.string.info_unlimited);
    }

    /**
     * 「录像保存路径」：在录写录制器实际写的目录，没在录写下一次会写的目录；
     * 此刻录不了（没有 U 盘、开发者选项没开）写「未检测到 U 盘」（{@link StorageHelper#savedVideoDir}）。
     */
    private void updateStorageUsage() {
        Preference pref = findPreference("pref_storage_usage");
        if (pref == null || getContext() == null) {
            return;
        }
        pref.setSummary(getString(R.string.info_reading));
        final Context context = getContext().getApplicationContext();
        final boolean recording = com.kooo.evcam.recording.RecordingCoordinator.get(requireContext()).isRecording();
        final String noDrive = getString(R.string.set_storage_usage_no_drive);
        final String failed = getString(R.string.info_read_failed);
        new Thread(() -> {
            String desc;
            try {
                java.io.File dir = StorageHelper.savedVideoDir(context, recording);
                desc = dir != null ? dir.getAbsolutePath() : noDrive;
            } catch (Throwable t) {
                desc = failed;
            }
            final String result = desc;
            if (isAdded()) {
                requireActivity().runOnUiThread(() -> pref.setSummary(result));
            }
        }, "storage-usage").start();
    }

    // ------------------------------------------------------------------ 打转向灯弹侧视

    private void bindSidePopup() {
        bindOverlaySwitch("pref_side_popup", appConfig.isSidePopupEnabled(),
                OverlayCoordinator::setSidePopupEnabled, on -> {
                    if (on) {
                        toast(getString(R.string.msg_side_popup_on));
                    }
                });
        bindSlider("pref_side_popup_min_speed", 0, AppConfig.SIDE_POPUP_MAX_MIN_SPEED,
                appConfig.getSidePopupMinSpeed(), "km/h", value -> {
                    appConfig.setSidePopupMinSpeed(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
        bindSwitch("pref_side_popup_straighten", appConfig.isSidePopupStraighten(), value -> {
            appConfig.setSidePopupStraighten(value);
            com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
        });
        bindSlider("pref_side_popup_fov",
                Math.round(com.kooo.evcam.zeekr.SideViewProjection.MIN_FOV_DEGREES),
                Math.round(com.kooo.evcam.zeekr.SideViewProjection.MAX_FOV_DEGREES),
                appConfig.getSidePopupFov(), "°", value -> {
                    appConfig.setSidePopupFov(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
        int maxYaw = Math.round(com.kooo.evcam.zeekr.SideViewProjection.MAX_YAW_DEGREES);
        bindSlider("pref_side_popup_yaw", -maxYaw, maxYaw,
                appConfig.getSidePopupYaw(), "°", value -> {
                    appConfig.setSidePopupYaw(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
        int maxPitch = Math.round(com.kooo.evcam.zeekr.SideViewProjection.MAX_PITCH_DEGREES);
        bindSlider("pref_side_popup_pitch", -maxPitch, maxPitch,
                appConfig.getSidePopupPitch(), "°", value -> {
                    appConfig.setSidePopupPitch(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
        bindSwitch("pref_side_popup_instant", appConfig.isSidePopupInstant(), value -> {
            appConfig.setSidePopupInstant(value);
            com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
        });
        bindSlider("pref_side_popup_close_delay_ms", 0, AppConfig.SIDE_POPUP_MAX_CLOSE_DELAY_MS,
                appConfig.getSidePopupCloseDelayMs(), "ms", value -> {
                    appConfig.setSidePopupCloseDelayMs(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
        bindSlider("pref_side_popup_size", AppConfig.SIDE_POPUP_MIN_SIZE_PERCENT,
                AppConfig.SIDE_POPUP_MAX_SIZE_PERCENT, appConfig.getSidePopupSizePercent(), "%", value -> {
                    appConfig.setSidePopupSizePercent(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
        bindSlider("pref_side_popup_shape", AppConfig.SIDE_POPUP_MIN_SHAPE_PERCENT,
                AppConfig.SIDE_POPUP_MAX_SHAPE_PERCENT, appConfig.getSidePopupShapePercent(), "%", value -> {
                    appConfig.setSidePopupShapePercent(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
        bindSlider("pref_side_popup_vertical", 0, 100,
                appConfig.getSidePopupVerticalPercent(), "%", value -> {
                    appConfig.setSidePopupVerticalPercent(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
        bindSideOutput();
        bindSwitch("pref_side_popup_mirror", appConfig.isSidePopupMirrored(), value -> {
            appConfig.setSidePopupMirrored(value);
            com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
        });
        bindSwitch("pref_hud_side_mirror", appConfig.isHudSideMirrored(), value -> {
            appConfig.setHudSideMirrored(value);
            com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
        });
        bindSlider("pref_hud_side_size", AppConfig.HUD_SIDE_MIN_SIZE_PERCENT,
                AppConfig.HUD_SIDE_MAX_SIZE_PERCENT, appConfig.getHudSideSizePercent(), "%", value -> {
                    appConfig.setHudSideSizePercent(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
        bindSlider("pref_hud_side_shape", AppConfig.HUD_SIDE_MIN_SHAPE_PERCENT,
                AppConfig.HUD_SIDE_MAX_SHAPE_PERCENT, appConfig.getHudSideShapePercent(), "%", value -> {
                    appConfig.setHudSideShapePercent(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
        bindSlider("pref_hud_side_left", 0, 100,
                appConfig.getHudSideLeftPercent(), "%", value -> {
                    appConfig.setHudSideLeftPercent(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
        bindSlider("pref_hud_side_vertical", 0, 100,
                appConfig.getHudSideVerticalPercent(), "%", value -> {
                    appConfig.setHudSideVerticalPercent(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
        bindSlider("pref_hud_side_opacity", AppConfig.HUD_SIDE_MIN_OPACITY_PERCENT, 100,
                appConfig.getHudSideOpacityPercent(), "%", value -> {
                    appConfig.setHudSideOpacityPercent(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
        bindSlider("pref_hud_side_contrast", AppConfig.HUD_SIDE_MIN_CONTRAST_PERCENT,
                AppConfig.HUD_SIDE_MAX_CONTRAST_PERCENT, appConfig.getHudSideContrastPercent(), "%", value -> {
                    appConfig.setHudSideContrastPercent(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
        bindSlider("pref_hud_side_night", AppConfig.HUD_SIDE_MIN_NIGHT_PERCENT,
                AppConfig.HUD_SIDE_MAX_NIGHT_PERCENT, appConfig.getHudSideNightPercent(), "%", value -> {
                    appConfig.setHudSideNightPercent(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
        bindSlider("pref_hud_side_fade", AppConfig.HUD_SIDE_MIN_FADE_PERCENT,
                AppConfig.HUD_SIDE_MAX_FADE_PERCENT, appConfig.getHudSideFadePercent(), "%", value -> {
                    appConfig.setHudSideFadePercent(value);
                    com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
                });
    }

    /** 侧视画面出在哪：主屏、HUD、两边都出。存下去的是 {@link AppConfig#getSideOutput} 那三个数。 */
    private void bindSideOutput() {
        ListPreference list = findPreference("pref_side_output");
        if (list == null) {
            return;
        }
        list.setPersistent(false);
        list.setEntries(new CharSequence[] {
                getString(R.string.set_side_output_screen),
                getString(R.string.set_side_output_hud),
                getString(R.string.set_side_output_both)});
        list.setEntryValues(new CharSequence[] {
                String.valueOf(AppConfig.SIDE_OUTPUT_SCREEN),
                String.valueOf(AppConfig.SIDE_OUTPUT_HUD),
                String.valueOf(AppConfig.SIDE_OUTPUT_BOTH)});
        list.setValue(String.valueOf(appConfig.getSideOutput()));
        list.setSummaryProvider(p -> ((ListPreference) p).getEntry());
        list.setOnPreferenceChangeListener((p, value) -> {
            appConfig.setSideOutput(Integer.parseInt(String.valueOf(value)));
            com.kooo.evcam.zeekr.SideViewPopupService.applyConfig();
            return true;
        });
    }

    // ------------------------------------------------------------------ 超级后视镜

    private void bindRearView() {
        // 这个开关原先没查悬浮窗权限：没授权时它会拨上去、提示语还讲了手势怎么用，
        // 而服务在 onStartCommand 里就 stopSelf() 走了，屏幕上什么都没有。
        bindOverlaySwitch("pref_rearview", appConfig.isRearViewEnabled(),
                OverlayCoordinator::setRearViewEnabled, on -> {
                    if (on) {
                        toast(getString(R.string.msg_rearview_on));
                        com.kooo.evcam.ui.RearViewGuide.showOnce(getActivity());
                    }
                });

        // 不跟着开关走：还没打开后视镜之前，也该能先看看它怎么用
        onClick("pref_rearview_guide",
                pref -> com.kooo.evcam.ui.RearViewGuide.show(getActivity()));

        bindSwitch("pref_rearview_button_mode", appConfig.isRearViewButtonMode(), value -> {
            appConfig.setRearViewButtonMode(value);
            if (getContext() != null && appConfig.isRearViewEnabled()) {
                RearViewMirrorService.applyButtonMode(getContext());
            }
        });

        bindSwitch("pref_rearview_front_rear", appConfig.isRearViewFrontRearOnly(), value -> {
            appConfig.setRearViewFrontRearOnly(value);
            if (getContext() != null && appConfig.isRearViewEnabled()) {
                RearViewMirrorService.applyLaneMode(getContext());
            }
        });

        bindSwitch("pref_rearview_fisheye", appConfig.isRearViewFisheyeCorrection(), value -> {
            appConfig.setRearViewFisheyeCorrection(value);
            pushCorrection();
        });

        bindSlider("pref_rearview_fov",
                (int) FisheyeProjectionBounds.MIN, (int) FisheyeProjectionBounds.MAX,
                Math.round(appConfig.getRearViewFov()), "°", value -> {
                    appConfig.setRearViewFov(value);
                    pushCorrection();
                });

        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;

        bindSlider("pref_rearview_width", AppConfig.REARVIEW_MIN_SIZE, screenWidth,
                appConfig.getRearViewWidth(screenWidth), " px", value -> {
                    appConfig.setRearViewSize(value, appConfig.getRearViewHeight(screenHeight),
                            screenWidth, screenHeight);
                    pushSize();
                });

        bindSlider("pref_rearview_height", AppConfig.REARVIEW_MIN_SIZE, screenHeight,
                appConfig.getRearViewHeight(screenHeight), " px", value -> {
                    appConfig.setRearViewSize(appConfig.getRearViewWidth(screenWidth), value,
                            screenWidth, screenHeight);
                    pushSize();
                });

        onClick("pref_rearview_reset", pref -> {
            appConfig.resetRearViewLayout();
            if (getContext() != null && appConfig.isRearViewEnabled()) {
                // 重开一次让新的默认值生效
                RearViewMirrorService.stop(getContext());
                RearViewMirrorService.start(getContext());
            }
            toast(getString(R.string.msg_rearview_reset));
        });
    }

    /**
     * 把「窗口宽度 / 高度」两根滑块拨到窗口当前的实际尺寸。
     *
     * <p>后视镜是个悬浮窗，<b>可以在设置页开着的时候被捏大捏小</b> ——
     * 滑块的值是在 {@code onCreatePreferences} 里读一次就定了的，
     * 不重读的话，界面上显示的宽高和眼前那个窗口对不上。</p>
     *
     * <p>放在 {@code onResume}：从别处回到这个界面时必然经过它。</p>
     */
    private void refreshRearViewSize() {
        if (getContext() == null) {
            return;
        }
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        SeekBarPreference width = findPreference("pref_rearview_width");
        if (width != null) {
            width.setValue(appConfig.getRearViewWidth(screenWidth));
        }
        SeekBarPreference height = findPreference("pref_rearview_height");
        if (height != null) {
            height.setValue(appConfig.getRearViewHeight(screenHeight));
        }
    }

    private void pushCorrection() {
        if (getContext() != null && appConfig.isRearViewEnabled()) {
            RearViewMirrorService.applyCorrection(getContext());
        }
    }

    private void pushSize() {
        if (getContext() != null && appConfig.isRearViewEnabled()) {
            RearViewMirrorService.applySize(getContext());
        }
    }

    // ------------------------------------------------------------------ 悬浮窗

    private void bindFloating() {
        // 按钮显示出来时自己问协调器在不在录，这里不用再推状态
        bindOverlaySwitch("pref_recording_floating", appConfig.isRecordingFloatingEnabled(),
                OverlayCoordinator::setRecordButtonEnabled, null);

        // 整档上移 50%（原来 32–100）：最小的也要比原来的最小大一半
        bindSlider("pref_button_size", 48, 150,
                appConfig.getRecordingFloatingButtonSizeDp(), " dp",
                value -> {
                    appConfig.setRecordingFloatingButtonSizeDp(value);
                    pushFloatingStyle();
                });
        bindSlider("pref_floating_alpha", 20, 100, appConfig.getFloatingWindowAlpha(), "%",
                value -> {
                    appConfig.setFloatingWindowAlpha(value);
                    pushFloatingStyle();
                });

        bindFloatingAction("pref_floating_tap", appConfig.getFloatingTapAction(),
                value -> appConfig.setFloatingTapAction(value));
        bindFloatingAction("pref_floating_long_press", appConfig.getFloatingLongPressAction(),
                value -> appConfig.setFloatingLongPressAction(value));

        bindSwitch("pref_floating_lock", appConfig.isFloatingPositionLocked(),
                value -> appConfig.setFloatingPositionLocked(value));

        bindSwitch("pref_floating_duration", appConfig.isFloatingDurationVisible(), value -> {
            appConfig.setFloatingDurationVisible(value);
            pushFloatingStyle();
        });
        bindSlider("pref_button_text_size", 8, 24,
                appConfig.getRecordingFloatingTimeTextSizeSp(), " sp",
                value -> {
                    appConfig.setRecordingFloatingTimeTextSizeSp(value);
                    pushFloatingStyle();
                });

        bindFloatingReset();

    }

    /**
     * 单击 / 长按能选哪几件事。
     *
     * <p>选项文字在 strings.xml，存下去的是 {@link FloatingAction} 里那几个 key，
     * 两边靠同一个数组下标对上 —— 所以这里必须一起写，不能一边加一边忘。</p>
     */
    private void bindFloatingAction(String key, String current, StringSetter onPick) {
        Preference pref = findPreference(key);
        if (!(pref instanceof ListPreference)) {
            return;
        }
        ListPreference list = (ListPreference) pref;
        FloatingAction[] actions = FloatingAction.values();
        String[] values = new String[actions.length];
        String[] labels = new String[actions.length];
        for (int i = 0; i < actions.length; i++) {
            values[i] = actions[i].key;
            labels[i] = getString(labelOf(actions[i]));
        }
        list.setEntries(labels);
        list.setEntryValues(values);
        list.setValue(FloatingAction.fromKey(current).key);
        list.setSummaryProvider(p -> ((ListPreference) p).getEntry());
        list.setOnPreferenceChangeListener((p, value) -> {
            onPick.set(String.valueOf(value));
            return true;
        });
    }

    /**
     * 每个动作在界面上叫什么。
     *
     * <p>两个数组从 {@link FloatingAction#values()} 一起长出来，所以数量不会对不上；
     * 新增一个动作时，忘了在这里加分支的后果是它显示成「打开主界面」——
     * 不会崩，但会说谎，所以新增时两处一起改。</p>
     */
    private static int labelOf(FloatingAction action) {
        switch (action) {
            case TOGGLE_RECORDING:
                return R.string.floating_action_toggle_recording;
            case TAKE_PHOTO:
                return R.string.floating_action_take_photo;
            case TOGGLE_MIRROR:
                return R.string.floating_action_toggle_mirror;
            case OPEN_APP:
            default:
                return R.string.floating_action_open_app;
        }
    }


    /**
     * 外观改了，让按钮就地重读一遍配置。
     *
     * <p>以前这里发的是 {@code ACTION_UPDATE_SIZE} 加两个 extra，而服务那边
     * 是用<b>广播</b>接收器在等这个 action —— 这边却是 {@code startService}。
     * 两条路对不上，所以两个滑块一直没有任何反应。现在服务在 onStartCommand
     * 里认这条指令，参数它自己读，不用带。</p>
     */
    private void pushFloatingStyle() {
        sendToRecordingFloating(RecordingFloatingService.ACTION_UPDATE_STYLE, null);
    }

    /**
     * 给录制悬浮按钮的服务发个指令。
     *
     * <p>放到后台线程：{@code startService} 会同步走到服务的 onStartCommand，
     * 悬浮窗那边要建视图，在主线程上做容易卡住。</p>
     */
    private void sendToRecordingFloating(String action, Intent extras) {
        if (getContext() == null) {
            return;
        }
        final Context context = getContext().getApplicationContext();
        new Thread(() -> {
            try {
                Intent intent = new Intent(context, RecordingFloatingService.class);
                intent.setAction(action);
                if (extras != null) {
                    intent.putExtras(extras);
                }
                context.startService(intent);
            } catch (Exception e) {
                AppLog.e(TAG, "录制悬浮服务指令失败: " + action, e);
            }
        }, "recording-floating-cmd").start();
    }

    private void bindFloatingReset() {
        onClick("pref_reset_floating", pref -> {
            // 以前清的是旧「主屏悬浮窗」那几个键，合并后的按钮根本不读它们 ——
            // 点了提示「已重置」，按钮纹丝不动。现在清按钮自己的位置、大小、字号，
            // 并让它当场挪回默认位置（右上角）
            appConfig.resetRecordingFloatingLayout();
            sendToRecordingFloating(RecordingFloatingService.ACTION_RESET_POSITION, null);
            // 两个滑块跟着回去，否则界面上还写着重置之前的数
            SeekBarPreference size = findPreference("pref_button_size");
            if (size != null) {
                size.setValue(appConfig.getRecordingFloatingButtonSizeDp());
            }
            SeekBarPreference textSize = findPreference("pref_button_text_size");
            if (textSize != null) {
                textSize.setValue(appConfig.getRecordingFloatingTimeTextSizeSp());
            }
            toast(getString(R.string.msg_floating_reset));
        });
    }

    // ------------------------------------------------------------------ 系统

    /**
     * 界面语言。
     *
     * <p>选完立刻生效：{@link Languages#apply} 走的是系统的「按应用设定语言」，
     * 由系统重新加载资源并重建界面 —— 不需要提示「重启后生效」，
     * 那种提示本身就意味着界面上显示的和实际生效的暂时不是一回事。</p>
     */
    private void bindLanguage() {
        bindEnum("pref_language", SettingsRegistry.LANGUAGE, appConfig.getLanguageMode(),
                value -> {
                    appConfig.setLanguageMode(value);
                    Languages.apply(value);
                });
    }

    // ------------------------------------------------------------------ 界面

    private void bindInterface() {
        bindLanguage();
        // 回到主界面时生效（MainActivity.showRecordingInterface 会按它重新摆一次）。
        // 在这里选过，首次启动就不必再问
        bindSegmented("pref_rail_side", SettingsRegistry.ACTION_RAIL_SIDE,
                appConfig.getActionRailSide(), value -> {
                    appConfig.setActionRailSide(value);
                    appConfig.setRailSideChosen();
                });
        // 录制状态显示是主界面画面角落那块，不是悬浮按钮的事
        bindSwitch("pref_recording_stats", appConfig.isRecordingStatsEnabled(),
                value -> appConfig.setRecordingStatsEnabled(value));

        bindSwitch("pref_reduce_motion", appConfig.isReduceMotionWhileRecording(),
                value -> appConfig.setReduceMotionWhileRecording(value));
        // 车辆状态面板：主界面那个控件自己听这个开关
        bindSwitch("pref_vehicle_status", appConfig.isVehicleStatusEnabled(),
                value -> appConfig.setVehicleStatusEnabled(value));

        bindEnum("pref_fisheye_projection", SettingsRegistry.FISHEYE_PROJECTION,
                appConfig.getFisheyeProjection(), value -> {
                    appConfig.setFisheyeProjection(value);
                    // 上限跟着投影变，滑块得重新绑 —— 否则界面上还能拖到 180°，
                    // 实际生效的却是夹过的 140°
                    bindFisheyeFov();
                }, this::showProjectionSummary);
        bindFisheyeFov();
    }

    /** 校正视野。范围随投影方式变，所以单独一个方法，换投影时再叫一次。 */
    private void bindFisheyeFov() {
        String projection = appConfig.getFisheyeProjection();
        bindSlider("pref_fisheye_fov", (int) FisheyeProjectionBounds.MIN,
                (int) com.kooo.evcam.zeekr.FisheyeProjection.maxFovFor(projection),
                Math.round(appConfig.getFisheyeFov()), "°",
                value -> appConfig.setFisheyeFov(value));
    }

    /** 摘要里除了选中项，还要写清楚它管到哪里：主界面预览、图片回看、视频回看。 */
    private void showProjectionSummary() {
        ListPreference pref = findPreference("pref_fisheye_projection");
        if (pref != null && getContext() != null) {
            pref.setSummary(getString(R.string.set_fisheye_projection_summary, pref.getEntry()));
        }
    }

    /**
     * 系统：诊断信息、系统信息、开机自启、保活、熄屏持续录制。
     * 开发者的「熄屏录制（阻止休眠）」不在这里，在开发者选项分区（{@link #bindAdvanced}）。
     */
    private void bindSystem() {
        // 诊断信息放在系统里：它是给所有人导出报告用的
        onClick("pref_diagnostics", pref ->
                startActivity(new Intent(getContext(), DiagnosticsActivity.class)));
        // 系统信息（试验性）：车机能读到的车辆信号。只在这一页开着时收，离开就把资源放掉
        onClick("pref_vehicle_info", pref ->
                openFragment(new VehicleInfoFragment(), R.string.set_vehicle_info_title));

        bindSwitch("pref_auto_start", appConfig.isAutoStartOnBoot(),
                value -> appConfig.setAutoStartOnBoot(value));
        // 保活开关接手全部保活手段（规格 §3）：关了就把定时任务也取消，别等它下次到点再自己退出
        bindSwitch("pref_keep_alive", appConfig.isKeepAliveEnabled(),
                value -> {
                    appConfig.setKeepAliveEnabled(value);
                    if (value) {
                        com.kooo.evcam.KeepAliveManager.startKeepAliveWork(requireContext());
                    } else {
                        com.kooo.evcam.KeepAliveManager.stopKeepAliveWork(requireContext());
                    }
                });
        // 熄屏持续录制能不能起作用看哨兵模式：行尾写着哨兵模式此刻开没开（行样式在 apply 之前标上）
        androidx.preference.Preference keepRecording = findPreference("pref_screen_off_keep_recording");
        if (keepRecording != null) {
            PreferenceRows.markSentryStatus(keepRecording);
        }
        bindSwitch("pref_screen_off_keep_recording", appConfig.isScreenOffKeepRecording(),
                value -> appConfig.setScreenOffKeepRecording(value));
    }

    // ------------------------------------------------------------------ 原「高级」，现在在开发者选项里

    private void bindAdvanced() {
        bindEnum("pref_recording_mode", SettingsRegistry.RECORDING_MODE,
                appConfig.getRecordingMode(), value -> appConfig.setRecordingMode(value),
                this::showRecordingModeSummary);

        // 熄屏录制 = 熄屏持续录制 + 唤醒锁（规格 §3.1）。整块只在开发者选项里出现，不用再单独锁
        bindSwitch("pref_screen_off_recording", appConfig.isScreenOffRecordingEnabled(),
                value -> appConfig.setScreenOffRecordingEnabled(value));
        bindScreenOffWakeHours();
        bindSwitch("pref_force_h264", appConfig.isForceH264Encoding(),
                value -> appConfig.setForceH264Encoding(value));

        // 画面调节：打开调节窗口（MainActivity 管着它，退出设置也还在），同时开启画面调节、套上存着的参数。
        // 窗口开没开成由 MainActivity 说：没有悬浮窗权限、相机还没好时它自己提示
        onClick("pref_image_adjust", pref -> {
            if (getActivity() instanceof MainActivity) {
                MainActivity main = (MainActivity) getActivity();
                appConfig.setImageAdjustEnabled(true);
                main.setImageAdjustEnabled(true);
                main.showImageAdjustFloatingWindow();
            }
        });

        onClick("pref_image_adjust_reset", pref -> {
            if (getActivity() instanceof MainActivity) {
                com.kooo.evcam.camera.ImageAdjustManager manager =
                        ((MainActivity) getActivity()).getImageAdjustManager();
                if (manager != null) {
                    manager.resetToDefault();
                    toast(getString(R.string.msg_adjust_reset));
                }
            }
        });

        onClick("pref_camera_mapping", pref -> {
            if (getContext() != null) {
                SettingsDialogs.showCameraMappingDialog(
                        getContext(), appConfig, this::updateCameraMappingSummary);
            }
        });
        updateCameraMappingSummary();

    }

    /** 摘要除了选中项，还写明这一项现在不起作用：录制固定走 MediaCodec。 */
    private void showRecordingModeSummary() {
        ListPreference pref = findPreference("pref_recording_mode");
        if (pref != null && getContext() != null) {
            pref.setSummary(getString(R.string.set_recording_mode_summary, pref.getEntry()));
        }
    }

    private void updateCameraMappingSummary() {
        Preference pref = findPreference("pref_camera_mapping");
        if (pref == null) {
            return;
        }
        pref.setSummary(getString(appConfig.hasCameraOverride()
                ? R.string.info_mapping_manual : R.string.info_mapping_auto));
    }

    // ------------------------------------------------------------------ 开发者选项

    /**
     * 开发者选项里的工具。只在开发者选项开着时接线（见 {@link #onCreatePreferences}）。
     *
     * <p>没开时整个分区从左栏上移除，而不是置灰 —— 置灰等于告诉别人
     * 「这里有东西但你用不了」，而这些本来就不该出现在普通用户的设置里。</p>
     */
    private void bindDeveloper() {
        // 这里原来先找一个 key 为 cat_developer 的分类，找不到就整个返回 ——
        // 而 0.21.0 把分区改成嵌套 PreferenceScreen 之后，这个 key 就不存在了。
        // 于是下面四个入口一个都没接上，点了毫无反应，也不报错。
        onClick("pref_permissions",
                pref -> openFragment(new PermissionsPreferenceFragment(), R.string.dev_permissions_title));

        bindSwitch("pref_raw_frame_dump", appConfig.isRawFrameDumpEnabled(),
                appConfig::setRawFrameDumpEnabled);

        // 信号普查：开就挂全部功能号记变化，关就停；到点自己停时开关也关（见 SignalScanControl）
        bindSwitch("pref_signal_scan", appConfig.isSignalScanEnabled(), on -> {
            appConfig.setSignalScanEnabled(on);
            com.kooo.evcam.telemetry.SignalScanControl.apply(requireContext().getApplicationContext());
        });

        // 鱼眼校正换成 GPU 逐像素算。只换算法，开不开还是看屏幕上那个鱼眼按钮
        bindSwitch("pref_gpu_fisheye_preview", appConfig.isGpuFisheyePreview(),
                appConfig::setGpuFisheyePreview);
        bindSwitch("pref_gpu_fisheye_video", appConfig.isGpuFisheyeVideo(),
                appConfig::setGpuFisheyeVideo);

        onClick("pref_repair_mp4", pref -> {
            if (getActivity() == null) {
                return;
            }
            // 录制中不能修：正在录的那一段也没有索引，和断电留下的半截文件长得一样
            boolean recording = com.kooo.evcam.recording.RecordingCoordinator.get(requireContext()).isRecording();
            com.kooo.evcam.repair.Mp4RepairFlow.start(getActivity(), recording);
        });

        // 归档：把录像、照片、日志从录像盘搬到另一个盘（项目所有者用 Type-C 固态盘统一管理）
        onClick("pref_archive", pref -> {
            if (getActivity() == null) {
                return;
            }
            boolean recording = com.kooo.evcam.recording.RecordingCoordinator.get(requireContext()).isRecording();
            com.kooo.evcam.repair.ArchiveFlow.start(getActivity(), recording);
        });

    }

    /**
     * 带按钮的设置对话框自己弹。
     *
     * <h3>为什么不用 androidx 自带的</h3>
     *
     * <p>androidx 的偏好对话框自己建一个<b>框架</b> AlertDialog，主题靠
     * {@code alertDialogTheme} 从 Activity 主题里解析。「车牌号没有确认键」
     * 「存储上限没有保存键」说的都是这一件事。</p>
     *
     * <p>0.36.4 往主题里补属性、0.38.0 把主题直接传进构造函数，都只是换个方式继续用
     * 框架对话框，所以在实车上都没修好 —— 那一栏按钮长什么样由车机 ROM 说了算。
     * 真正的差别是<b>哪一种对话框</b>：同期用 Material 对话框的那几个（相机映射、
     * 设备名）一直是好的。这里也统一到那条路。</p>
     *
     * <p>下拉框（ListPreference）也在此列。androidx 那个选中即关闭、没有确认键，
     * 点错一项就直接生效，没有反悔的机会。</p>
     */
    @Override
    public void onDisplayPreferenceDialog(Preference preference) {
        if (preference instanceof EditTextPreference) {
            showTextDialog((EditTextPreference) preference);
            return;
        }
        if (preference instanceof ListPreference) {
            showChoiceDialog((ListPreference) preference);
            return;
        }
        super.onDisplayPreferenceDialog(preference);
    }

    /** 单选：视频流配置、存储位置、操作按钮位置。选中之后还要按确定才算数。 */
    private void showChoiceDialog(ListPreference pref) {
        CharSequence[] entries = pref.getEntries();
        CharSequence[] values = pref.getEntryValues();
        if (entries == null || values == null || entries.length != values.length) {
            super.onDisplayPreferenceDialog(pref);
            return;
        }
        final int[] picked = {pref.findIndexOfValue(pref.getValue())};
        CharSequence title = pref.getDialogTitle() != null
                ? pref.getDialogTitle() : pref.getTitle();
        com.kooo.evcam.ui.CamDialogs.show(new MaterialAlertDialogBuilder(
                requireContext(), R.style.Theme_Cam_MaterialAlertDialog)
                .setTitle(title)
                .setSingleChoiceItems(entries, picked[0], (d, which) -> picked[0] = which)
                .setPositiveButton(R.string.action_ok, (d, w) -> {
                    if (picked[0] < 0 || picked[0] >= values.length) {
                        return;
                    }
                    String value = values[picked[0]].toString();
                    if (pref.callChangeListener(value)) {
                        pref.setValue(value);
                    }
                })
                .setNegativeButton(R.string.action_cancel, null));
    }

    /**
     * 单行文本输入：车牌号、视频 / 图片存储上限。
     * 标题和说明取 XML 里的 dialogTitle / dialogMessage（存储上限靠它们写单位和清理规则），
     * 和下拉框一个规矩：没写标题就用这一行的标题，没写说明就不带。
     */
    private void showTextDialog(EditTextPreference pref) {
        final android.widget.EditText input =
                com.kooo.evcam.ui.CamDialogs.input(requireContext());
        input.setText(pref.getText());
        input.setSelectAllOnFocus(true);
        configureInput(pref.getKey(), input);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        android.widget.FrameLayout box = new android.widget.FrameLayout(requireContext());
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(input);

        CharSequence title = pref.getDialogTitle() != null
                ? pref.getDialogTitle() : pref.getTitle();
        com.kooo.evcam.ui.CamDialogs.show(new MaterialAlertDialogBuilder(requireContext(), R.style.Theme_Cam_MaterialAlertDialog)
                .setTitle(title)
                .setMessage(pref.getDialogMessage())
                .setView(box)
                .setPositiveButton(R.string.action_save, (dialog, which) -> {
                    String value = input.getText().toString();
                    if (pref.callChangeListener(value)) {
                        pref.setText(value);
                    }
                })
                .setNegativeButton(R.string.action_cancel, null));
    }

    /**
     * 按 key 配键盘类型。
     *
     * <p>本来该问 preference 自己要那个 {@code OnBindEditTextListener}，
     * 但那个 getter 不是公开的。要输入什么这里本来就知道，写在一处反而更好找。</p>
     */
    private void configureInput(String key, android.widget.EditText input) {
        if ("pref_license_plate".equals(key)) {
            input.setInputType(InputType.TYPE_CLASS_TEXT
                    | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
            input.setFilters(new android.text.InputFilter[]{
                    new android.text.InputFilter.LengthFilter(LicensePlate.MAX_LENGTH)});
            return;
        }
        if ("pref_video_limit".equals(key) || "pref_photo_limit".equals(key)) {
            input.setInputType(InputType.TYPE_CLASS_NUMBER);
        }
        if ("pref_screen_off_wake_hours".equals(key)) {
            input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        }
    }

    
    // ------------------------------------------------------------------ 关于

    // ------------------------------------------------------------------ 检查更新

    /**
     * 检查更新：点那一行就查；另有一个「接收 Beta 版」开关。
     *
     * <p>当前版本写在那一行的说明里 —— 点之前就知道本机装的是哪个，
     * 查完提示「已是最新」时也对得上。</p>
     */
    private void bindUpdate() {
        androidx.preference.Preference check = findPreference("pref_check_update");
        if (check != null && getContext() != null) {
            check.setSummary(getString(R.string.set_check_update_summary,
                    com.kooo.evcam.update.UpdateFlow.currentVersion(getContext())));
        }
        onClick("pref_check_update",
                pref -> com.kooo.evcam.update.UpdateFlow.start(getActivity()));
        bindSwitch("pref_update_beta", appConfig.isUpdateBetaEnabled(),
                value -> appConfig.setUpdateBetaEnabled(value));
    }

    // ------------------------------------------------------------------ 小工具

    private interface BoolSetter {
        void set(boolean value);
    }

    private interface IntSetter {
        void set(int value);
    }

    private interface StringSetter {
        void set(String value);
    }

    private interface Action {
        void run(Preference preference);
    }

    /** 开关：不自己持久化，读写都走 AppConfig。 */
    /**
     * 悬浮窗类开关。
     *
     * <p>没有悬浮窗权限时<b>不把开关拨上去</b>，而是去要权限 ——
     * 拨上去而窗口不出现，就是「界面显示的和实际生效的不是一回事」。
     * 三个开关原先各写各的，其中一个漏了这道检查。</p>
     *
     * @param toggle      真正去开 / 关的动作，返回 false 表示没开成
     * @param afterChange 开成了之后额外要做的事，可以为 null
     */
    private void bindOverlaySwitch(String key, boolean current,
                                   OverlayToggle toggle, BoolSetter afterChange) {
        SwitchPreferenceCompat pref = findPreference(key);
        if (pref == null) {
            return;
        }
        pref.setPersistent(false);
        pref.setChecked(current);
        pref.setOnPreferenceChangeListener((preference, newValue) -> {
            if (getContext() == null) {
                return false;
            }
            boolean on = Boolean.TRUE.equals(newValue);
            if (!toggle.apply(getContext(), on)) {
                toast(getString(R.string.msg_need_overlay));
                WakeUpHelper.requestOverlayPermission(getContext());
                return false;
            }
            if (afterChange != null) {
                afterChange.set(on);
            }
            return true;
        });
    }

    /** 开 / 关一个悬浮窗；返回是否真的按要求生效。 */
    private interface OverlayToggle {
        boolean apply(Context context, boolean enabled);
    }

    private void bindSwitch(String key, boolean current, BoolSetter setter) {
        SwitchPreferenceCompat pref = findPreference(key);
        if (pref == null) {
            return;
        }
        pref.setPersistent(false);
        pref.setChecked(current);
        pref.setOnPreferenceChangeListener((preference, newValue) -> {
            boolean on = Boolean.TRUE.equals(newValue);
            setter.set(on);
            // 开关什么时候被改过，黑匣子里要看得到 —— 否则一段时间线对不上当时的设置
            com.kooo.evcam.blackbox.BlackBox.noteImportant("开关变更: " + key + " → " + (on ? "开" : "关"));
            return true;
        });
    }

    /** 枚举：选项与显示名都来自 {@link SettingsRegistry}，声明一遍就够。 */
    /**
     * 选项只有两三个的设置：摆在行里点一次。
     *
     * <p>和 {@link #bindEnum} 的区别只在长相；取值、校验、写回都还是走
     * {@link SettingSpec}，所以两者可以随时互换。</p>
     */
    private void bindSegmented(String key, SettingSpec spec, String current,
                               StringSetter setter) {
        SegmentedPreference pref = findPreference(key);
        if (pref == null) {
            return;
        }
        pref.setOptions(localizedNames(spec), spec.values());
        pref.setValue(spec.sanitize(current));
        pref.setOnPreferenceChangeListener((preference, newValue) -> {
            setter.set(String.valueOf(newValue));
            return true;
        });
    }

    private void bindEnum(String key, SettingSpec spec, String current, StringSetter setter) {
        bindEnum(key, spec, current, setter, null);
    }

    /**
     * @param summary 自己接管摘要的写法；传 null 时摘要就是选中项的名字。
     *                <b>必须在 {@code setValue} 之后调用</b> —— 之前调的话
     *                {@code getEntry()} 拿到的还是上一个选项，而且紧接着会被
     *                默认的 setSummary 覆盖掉。「切换之后摘要消失」就是这么来的。
     */
    private void bindEnum(String key, SettingSpec spec, String current, StringSetter setter,
                          Runnable summary) {
        ListPreference pref = findPreference(key);
        if (pref == null) {
            return;
        }
        pref.setPersistent(false);
        pref.setEntries(localizedNames(spec));
        pref.setEntryValues(spec.values());
        pref.setValue(spec.sanitize(current));
        if (summary == null) {
            pref.setSummary(pref.getEntry());
        } else {
            summary.run();
        }
        pref.setOnPreferenceChangeListener((preference, newValue) -> {
            String value = String.valueOf(newValue);
            setter.set(value);
            pref.setValue(value);
            if (summary == null) {
                pref.setSummary(pref.getEntry());
            } else {
                summary.run();
            }
            return false;
        });
    }

    /**
     * 滑块。
     *
     * <p>只在<b>松手</b>时落盘（{@code updatesContinuously = false}）——
     * 拖动过程中每一格都写一次配置、再推给正在显示的悬浮窗，是没必要的开销。</p>
     */
    private void bindSlider(String key, int min, int max, int current,
                            String unit, IntSetter setter) {
        SeekBarPreference pref = findPreference(key);
        if (pref == null) {
            return;
        }
        pref.setPersistent(false);
        pref.setMin(min);
        pref.setMax(Math.max(min, max));
        pref.setValue(Math.max(min, Math.min(max, current)));
        pref.setUpdatesContinuously(false);
        pref.setOnPreferenceChangeListener((preference, newValue) -> {
            setter.set((Integer) newValue);
            return true;
        });
    }

    /**
     * 枚举选项的显示名。
     *
     * <p>有字符串资源的用资源 —— 英文界面就是靠这个；没有的回落到
     * {@link SettingsRegistry} 里那份中文（分辨率、fps 这类本来也不需要翻译）。</p>
     *
     */
    private String[] localizedNames(SettingSpec spec) {
        String[] names = spec.displayNames();
        int[] res = spec.nameResIds();
        for (int i = 0; i < names.length; i++) {
            if (res[i] != 0) {
                names[i] = getString(res[i]);
            }
        }
        return names;
    }

    private void onClick(String key, Action action) {
        Preference pref = findPreference(key);
        if (pref == null) {
            return;
        }
        pref.setOnPreferenceClickListener(preference -> {
            action.run(preference);
            return true;
        });
    }

    /**
     * 打开一个自带界面的子项（权限设置这类）。
     *
     * <p>两栏布局下只换右栏，左栏的分区列表留着 —— 进了二级界面还看得见
     * 自己在设置的哪一块。外壳不在时（理论上不会）退回整屏替换。</p>
     */
    /** @param titleRes 这个二级界面叫什么；标题区显示它，返回时自动退回上一层的名字 */
    private void openFragment(androidx.fragment.app.Fragment fragment, int titleRes) {
        if (getParentFragment() instanceof SettingsShellFragment) {
            ((SettingsShellFragment) getParentFragment())
                    .openDetail(fragment, getString(titleRes));
            return;
        }
        if (getActivity() == null) {
            return;
        }
        getActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment, fragment.getClass().getName())
                .addToBackStack(null)
                .commit();
    }

    private void toast(String message) {
        if (getContext() != null) {
            Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
        }
    }

    /** 视野角度的取值范围，避免这里再写一遍数字。 */
    private static final class FisheyeProjectionBounds {
        static final float MIN = com.kooo.evcam.zeekr.FisheyeProjection.MIN_FOV_DEGREES;
        static final float MAX = com.kooo.evcam.zeekr.FisheyeProjection.MAX_FOV_DEGREES;
    }
}
