# Changelog

Notable changes only, newest first. Each version's section becomes the body of its
[GitHub release](../../releases) and the text of the in-app update dialog.

Alpha sections: one line per change, what changed and nothing else. Beta and stable
sections: written for users, reviewed before release. Why a change was made lives in the
commit message, not here.

## [2.12.3] - 2026-10-15

### Fixed

- **Signalling right no longer flashes the left picture first.** The picture was hidden between
  signals by making its window see-through, which left the last picture (the other side's) in the
  window; the next signal showed that leftover for a moment before the new one was drawn. The picture
  now fades out when it is hidden, so nothing is left behind, and fades in when it comes back.

### New and improved

- **The side view fades in and out** (about 0.13 s in, 0.16 s out) on the HUD and the screen pop-up,
  instead of appearing and disappearing in one frame. Switching straight from one side to the other
  fades the new side in.
- The diagnostics report now notes, for each pop-up, which side was chosen and where the window had
  been parked.
- **Defaults now follow the owner's settings** (see `docs/owner-config.md`): side view on screen and
  HUD, HUD picture 49 % tall / shape 194 / contrast 220 / edge fade 6, stay open 500 ms, mirrored,
  start on boot, info bar and licence plate on, floating button locked and tap = record, and so on.
  A fresh install, or a setting you never changed, comes up like that; settings already saved on a
  car keep their value.
- **Signal scan (developer option) listens on one more path.** Some of the car's values arrive only
  through a second callback the scan never recorded; it now logs them (`C:` lines) and notes which
  callback paths the car uses. For the blind-spot light investigation.

## [2.12.2] - 2026-10-15

### Fixed

- **The camera no longer breaks when the car flips between day and night twice within a few
  seconds.** The second flip could drop the camera the recording was using from the app's
  bookkeeping; the next thing to ask for the camera (the HUD side view) then opened a second copy,
  and the two kept knocking each other off the surround camera. The recording stopped, the main
  screen couldn't start the camera, and the side view flickered and said *No live picture*. The
  app now keeps using the one camera it already has.
- **The HUD picture moves to the other side when you switch the indicator straight from right to
  left (or left to right).** It used to stay where the first indicator had put it and only change
  the camera view.
- **The HUD side view now shows below 30 km/h even when the car pops up its own 360 view.** At low
  speed the car's 360 view, its small side window and park assist all come on together with the
  indicator, and the HUD was still stepping aside for two of the three. They are only on the
  screen, so the HUD now ignores all three. It still steps aside for reverse.

## [2.12.1] - 2026-10-14

### Fixed

- **The HUD side view now shows below 30 km/h.** At low speed the car pops up its own side-view
  window on the screen, and the HUD used to step aside for it like the screen pop-up does. That
  window is only on the screen, so the HUD no longer waits for it. The HUD still steps aside for
  reverse, the car's 360 view and park assist.

### New and improved

- **The HUD picture follows the signal.** Left indicator, picture on the left of the HUD; right
  indicator, picture on the right. *Position across the HUD* is now *HUD picture distance from the
  edge*: the same distance from the left edge or the right edge (0 at the edge, 50 the middle).
- **The HUD picture is no longer mirrored by default.** It reads as the camera sees it, like the
  screen pop-up. *Mirror the HUD picture like the door mirror* is still there for those who want it.
- **HUD picture contrast.** The HUD is a projection: every grey lights up, so the camera's picture
  looked washed out. *HUD picture contrast* (Settings → Super mirror → Turn-signal side view →
  HUD picture) pushes the darker half of the picture towards black; default 150, 100 is the camera's
  own picture. The HUD picture also loses the thin light frame, which showed as a ring of light.
- **HUD picture dims at night.** When the car is in night mode the HUD picture is dimmed to the
  share set in *HUD picture brightness at night* (applied on top of *HUD picture opacity*; default 60,
  100 turns it off). It follows the car's own day/night signal; if that cannot be read, the picture
  stays at the day brightness.
- **HUD picture edge fade.** The picture keeps the shape set under *HUD picture shape*, but its four
  edges now fade to black, which blends into the road on a HUD. *HUD picture edge fade* (same
  place) sets how far the fade reaches, as a share of the shorter side; default 15, 0 is the old
  hard edge.

## [2.12.0] - 2026-10-14

### New and improved

- **Side view on the HUD.** *Show side view on* (Settings → Super mirror → Turn-signal side view)
  chooses the screen (as before), the HUD, or both. The picture appears on the HUD at any speed; only
  the screen pop-up waits for *Show from speed*. *HUD picture* sets its size, position and opacity,
  and the picture, aim and stay-open settings are shared with the screen pop-up. The HUD is the extra
  1440×480 screen; if it isn't found, or its window can't open, the screen pop-up is used instead.
- **Mirror like the door mirror.** The HUD picture is flipped left-to-right by default, so a car
  coming up from behind enters from the outside edge as it does in the door mirror. The screen
  pop-up stays as the camera sees it. Each has its own switch under its picture settings.
- **Diagnostics list the HUD:** which screen was picked and how, where the side view is set to show,
  the HUD window's last state, and each screen's flags.

### Fixed

- **Send to phone no longer shows an address the phone can't open when the head unit isn't on a
  network.** With Wi-Fi and the hotspot both off, the QR code used to carry one of the head unit's
  internal addresses (for example 192.168.55.15), and the *Connect to a network first* message never
  appeared. Now it says the head unit isn't on a network and lists the network links it found.
- The *waiting* and *hasn't reached the head unit* messages now say which network link the address
  belongs to (for example `192.168.5.78 · wlan2`), and the second one suggests turning off the phone's
  mobile data.

## [2.11.5] - 2026-10-11

### New and improved

- **Send to phone shows what is happening:** *Waiting for your phone*, *Phone connected*, *Sending*,
  *Sent* (for photos and videos: *On your phone*, with a reminder to long-press and save). If the phone
  hasn't reached the head unit after 20 seconds, it says so and what to check.
- **Diagnostics list the recent Send to phone attempts:** which address the QR code showed, whether the
  phone's request arrived, and how the attempt ended.

### Fixed

- **Send to phone offers only addresses your phone can reach.** The head unit has a dozen internal
  network addresses (links to the car's other modules) that a phone can never open; the QR code used
  to cycle through all of them. Now it offers the head unit's Wi-Fi, hotspot or USB-tethering address
  (and everything only if none of those is found).

## [2.11.4] - 2026-10-10

### New and improved

- **Floating record button:** the icon (ring, dot and stop square) is a little bigger, closer to the car's
  own buttons.
- **Record all vehicle signals** now also records the car's sensor events that the app doesn't use yet,
  and reads the blind-spot-like signals twice a second, in case the car only answers when asked. Same
  switch, same Diagnostics section.

## [2.11.3] - 2026-10-10

### New and improved

- **Record all vehicle signals** (Settings → Developer options). While on, the app listens to every signal the
  head unit offers and logs each change with time, speed and name, to find signals not mapped yet, such as
  the blind-spot warning. Read only. Results are in Diagnostics under "Signal scan". Turns itself off after
  3 hours.

## [2.11.2] - 2026-10-09

### New and improved

- **Turn arrow on the side view.** The pop-up shows a green arrow in its top corner on the side you are
  signalling (top left for left, top right for right). It turns green and grey in time with the car's
  indicator.
- **Floating record button looks like the car's own buttons.** Smaller dark icon with the same line
  weight, no shadow. While recording the button stays grey; only the ring and the stop square turn red.
- **Send to phone in Diagnostics** no longer needs developer options.

## [2.11.1] - 2026-10-09

### New and improved

- **Save a clip of any length** in playback, up to 10 minutes. Tap **Save clip**, choose *Choose a range
  starting here*, move to where it should end and tap **Save to here**. *15 seconds before and after*
  is still there. Clips are copied without re-encoding, so they keep the original quality and save in
  seconds.

### Fixed

- **No more gaps in the video on slow USB drives** (from dts88's 2.10.3). Writing to the drive now has
  its own thread, so a slow drive no longer drops picture, including the 1–2 second gap at the start of
  each new one-minute file. If the USB drive drops out, the last seconds are now saved to another drive;
  that never worked before.
- **The floating record button stays red while recording** after the screen switches between day and
  night (from dts88's 2.10.2), and its timer no longer jumps when the car corrects its clock.
- **Deleting recordings in playback no longer freezes the screen.**
- **Starting a recording no longer briefly freezes the screen.**

## [2.11.0] - 2026-10-08

The first stable release of this fork, with everything since dts88's last stable release (2.0.0),
betas included.

### Upgrade notes

- When the installer finishes, tap **Back** at the top left, not **Open**. Otherwise later installs
  and updates can fail.
- **Recording follows the driver**: it starts when you sit in the driver's seat or shift out of P,
  and stops when you leave the car. Turn either off in Settings → Recording.
- **One recording quality**: 30 fps at about 14 Mbps, around 105 MB a minute while driving. The
  presets moved to Developer options and your profile switches over on its own. To keep more
  history, raise the video storage limit (Settings → Storage).
- **Lock footage on hard braking** is on by default and uses at most 10% of the recording space.
  "Lock footage on horn", which could never be turned on, is gone.
- Updates come from this repo. Turn on *Include beta releases* under Settings → Updates to get
  betas too.

### New and improved

- **Turn-signal side view** (Settings → Super mirror, off by default): signalling pops up that
  side's camera and closes after the signal, whether or not you're recording.
- **Recording starts as soon as you get in**, instead of up to two minutes later.
- **Smoother video**: 30 fps instead of 15. After 5 seconds stopped it drops to 15 fps to save
  space, and goes back to full rate as soon as you move.
- **Lock footage** so loop recording never removes it: by hand in playback, by flashing the high
  beams, or automatically on a hard stop. Each lock keeps 10 seconds either side.
- **Playback by drive**, with the distance driven and dots for hard braking and flashes. Swipe
  between cameras, and **Save clip** keeps 30 seconds as a normal video in DCIM/EVCam_Clips.
- **The car's own views come first**: the super mirror and floating button step aside while the
  reversing camera, 360 view or park assist is showing, and the app never takes the camera from
  them. A picture that stops is blanked or marked "No live picture" instead of looking live.
- **Security and privacy**: other apps can no longer start or stop recording, the phone-sharing link
  uses a longer key and closes when you leave the screen, the accessibility service no longer reads
  screen content, and diagnostics contain only the app's own logs and no number plate.
- **Night mode matches the car**, and **tidier settings**: fine adjustments moved one level down.
- Steadier camera handling: the app waits for a steady 360 picture, backs off when the car's camera
  is stuck, resumes interrupted recordings and no longer leaves empty video files.
- Redesigned driving info bar, Sentry Mode awareness, and photos saved to the USB drive only (from
  dts88).

### Experimental

- Vehicle status panel on the main screen (off by default) and System info (Settings → System).

## [2.10.7-beta] - 2026-10-08

- Night mode on the main screen matches the car too: the area around the camera picture is black
  instead of a grey panel, and the buttons are dark grey like the car's own.
- Night mode backgrounds are now pure black, like the car's screens.

## [2.10.6-beta] - 2026-10-08

- Night mode matches the car's own settings more closely: the page is almost black, and the setting rows
  and the selected menu item are a darker grey instead of standing out as light grey blocks.

## [2.10.5-beta] - 2026-10-08

- Recording starts right away when you get in, instead of after about two minutes. The camera
  service refuses the 360 camera to an app in the background unless the app's camera service is
  running, and that service only started once recording had begun, while recording waited for the
  360 camera. Nothing moved until something else woke it up. The service now starts as soon as
  recording is waiting for the camera.
- The turn-signal side view now also works in those first two minutes. While recording was waiting,
  the side view held back from taking the camera and skipped starting the camera service too. It now
  starts the service either way.
- When the 360 camera sends no picture, the main screen says "No picture from the surround view"
  instead of showing a blank area with the Front, Rear, Left and Right labels floating over it.
- The hide-to-background button has a new icon. The old down-arrow looked like a download.
- Recording settings are grouped under Stream, Automatic recording, and Photos and stamps. The
  descriptions for starting and stopping recording with the driver are shorter.
- Descriptions in light mode are slightly darker and easier to read.
- The side view pop-up has rounded corners and a thin frame, so it looks like the car's own 360
  view instead of two plain boxes.
- Settings no longer has a status bar along the bottom, like the car's own settings. The
  recording status is still on the main screen.
- Shorter menu names in Settings in English and Malay (Main screen, Developer, Updates), so they
  fit on one line.

## [2.10.4-beta] - 2026-10-08

When the car's 360 camera service gets stuck (the feed crawls at about one frame per second and every
attempt to start recording fails), the app now backs off instead of retrying all morning:

- Recording only starts on a steady 360 feed, at least 3 frames per second. A feed that trickles in
  no longer counts as healthy, so the app keeps waiting instead of failing three starts in a row
  and giving up.
- The app stops poking a stuck camera. Pauses between reconnects grow from 15 seconds to 30, 60 and
  then 2 minutes, and the camera watchdog now really stops after a few rounds. Before, every
  successful reopen reset both, so it kept retrying every 20 seconds or so for as long as the app
  was open. The camera counts as recovered only after 10 seconds of steady frames.
- The app listens to the camera service from the moment it starts, so the 2.10.3 safeguards (don't
  start on a camera the car has dropped, wait for the car's own cameras to go quiet) also work
  right after the app launches.
- The turn-signal side view no longer depends on recording. It was blank unless a recording was
  running, and turning recording off while driving took its picture away: the camera is only available in the
  background while the app's camera service is running, and only recording started it. The side view
  now starts it when it takes the camera and lets it go a few seconds after it is done, unless a
  recording or Keep running in background needs it. A notification shows while it runs.
- A recording that fails to start no longer leaves empty 0 B video files.
- Diagnostics name this stuck state and show who holds each camera from the start. When the camera
  service refuses to open a camera ("disabled by policy"), they also record gear, speed and the app's
  state at that moment, and when it starts working again.

## [2.10.3-beta] - 2026-10-07

Fixes the 360 camera freezing after getting in (seen twice): recording started, then the camera
kept failing and restarting until the app was closed.

- When the main screen is in the background, its hidden preview no longer stays attached to the
  360 feed. A hidden preview takes no frames and could stall the whole feed while recording was
  starting. A hidden frame receiver keeps the camera running instead.
- When you get in, recording waits until the screen has been on for 10 seconds and the car has
  finished with its cameras (face recognition) before starting, at most 30 seconds.
- Recording no longer starts on a 360 connection the car has already dropped.
- After three camera errors within two minutes, the app leaves the camera alone for 15 seconds
  before reconnecting, instead of retrying every few seconds.
- The turn-signal side view waits while the camera is recovering or recording is starting.
- The floating record button turns Zeekr orange while the app is retrying after a camera problem.
- Diagnostics say whether recording started because you sat down, shifted out of P, or the app
  came up while driving.

## [2.10.2-beta] - 2026-10-07

Recording follows the driver (Settings → Recording, both on by default):

- **Start recording when you get in**: sitting in the driver's seat with the car in P starts
  recording, even if you don't drive off. Shifting out of P also starts it, and so does the app
  coming up while you're already driving (you set off before it was ready, or it restarted
  mid-drive), so Record on launch can be turned off. The app doesn't need to be open. Not if you
  stopped recording yourself on this trip.
- **Stop recording when you leave the car**: in P, once the driver's seat has been empty for 30
  seconds, or Sentry Mode arms after you lock, recording stops and the cameras are free for Sentry
  Mode. Sitting in the car never stops it. Until you sit back in the driver's seat or shift out of
  P, nothing restarts it by itself, even when Sentry Mode wakes the screen.
- It stops properly before the head unit sleeps: when the screen turns off in P while recording,
  the app keeps the head unit awake for up to a minute, and stops and finishes the file as soon as
  the driver's seat is empty (no 30-second wait once the screen is off). If you stay in the seat,
  it lets the head unit sleep after that minute and nothing changes.
- If the car's signals can't be read, the earlier screen-off rules apply.

## [2.10.1-beta] - 2026-10-07

Brings this fork up to dts88's 2.10.0-alpha. Everything from this fork stays: the turn-signal
side view, and updates from this repo.

### New from dts88 (since 2.0.1-beta)

- Lock videos and photos so loop recording never removes them, by hand in playback or
  automatically when you flash the high beams.
- Driving info bar redesigned; choose what it shows in Settings → System → System info.
- Sentry Mode is read by the app: it shows on the info bar and decides whether recording carries
  on with the screen off. The record button says what will happen when the screen goes off.
- Vehicle status panel on the main screen (experimental, off by default).
- All interface text reviewed and reworded in Chinese, English and Malay.
- Recording start and stop reworked into one path, with several stop/start bugs fixed.
- Photos are saved to the USB drive only. The info bar no longer asks for location permission.

## [2.10.0-alpha] - 2026-10-06

Version jump: the whole interface text was reviewed and reworded in the 2.1.x alphas; this build finishes it and reworks the recording start/stop.

- Super mirror, floating button, System info and vehicle-signal texts reworded in all three languages; System info is now called System info in English and Malay too.
- The System info status line is translated and no longer shows raw error text.
- "Camera in use" on the Super mirror no longer tells you to restart the head unit.
- When no camera starts recording, the notification and floating button no longer stay on recording: the app shows "Recording didn't start. Retrying…" and retries when the surround view is back, up to three times.
- A recording that starts while the screen is off now holds the wake lock from the start when Screen-off recording (keep awake) is on.
- Stopping right after starting no longer leaves a dead recording output on the cameras or stops the next recording; a stop during a MediaRecorder rebuild is no longer undone.

## [2.1.4-alpha] - 2026-10-06

- Photos are saved to the USB drive only, like videos; with no drive the shutter says so instead of saving to internal storage (developer options excepted).
- Turning on the driving info bar no longer asks for location permission; latitude and longitude show when the head unit already allows it.
- English: correct singular and plural forms, full stops on multi-sentence texts, and failure messages no longer show raw error text or "null".

## [2.1.3-alpha] - 2026-10-06

- Interface text reworded across the app in all three languages, following one terminology and style guide (docs/ui-text-style.md).
- Turning developer options off now really switches their features off; turning them back on restores the previous settings.
- Removed the extra cleanup rule that deleted 20% of files on internal storage below 3 GB; storage caps are the only cleanup rules.
- "Deleting oldest recordings" now only shows when recordings are actually being deleted.
- Settings: Image adjustment opens its window again; Video folder shows when no USB drive is found; the stream profile editor remembers the chosen quality and marks cameras tuned by hand; the photo size row shows the size actually saved.
- Recording stats and the debug overlay follow the setting without reopening the app; the overlay shows the pipeline in use.
- The info bar shows "—" for missing data, as the System info page does.
- Developer tools (permissions, repair, archive) are translated.
- Ending a recording now actually frees the video encoder's graphics resources, and no longer races the last frame being drawn.

## [2.1.2-alpha] - 2026-10-04

- The app name and version, and the plate number when it is turned on, are now on every recording, including the cabin cameras, and on every photo, whether or not the timestamp is on. The timestamp switch now only controls the date and time.
- Storage cap dialogs now show their title and explanation.
- Storage location shows "USB drive (not found)" instead of internal storage when the selected drive isn't plugged in.
- Clearer wording in recording, storage, Super mirror and floating button settings, in all three languages.

## [2.1.1-alpha] - 2026-10-04

- Clearer wording for recording, storage and notification messages and the first-run guide, in all three languages.
- "No camera available" now has its own message instead of the surround-stream one.

## [2.1.0-beta] - 2026-10-04

Upgrade from 2.0.0.

- Driving info bar: refined design, integration and display. There's a little easter egg in it, see if you can find it.
- Lock videos and photos, by hand or automatically. Locked videos and photos are marked and are never removed by the app's loop recording.
  - Including flash-to-pass: flash the high beams to lock the current recording automatically.
- The record button explains more clearly what happens.
- Improved stability.

## [2.0.17-alpha] - 2026-10-04

- Lock footage: new option to lock automatically on flash-to-pass (off by default): every segment of every camera within 10 s before and after the flash is locked. A "lock on horn" option is shown but can't be turned on yet (the horn signal isn't readable).
- Car-signal reading during recording is now released when a recording fails to start.

## [2.0.16-alpha] - 2026-10-04

- Info bar cabin: empty seats are a darker grey, a seated passenger without a belt is red, belted is the light look; seats with unreadable belts show as no data instead of looking belted.
- System info: seat sensors, the turn indicator display and the brake pedal now bring their icons; every row says whether a tick shows as an icon (which one) or as text.

## [2.0.15-alpha] - 2026-10-04

- Easter egg: if a licence plate is set (Settings → Recording), the plate on the info bar's front view shows its digits in white (last 4 if longer).

## [2.0.14-alpha] - 2026-10-04

- Info bar front view redrawn as the 7X nose: two straight daytime running light strips with a dark middle, flat low/high beam lamps below them; high beam lights with a strong round glow. The separate low/high beam cell stays for now.

## [2.0.13-alpha] - 2026-10-04

- Info bar steering: the angle digits and the degree sign are drawn over the wheel with a background outline, so the ring and spokes break around them instead of crossing them.

## [2.0.12-alpha] - 2026-10-04

- Info bar: left turn, hazard and right turn are one cell; off is a grey outline, lit arrows are white with green light, hazard lights both arrows and a red nested double triangle (same mark on the vehicle status panel).
- Info bar: narrower steering (78), speed (172), cabin (110); rear view keeps its drawing at 106 wide and the front view matches it.

## [2.0.11-alpha] - 2026-10-03

- Info bar: choose what it shows by ticking items in Settings → System → System info. A ticked signal with an icon brings its whole icon; signals without an icon appear as text (name + value); what doesn't fit is left out. Defaults match 2.0.10.
- Unverified signals can only be ticked by developers; the "Activate all items" switch is removed.
- Hands-on-wheel cell removed (no data source).
- Driver assistance: the four verified badges now show; lane departure and blind spot are crossed out on their own.

## [2.0.10-alpha] - 2026-10-03

- Info bar: Sentry Mode cell added right of the stock 360 cell; the ACC and lane centering cells are gone.
- Settings → Interface: Correction strength removed; fisheye correction is always full strength.

## [2.0.9-alpha] - 2026-10-03

- Lock footage (Settings → Storage, on by default): lock videos and photos in playback; locked files are never removed by automatic cleanup or plain delete.
- Video playback: Lock / Unlock for the files playing at this moment (all cameras), locked parts marked under the progress bar, sessions with locked files marked in the list.
- Photo playback: Lock / Unlock a whole photo group; locked groups marked in the list.
- If locked footage fills the space, recording stops and says so.

## [2.0.8-alpha] - 2026-10-03

- Vehicle status panel: now only the horn, flash-to-pass and hazard lights.
- Sentry Mode no longer has to hold for 2 s before it counts (the blink it guarded against was most likely a manual toggle).

## [2.0.7-alpha] - 2026-10-03

- Record button: while recording, a small line says what happens when the screen goes off.
- Settings → System → Keep recording when the screen goes off: shorter description.
- Sentry Mode has to hold for 2 s before it counts (it can blink on for a second while parked).

## [2.0.6-alpha] - 2026-10-03

- Sentry Mode status can now be shown anywhere it matters (SentryStatusView).
- Settings → System → Keep recording when the screen goes off: clearer description of how it works
  with Sentry Mode, and the row shows whether Sentry Mode is on right now.

## [2.0.5-alpha] - 2026-10-02

- Sentry Mode status is read for everyone (it decides whether recording can carry on with the screen off).
- Vehicle status panel: Sentry Mode (off, on, armed) takes the first cell; doors and seat belts
  are no longer on it.

## [2.0.4-alpha] - 2026-10-02

- Main screen: vehicle status panel (experimental, off by default).
- Settings → Interface → Vehicle status (experimental): a panel below Straighten on the main screen
  shows doors and seat belts, brake and throttle, driver assistance switches and the horn, with the
  info bar icons. The horn stays crossed out until its signal is found.
- Driving info bar: the hands-on-wheel cell moves next to the driver assistance badges.

## [2.0.3-alpha] - 2026-10-02

- Driving info bar: lamp cells reworked as agreed on the mock-ups; more adjustments to follow.
- Driving info bar: low and high beam share one cell; the direction of its four rays shows
  which beams are on.
- Driving info bar: a rear lamp group drawn from the 7X tail shows the rear position lamps,
  stop lamps, rear fog lamps and reversing lamps; the separate fog cell is gone.

## [2.0.2-alpha] - 2026-10-01

- Driving info bar: the number in the steering wheel is the wheel's angle in degrees.
- About: thanks now name the Singapore Zeekr Group and add members of the Malaysian, Australian
  and Chinese owner communities for their suggestions, insights and support.
- The About page comes in Chinese and English only: the Chinese interface shows Chinese, every
  other language shows English.
- Driving info bar: the high beam cell also lights while you flash the high beams, for at least
  half a second so a quick flash still shows in the recording.
- Driving info bar: the steering wheel turns by its real angle and in the right direction (up to
  about 510° each way, yellow to the left).
- Driving info bar: the brake bar fills at a full press; it used to stop at about a fifth.
- Vehicle info page: Sentry Mode shows on, armed or off.
## [CAMCORDER 2.0.7-beta] - 2026-10-02

- Turn-signal side view: **View width** now defaults to 80°, about what Honda LaneWatch shows (a
  normal mirror is about 20°), so cars stay large enough to judge distance. This resets any value
  you set before; you can still widen it up to 180°.

## [CAMCORDER 2.0.6-beta] - 2026-10-02

Turn-signal side view:

- The pop-up is a wide rectangle instead of a square, so it shows more to the left and right.
  New **Pop-up shape** slider (width ÷ height, 100 = square, default 180). The size slider now
  sets the height; the width is capped at half the screen so the two pop-ups still meet in the
  middle.
- **View width** goes up to 180°. The straightening now spreads the view evenly from side to
  side (like a phone panorama), so wide settings don't smear the edges; vertical lines stay
  straight and horizontal lines curve a little. Default 120° (was 90°); a value you already set
  is kept.

## [CAMCORDER 2.0.5-beta] - 2026-10-01

Turn-signal side view, after the first drive:

- The pop-up is fully solid. It was slightly see-through: Android limits pop-ups that let taps
  through to 80% opacity, so while it shows it now takes taps itself (only for the second or two
  it is up; while hidden it still lets them through).
- **Aim back** and **Aim up** now turn the view (in degrees) instead of shifting a crop, so it can
  look much further back, up to 80°. **View width** replaces Zoom. Defaults: 90° wide, 50° back,
  15° up. Needs *Straighten picture* on. Earlier Zoom / Aim values are not carried over.
- **Stay open after the signal** is set in milliseconds (0–3000, default 1000). The old slider
  only had four positions and didn't move on the car's wide screen.

## [CAMCORDER 2.0.4-beta] - 2026-10-01

- Turn-signal side view: stays open for 1 second after the signal goes off by default (was 0).
  If you already moved the *Stay open after the signal* slider, your setting is kept.

## [CAMCORDER 2.0.3-beta] - 2026-10-01

A hobby fork of dts88's app, vibe coded with an AI assistant; see the README. This version
improves the turn-signal side view.

### Turn-signal side view

- Fixed: the pop-up could stay black when the camera wasn't already running.
- The left and right pop-ups now meet at the middle of the screen.
- **Straighten picture** (on by default): corrects the fisheye curve in the pop-up. Recordings are
  not affected.
- **Instant pop-up** (on by default): in D, the picture is kept ready in the background so it is
  there as soon as you signal. The camera stays on while driving.
- **Stay open after the signal**: 0–3 seconds, default 0.
- **Zoom, Aim back, Aim up**: point the pop-up at the blind spot. The default (1.6× zoom, mostly back,
  a little up) is a best guess at which way each camera faces; drag the other way if it is wrong.
- Pop-up size and height on screen are adjustable.

### This fork

- Check for updates now looks at this repo's releases (FerixzTanz/CAMCORDER), so updating no
  longer replaces this version with dts88's. Turn on *Include beta releases* to get them.
- The About page links here and says this is a personal fork of dts88's app.

## [CAMCORDER 2.0.2-alpha] - 2026-10-01

- Turn-signal side view (off by default, Settings → Super mirror): signalling pops up that side's camera and closes it when the signal goes off; stock views (reverse, 360, side pop-up, park assist) take precedence; minimum speed adjustable, default 30 km/h.

## [2.0.1-beta] - 2026-10-01

Mainly bug fixes and driving info bar updates. Everything else is as in 2.0.0.

Small updates will follow often for a while. They only refine the driving info bar and leave
the main features alone, so there is no need to install every one.

### Since 2.0.0

- Driving info bar: the daytime running light cell shows the front light band as you see it,
  so it stays lit when the headlights are on.
- Settings: **Keep recording when the screen goes off** now says it needs the car's Sentry Mode.
- Video playback no longer shows the status strip under the picture: it showed today's settings
  and free space, not the clip's.
- The app is about 0.8 MB smaller: two unused images from the upstream project no longer ship
  in it.

Changes since 1.0.0, as in 2.0.0:

### Upgrade notes

- When the installer finishes, tap **Back** at the top left, not **Open**. Otherwise the head
  unit's installer gets stuck and later installs or updates fail.
- The "Custom" stream profile is gone. If you used it, the app switches to Zeekr 7X (surround
  composite).
- **Keep recording when the screen goes off** and **Timestamp overlay** are now on by default.
  Recording with the screen off needs the car's Sentry Mode, which keeps the head unit awake;
  without it the car sleeps and recording pauses until it wakes.

### New and improved

- Malay interface.
- Fisheye correction (**Straighten**) on every screen: the main screen, photo playback and
  video playback.
- Recording can cover the surround view alone, or the surround view plus the cabin cameras,
  with more detailed camera, quality and frame-rate options (Settings → Recording).
- Video playback shows all cameras in sync. Tap one to enlarge it, tap again to go back.
- Photo playback uses the same layout as the main screen. One tap enlarges a view.
- Super mirror button mode: tap the top, bottom, left or right of the window to switch to the
  front, rear, left or right camera.
- The super mirror shows "tap to resume" when its picture stops, and reconnects by itself
  after the car wakes.
- An interrupted recording, for example when the USB drive drops out, resumes by itself.
- Improved stability and smoother operation.

### Experimental

- Driving info bar (off by default, Settings → Recording): a strip under the recorded video
  with vehicle state such as turn signals, steering, gear, pedals, speed, doors, lights,
  odometer and position. Only items verified on the car are live; the rest are crossed out.
- Vehicle info (Settings → System): the vehicle signals the head unit exposes and their
  current state.

## [2.0.0] - 2026-09-30

Changes since 1.0.0.

Small updates will follow often for a while. They only refine the driving info bar and leave
the main features alone. Each one is a stable release, so there is no need to install every one.

### Upgrade notes

- When the installer finishes, tap **Back** at the top left, not **Open**. Otherwise the head
  unit's installer gets stuck and later installs or updates fail.
- The "Custom" stream profile is gone. If you used it, the app switches to Zeekr 7X (surround
  composite).
- **Keep recording when the screen goes off** and **Timestamp overlay** are now on by default.
  Recording with the screen off needs the car's Sentry Mode, which keeps the head unit awake;
  without it the car sleeps and recording pauses until it wakes.

### New and improved

- Malay interface.
- Fisheye correction (**Straighten**) on every screen: the main screen, photo playback and
  video playback.
- Recording can cover the surround view alone, or the surround view plus the cabin cameras,
  with more detailed camera, quality and frame-rate options (Settings → Recording).
- Video playback shows all cameras in sync. Tap one to enlarge it, tap again to go back.
- Photo playback uses the same layout as the main screen. One tap enlarges a view.
- Super mirror button mode: tap the top, bottom, left or right of the window to switch to the
  front, rear, left or right camera.
- The super mirror shows "tap to resume" when its picture stops, and reconnects by itself
  after the car wakes.
- An interrupted recording, for example when the USB drive drops out, resumes by itself.
- Improved stability and smoother operation.

### Experimental

- Driving info bar (off by default, Settings → Recording): a strip under the recorded video
  with vehicle state such as turn signals, steering, gear, pedals, speed, doors, lights,
  odometer and position. Only items verified on the car are live; the rest are crossed out.
- Vehicle info (Settings → System): the vehicle signals the head unit exposes and their
  current state.

## [1.80.0-alpha] - 2026-09-30

- Info bar: auto hold lights only while the car is standing still.
- Vehicle info page: dark labels now read "consistent in on-car tests (still
  cross-checked)"; every signal is an experimental finding.
- Vehicle info page: Sentry Mode on / off (seen once, shown as unverified).

## [1.79.0-alpha] - 2026-09-30

- Info bar: auto hold lights while the car is actually being held (lab-confirmed holding
  state), and the fog cell follows the rear fog lamp; both cells are live for everyone.
- Daytime running lights confirmed as read; the cell stays as it is.
- Vehicle info page: auto hold holding, indicator display, stock view pop-up, mirror
  reverse tilt (both sides) and day/night added; light switch shows the low-beam position.

## [1.78.0-alpha] - 2026-09-30

- Signal table has three levels: confirmed, provisional (usable, details pending) and
  unverified; the info bar activates confirmed and provisional cells by default.
- Steering, pedals and daytime running lights are provisional, so those three info-bar
  cells are live for everyone.
- Vehicle info page shows the three levels by label tone.

## [1.77.0-alpha] - 2026-09-30

- Signal table aligned with the lab handbook: pedal depths and daytime running lights
  count as unverified until their range and daytime reading are measured (those two
  info-bar cells are crossed out by default); high beam, odometer, range, battery,
  temperatures, AEB, lane keeping and rear collision warning count as verified.
- Forward collision warning read from its sensitivity setting.
- Vehicle info page: position lamps, light switch position, battery temperature, lane
  change assist, automatic lane change and door open warning added; indicator status
  shows hazard.

## [1.76.0-alpha] - 2026-09-30

- Info bar always lays out every cell; cells not verified on the car are drawn crossed
  out instead of being left off.
- Developer switch renamed "Activate all items": it turns the unverified cells live so
  they can be checked on the car.
- Speed, odometer and position draw the slash when they have no data, like the icons.

## [1.75.0-alpha] - 2026-09-29

- Info bar shows only cells whose signals are verified on the car by default; the three
  per-cell switches are gone, replaced by "Show all driving info" (developer mode only).
- Auto hold is no longer lit from the auto-hold setting switch; the cell stays empty until
  the holding state is found.
- Throttle depth counted as verified.
- Steering icon rotation scale is one constant, waiting for lock-to-lock data.

## [1.74.0-alpha] - 2026-09-29

- Speed: the sensor reports m/s; converted to km/h (×3.6) for the info bar and the
  vehicle info page.
- Hazard lights taken from the indicator status (3); the dedicated hazard signal, which
  never reads, removed from the table.
- Gear N recognised.
- Vehicle info page: frunk, tailgate and sunroof shade added.

## [1.73.0-alpha] - 2026-09-29

- Vehicle signals now come by subscription from the head unit's vehicle interface (function
  watcher plus sensor listeners, read once after registering, reconciled every 3 s); float
  sensors still read every 200 ms.
- Signal table (`telemetry.Signal`) is the single list of what is read and how it decodes;
  the info bar is derived from it.
- Info bar mapping updated: turn signal from the steady indicator status; driver door and
  driver belt placed by the car's driver side; door zones corrected.
- Settings › System › Vehicle info (experimental): every known signal with its current
  state, grouped; reading starts when the page opens and everything is released when it
  closes.

## [1.72.0-alpha] - 2026-09-29

- Info bar v3: icons redrawn to survive video compression (strokes 6 px and up, solid fills,
  no translucency, no dashes; unknown = dark fill with a bright slash); larger numbers
  (steering 32, pedals 30, odometer 28, position 26, badges 20); steering angle centred on
  the digits with the degree sign to the right, yellow when turned left, white when right,
  no sign; brake bar red, throttle bar green; daytime running lights drawn from the 7X front
  (body outline, Stargate band, emblem, the two thin daytime lines below the band, lit with
  a glow). Cell widths rebalanced, gap 12.

## [1.71.0-alpha] - 2026-09-29

- Driving info bar, second pass on the design: seat belts moved into the cabin cell
  (top-view car, four doors, five seats: two in front, three behind, an unbuckled seat in
  red); brake and throttle are one cell with two horizontal bars, brake above, throttle
  below, the depth in percent to the left of each; the four lamp icons differ by their rays
  (fan for daytime running, slanted for low beam, straight for high beam, slanted with a
  wave for fog); icons are outlines when off and filled when on. New cells: hands on the
  wheel (no reading found on the car yet, shown as no data) and six safety-assist switches
  read from the car (AEB, forward collision warning, lane departure warning, lane keeping
  aid, blind spot assist, rear collision warning). Position is shown on two lines.

## [1.70.0-alpha] - 2026-09-29

- Driving info bar: a new cell shows whether the car's own 360 view is on screen (a car
  with four arcs; lit while the stock view is showing). It is read from the ECARX function
  the lab verified (2 normally, 1 while the stock view is up in reverse) and sits right after
  the driving-assist cells, with a high priority, since the stock view is what takes the
  cameras away from this app.

## [1.69.0-alpha] - 2026-09-29

- **The driving info bar reads the car through ECARX's in-car API**, the route
  zeekr-shortcut-lab verified on the 7X inside the App Lab container: `Car.create`, then
  the function and sensor managers, read every 200 ms without any vehicle permission. Turn
  signals (with a 1.5-second hold across the blink, both sides meaning hazard), gear, brake
  and throttle depth, steering angle, speed, odometer, doors per zone, seat belts, low and
  high beam, daytime running and fog lights, auto hold and lane centering now come from the
  car; position still comes from the location service, which also supplies speed only when
  the car does not. The first round of readings is written to the black box. The
  `android.car` source added in 1.68.0 is removed: it cannot work in this container.
- Verified on the car so far (by the lab app): turn signals, gear P/R/D, brake, driver's
  door, low beam, daytime running lights, auto hold. Speed and steering units, the other
  doors' left/right assignment, seat-belt values and lane centering are read but not yet
  confirmed; there is no known reading for ACC.

## [1.68.0-alpha] - 2026-09-29

- **Driving info bar under the recorded video (experimental, off by default).** Settings →
  Recording → "Driving info bar" adds a 100-pixel strip below every recorded stream, in the
  app's dark grey, showing vehicle state as icons, numbers and bars only: turn signals,
  hazard lights (red triangle), steering wheel (rotates with the angle, degrees in the
  middle), gear, throttle and brake (pedal icon plus a bar), speed, auto hold, ACC, lane
  centering, doors, seat belts, daytime running, low beam, high beam and fog lights,
  odometer, and latitude/longitude. Sub-switches turn speed, the pedals and the steering
  wheel off individually. A signal that cannot be read is drawn dimmed with a slash, never
  as "off". Narrower streams keep the higher-priority cells and drop the rest.
- Where the signals come from: the vehicle property service (`android.car`, read by
  reflection) and the location service (position, and GPS speed when the car gives none).
  On this head unit the container is known to refuse vehicle properties, so most cells are
  expected to show "no data" until another route exists; what each source could and could
  not read is written to the black box when a recording starts. The app now declares the
  location permission and asks for it when the bar is switched on.
- Playback knows the strip: tap-to-enlarge and fisheye correction treat only the picture
  above it as the 2×2 grid; the strip is shown as recorded. With the bar on, recording uses
  the MediaCodec path (like the 2×2 grid, it needs GL to compose the frame).
- Releases are drafts from now on: only the repository owner can see and download them,
  and the in-app update check no longer sees new versions.

## [1.67.0-beta] - 2026-09-29

Changes since 1.0.0.

### Upgrade notes

- When the installer finishes, tap **Back** at the top left, not **Open**. Otherwise the head
  unit's installer gets stuck and later installs or updates fail.
- The "Custom" stream profile is gone. If you used it, the app switches to Zeekr 7X (surround
  composite).
- **Keep recording when the screen goes off** and **Timestamp overlay** are now on by default.

### New and improved

- Malay interface.
- Fisheye correction (**Straighten**) on every screen: the main screen, photo playback and
  video playback.
- Recording can cover the surround view alone, or the surround view plus the cabin cameras,
  with more detailed camera, quality and frame-rate options (Settings → Recording).
- Video playback shows all cameras in sync. Tap one to enlarge it, tap again to go back.
- Photo playback uses the same layout as the main screen. One tap enlarges a view.
- Super mirror button mode: tap the top, bottom, left or right of the window to switch to the
  front, rear, left or right camera.
- The super mirror shows "tap to resume" when its picture stops, and reconnects by itself
  after the car wakes.
- An interrupted recording, for example when the USB drive drops out, resumes by itself.
- Improved stability and smoother operation.

## [1.67.0-alpha] - 2026-09-29

- **Taking a photo opens the cameras when they are closed, and says what actually happened.**
  The floating button's photo action used to ask the main screen to take it, or launch the
  main screen and try once after 3 seconds; with the cameras closed (main screen in the
  background, no recording, super mirror off) nothing was taken, yet "Photo saved" was shown.
  Now the main screen's photo button and the floating button share one photo path: it registers
  as a camera user, so closed cameras open; a camera with no picture output (main screen in
  the background) gets an invisible output while the photo is pending; the shutter fires
  once the cameras deliver frames (up to 10 s, then with the ones that do). The message
  reports the real result: saved, saved for some cameras, or not taken and why. The cameras
  close again 1.5 s after the photo if nobody else needs them.
- Settings -> Storage: a note under the storage location. With Sentry Mode on after you
  leave the car, only the USB-A port stays powered; a drive on the Type-C port works too,
  because recording moves to the USB-A drive when the Type-C one loses power.

## [1.66.0-alpha] - 2026-09-28

- **One way to rebuild a camera's capture session.** Whenever a camera's outputs change
  (recording starts or stops, the super mirror attaches or detaches, the photo channel is
  dropped, a configuration attempt fails, a surface was abandoned) the request goes through
  a single entry that keeps at most one rebuild queued. The old session is closed first and
  the new one is built when the close completes (with one fallback if the close callback
  never arrives); a request that arrives while a configuration is in flight voids that
  attempt, which is closed and rebuilt once with the latest outputs, tracked by a
  generation number. Closing the camera, forcing a reopen and reconnecting after a
  disconnect all void in-flight work the same way. This replaces five separate entry
  points with their own delays, a "rebuild pending" flag and a separate fallback task.
  Fifth step of the consolidation plan, part three.

## [1.65.0-alpha] - 2026-09-28

- **One judge of whether the cameras are open: the registry of who needs them.** The main
  screen's preview, a recording (running or waiting for the surround view) and the super
  mirror each register their need; when someone registers, the cameras open, and 1.5
  seconds after nobody needs them they close. That single rule replaces the four places
  that used to decide (main screen going to the background, 1.5 s and 15 s after
  screen-off, the mirror service), the main screen's "reopen after returning from the
  background" timer and the recording coordinator's own open. The screen-off case works
  through it: the mirror and the paused main screen unregister, so the cameras close
  before deep sleep as before.
- The camera's photo capture and the picture-adjust window's changes are sent from the
  camera's own thread instead of the main thread, and the "front camera is mirrored" fact
  is read once when the camera opens instead of on the view thread.
- Two configuration slots naming the same camera no longer create a second, inert camera
  object ("secondary instance"); the second slot is left empty and the camera mapping
  note says so. Fifth step of the consolidation plan, part two.

## [1.64.0-alpha] - 2026-09-28

- **The foreground service lives as long as "keep alive" is on or a recording is running.**
  Stopping a recording now only switches its notification back to "running in the
  background" instead of stopping the service (which then restarted itself a second later,
  flashing the notification and re-running the start-up restore). Its self-restart after
  being killed or swiped away, the system's sticky restart, and the sticky flag of the
  super-mirror, floating-button and background-recording services all follow the one
  "keep alive" switch. The minute tick, the static broadcasts and the accessibility
  heartbeat start the service only when it is actually missing (they used to restart it
  every minute). The start-up restore runs once per service start, not twice. Sixth step
  of the consolidation plan, part two.
- Super mirror, button mode: the four direction buttons are gone. The window is split along
  its diagonals into four parts, top, bottom, left and right, which switch to the front, rear,
  left and right camera. Nothing is drawn on them and a tap works at any time, with no need
  to bring buttons up first; the tapped part flashes brand orange at 50% as confirmation.
  Dragging, swiping up and down for framing and pinching work as before. The window no
  longer has a larger minimum size in this mode.
  With "Front and rear only" on, the window is split into a top half (front) and a bottom
  half (rear) instead, so that setting applies to tapping as it does to swiping.

## [1.63.0-alpha] - 2026-09-28

- **One source of screen state.** Screen-off comes from the broadcast; while the screen is
  dark the app asks the system every two seconds whether it is lit again, which stands in for
  the screen-on broadcast that never arrives after deep sleep. Everything reacts in one fixed
  order: the screen-off wake lock, the recording rule (stop after 10 s when "keep recording
  when the screen is off" is off; on screen-on decide whether to resume), closing the cameras
  1.5 s after screen-off when nobody needs them, bringing the main screen back after
  screen-on if it had retreated because of screen-off, then the main screen's own 15-second
  retreat and the super mirror's unbind/rebind. Removed: the main screen's, the mirror
  service's and the wake-lock code's separate receivers and flags, the five "ask the system
  again" corrections, the foreground service's minute check of the screen, and the
  keep-alive receiver's own copy of "bring the main screen back". Screen-on also runs the
  normal restore (overlays, recording) as before. Sixth step of the consolidation plan,
  part one.
- After a recording stops while the screen is dark, the cameras are closed if nobody needs
  them, also when the main screen is not showing.

## [1.62.0-alpha] - 2026-09-28

- **One judge of whether a camera is alive.** The frame-age watchdog (8 s without progress,
  clock that excludes deep sleep, three attempts then a minute's rest, three rounds then
  stop) is now the only detector: on the first attempt it rebuilds the capture session, after
  that it reopens the camera, and it also covers an open request that never got an answer.
  Removed: the foreground service's 10-second "repair loop" (it reopened every closed camera
  unconditionally, reset the back-off each time and opened cameras nobody was using), each
  camera's own 2.5-second wall-clock stall check (after deep sleep it saw hours of "stall"),
  and the recording start's "force reopen all cameras" escalation (recording waits up to two
  seconds for stable frames, then starts with the cameras that are ready). A forced reopen
  already under way is no longer started a second time, and a closed camera drops its
  per-run flags (taken by another app, raised reconnect floor). Fifth step of the
  consolidation plan, part one; closing policy and session-rebuild coalescing come next.
- Indentation left behind by the 1.61.0 edits is repaired (whitespace only).

## [1.61.0-alpha] - 2026-09-28

- **One judge of whether recording is healthy: the recorder.** If nothing has been written to
  the file for 15 seconds, counted from the start or from the last write, the recorder reports
  it once and the coordinator stops the recording and resumes it through the usual path
  (nothing ever written counts as "no picture", a stall after writing as "cannot write"). In
  those 15 seconds the recorder's own repairs run as before: switching drives, rebuilding the
  encoder, quick retries every 5 s (the old cap of 60 retries is gone; the 15-second judge ends
  them). Removed: the camera layer's separate 15-second watchdog, the main screen's 10-second
  "no first data" watchdog and its own retry, and the recorder's 10-second "first write
  timeout"; the first write is now noticed as it happens instead of by polling the file size
  every half second. Fourth step of the consolidation plan.

## [1.60.0-alpha] - 2026-09-27

- **One way to start recording.** Every path that wants recording (the record button, the
  floating button in the foreground or the background, auto-start on launch, resume after
  an interruption, screen-on) asks one coordinator, which waits for the surround camera to
  show frames and then starts: one wait, one retry budget. The main screen no longer runs
  its own start timers (the seven "wait two seconds" chains, the 30-second check, the
  restore after a theme change and the 10-second screen-on resume are gone) and no longer
  keeps its own copy of the decision; it paints what the pipeline is doing. The floating
  button's background start used to bypass the storage checks, the write watchdog and the
  USB-only rule; it now goes through the same entry. Third step of the consolidation plan.
- Screen off with "keep recording when the screen is off" switched off: recording stops
  10 seconds after the screen goes dark whether it was started by hand or automatically (it
  used to stop only automatic recordings). On screen-on it resumes only when "auto-record on
  launch" is on.
- The pipeline's stop reasons (drive full, nothing written, camera taken by another app, no
  first data) are handled the same way whether or not the main screen is showing; the toast
  and the status-bar hint follow the reason.

## [1.59.0-alpha] - 2026-09-27

- **No file I/O on the main thread for storage or the black box.** The black box writes on
  its own thread (every important line used to fsync on the caller's thread: recording
  start/stop, screen off, every settings switch); quit and crash wait for it briefly.
  Storage is now a snapshot taken on a background thread (drive present, free space,
  mounted volumes), refreshed on drive events, recording start/stop, a drive switch, a
  settings change, return to the main screen and every 30 s while it is showing; the status
  bar, the record button's availability, the pre-start check and the 30-second free-space
  check read the snapshot instead of stat-ing the USB drive, which is what stalled the
  screen when a drive dropped. Second step of the consolidation plan.

## [1.58.0-alpha] - 2026-09-27

- **Cleanup, no behaviour change.** Leftovers of removed features are gone: remote
  recording / DingTalk / Feishu state and launchers, the lifecycle pause API, unused camera
  entry points, write-only counters in the recorder, unused storage lookups, dead config
  keys, orphan layout ids and the plain-button branch (about 1,300 lines). First step of
  the consolidation plan; the next steps move file I/O off the main thread and merge the
  duplicated recording and camera watchdogs.
- Check for updates: tapping "Download and install" first shows a picture of the head unit's
  installer, in the style of the super mirror guide. Once the new version is installed, tap
  Back at the top left, not Open in the middle: that installer has a bug, Open leaves you
  unable to get back and the next install or update then fails. "Got it, download" starts
  the download; Back cancels. Shown every time.
- The picture guides (super mirror guide, install reminder) are in Chinese only when the
  interface is Chinese and in English for every other language. The super mirror guide
  showed Chinese pictures in Malay.
- Main screen: with fisheye correction on, each surround cell fills its space instead of
  fitting inside it. With only the surround view shown the cells are wider than the picture,
  which left black bars at the sides; now a little of the top and bottom (sky and ground) is
  cropped and the middle is larger. In the surround + two cabin layout the cells are about
  as wide as the picture, so little changes there. Each cell stores this setting on its own
  (`fitCorrected`, default fill), ready for per-cell adjustment in the profile editor's
  layout; nothing edits it yet. With correction off nothing changes.

## [1.57.0-alpha] - 2026-09-27

- **Recording keeps going around the car's own camera use.** On this head unit only one of
  the cabin and surround cameras can be open at a time, and the camera service decides by
  process priority, so yielding never helped: the yield option (1.54.0–1.56.0) is gone.
  Now, when the camera service disconnects a recording camera, the segment stops at once
  instead of after the 15-second write watchdog; while another app holds a camera we retry
  only every 30 s; the moment it lets go (or our priority changes, e.g. the main screen comes
  back) we reconnect and recording resumes by itself. The status bar says so meanwhile.
  These interruptions no longer count against the auto-resume budget.
- Time watermark is on by default.
- Status bar: after switching the recording drive in Settings → Storage, the free-space cell
  kept showing the previous drive until the next recording started.
- Developer options: **Archive to another drive** moves recordings, photos and diagnostics
  reports from the recording drive to another mounted drive (app logs are copied), verifying
  sizes and keeping file times. Not while recording.

## [1.56.0-alpha] - 2026-09-27

- **Our own camera reopen no longer counts as "another app".** A reconnect or forced reopen
  did not mark the camera as opening, so the camera service's "in use" report for it was
  classified as someone else's. In 1.54.0 that could trigger yielding against ourselves; in
  1.55.0 it added a false "another app took camera 2" contention line after every reopen.
  Use this version's logs instead of 1.55.0's.

## [1.55.0-alpha] - 2026-09-27

- **Camera yielding (1.54.0) is now a developer option, off by default.** Recording keeps its
  cameras; the head unit's own cabin view is not expected to conflict with the surround stream,
  so the contention is logged instead of avoided: the black box records who took which camera,
  which of ours was disconnected how many milliseconds later, and whether our reopen pushed the
  other app off, each with the process importance, whether the main screen is in front and the
  cameras we hold. Diagnostics list each camera's physical cameras and capabilities.

## [1.54.0-alpha] - 2026-09-27

- Main screen, surround view only: the top-left cell is labelled "Front" again. It showed
  "Surround", the name of the camera the composite stream comes from, while the other three
  cells read Rear, Left and Right.
- **The car's own cabin views open even while this app's main screen is up.** When the head
  unit takes a camera for its own feature, the surround camera gets disconnected (the two
  conflict in the HAL); the app used to reconnect within half a second and, from the
  foreground, win the camera back, killing the factory view. Now it yields: no reconnects,
  reopens or watchdog resets while another app holds a camera, and it reconnects once that
  app lets go (a hold longer than 10 minutes is treated as a stale camera-service entry).

## [1.53.0-alpha] - 2026-09-27

- The profile name at the bottom left of the main screen follows the interface language:
  "Zeekr 7X (surround)" and "Surround + 2 cabin" in English and Malay, the Chinese names in
  Chinese. It used to show the Chinese name stored with the profile whatever the language.
- **"Start on boot" has one entry point that restores the app's core** — floating button, super
  mirror and, with "Record on launch", recording — whenever the foreground service comes up, the
  keep-alive job runs (within a second of waking), the screen turns on or the app is updated.
  It does nothing while "Start on boot" is off or after you quit. A silently launched main screen
  now flashes and goes to the background instead of staying in front.
- A manual stop of the recording now survives the process being killed and brought back; it is
  cleared by a real reboot or by opening the app yourself.
- Screen-off recording's wake lock now lives at process level: it listens for the screen itself,
  also covers a recording that starts while the screen is already off (remaining time counted
  from the moment it went off), and is checked every minute against the real screen state.

## [1.52.0-alpha] - 2026-09-27

- The fisheye correction button reads "Straighten" in English and "Luruskan" in Malay, on the
  main screen, in photo playback and in video playback. "Fisheye" / "Mata ikan" read like a
  switch that turns a fisheye effect on; when lit it does the opposite and the picture is
  corrected. The Chinese label, 鱼眼校正, is unchanged.
- Screen-off recording: the "keep the car awake" limit is typed in as hours (decimals allowed,
  24 or 30 are fine) instead of picked from a list; default 1 hour.
- The accessibility keep-alive service is back (1.51.0 had removed it): whether the head unit
  lets it run has never been tested, so it stays as one of the keep-alive means, does nothing
  while "Keep alive" is off, and writes to the black box when the system creates, connects or
  destroys it.

## [1.51.0-alpha] - 2026-09-27

- **Settings → System now answers two questions only**: whether the app brings itself back
  when it is gone ("Start on boot"), and whether recording survives the screen going off
  ("Keep recording when the screen goes off"). "Record on launch" moved to Recording: it is
  part of what the user wants running, not a rule.
- **"Keep alive" is a real switch.** It now governs every keep-alive means (the 15-minute job,
  broadcast wake-ups, the per-minute tick, the early foreground service, sticky restarts);
  off means the app stays gone once killed. The accessibility service is removed: it never
  ran on the head unit and could not be enabled there.
- **Screen-off recording (developer options) = keep recording + keep the car awake.** While a
  recording is running and the screen goes off, the app holds a wake lock so the head unit
  does not deep-sleep, for a duration you choose (30 minutes to 8 hours, counted from the
  moment the screen went off; default 1 hour). The lock is released when recording stops,
  the screen comes back on, or the time is up. The separate "Persistent wake lock" option is
  gone. Applies to manual recordings too.
- After a real reboot the "exited" state is cleared, so the app may come back as the spec
  says; the boot broadcast never reaches the app on this head unit, so reboot is detected
  from the uptime clock instead.
- The black box records who actually started the process (the first broadcast, keep-alive
  job or screen after the content provider), not just "ContentProvider".

## [1.50.0-alpha] - 2026-09-27

- **The OK button's label is centred in English and Malay.** Dialogs took "OK" from the head
  unit's system strings (android.R.string.ok), and the English one sat off to the right in the
  button; Cancel, the app's own string, was always centred. OK now comes from the app's own
  strings in all three languages. (The 1.49.0 change to button layout addressed long labels,
  not this.)

## [1.49.0-alpha] - 2026-09-27

- Dialog buttons lay their label out in the button's real width, centred. Material's dialog
  button style is single-line (centred by a scroll offset) and capped at 320dp, which left
  long English and Malay labels off-centre or cut to "…".
- Wording brought in line with what the app does: the privacy note no longer lists "Upload
  logs" (removed in 1.44); diagnostics no longer claims vehicle signals; the photo-channel
  note, "Record on launch", "Reset floating button" and the developer-options hint say what
  actually happens; the continuous playback title was "Continuous recording" in Chinese.
- One word per thing: "camera" (not 摄像头/相机 mixed), "USB drive" everywhere users read
  prose (not "external storage"), recording as the act and 录像 as the footage, "Settings"
  in the drawer, delete dialogs phrased as questions, plain-language fisheye projection
  names in Chinese, two long setting notes shortened.

## [1.48.0-alpha] - 2026-09-27

- **Developer options: per-pixel fisheye correction on the GPU**, one switch for the live
  preview and one for video playback. With them on, the surround view is straightened pixel
  by pixel, as in photo playback, instead of in patches that bend straight lines slightly.
  The Fisheye button still turns correction on and off; these only pick the method. For the
  preview the camera picture goes through the app's own GL before it is shown, which has not
  been tried on the car yet; it takes effect after restarting the app. Recordings are
  untouched either way.

## [1.47.0-alpha] - 2026-09-27

- **Recording moves to another drive the moment its drive stops taking data, without losing
  the last 15 seconds.** The recorder keeps the most recent 15 seconds of encoded video in
  memory (longer while the drive has not confirmed the data on disk, up to one minute), fsyncs
  the file every 5 seconds, and on the first write, fsync or file-open error switches to another
  mounted drive, writes the buffered video into the new file first, then carries on. When the
  loss is only found at a segment switch, the buffered video is saved as its own file. In sentry
  mode the M.2 drive drops out when the car locks; about 40 seconds around the drop used to be
  lost.
- While a recording is on a drive other than the chosen one, the status line says so until the
  recording stops, e.g. "Recording to B905 (1D8C unavailable)".

## [1.46.0-alpha] - 2026-09-26

- The black box records USB drives being mounted, unmounted or dropping out, with the drives
  present at that moment. It also records which drive each recording writes to, and says so when
  that is not the drive chosen in settings.
- Diagnostics: "Recent recordings" lists the folder the last recording actually went to. When the
  chosen drive dropped out and recording moved to the other one, the report used to show none of
  the new clips.

## [1.45.0-alpha] - 2026-09-26

- **No more "recording" when nothing is being recorded.** If the screen and the floating button
  say recording but no data has reached the file for 15 seconds, recording stops as interrupted
  ("nothing was being written to the file"), and resumes on its own once the surround view is
  fine, like the other interruptions. In sentry mode the encoder failed and the app showed
  "recording" for two hours without writing a file.
- Every recorder error, encoder rebuild and recovery attempt goes to the black box with the
  reason the system gives. Warnings and errors are also kept in a file that survives restarts;
  the diagnostics report shows the last 150 of them.
- Developer options: the screen-off recording switch is now called "Screen-off recording
  (developer)", so it is not confused with "Keep recording when the screen goes off".

## [1.44.0-alpha] - 2026-09-26

- **Removed the EVCam code this app never used, about 18,000 lines.** The blind-spot,
  secondary-display and supervision windows with their turn-signal and door observers (turn
  signals cannot be read inside the App Lab container); the "Custom" stream profile with its
  layout manager and camera-mapping page; the ADB permission tools; the panoramic engine and
  second recording pipeline; "Upload logs", which posted to the upstream author's server; the
  old car models; and developer options the app has since replaced (preview correction, current
  profile, save logs, the debug switch). No user-facing feature of this app changes.
- Developer options that remain: raw frame dump, repair clips, force H.264, image adjustment,
  camera mapping, permissions, the keep-alive switches and screen-off recording.
- Diagnostics: the black box notes when the app version changed (an update ends the old process
  with a signal, which read like a crash), and a recording that survives a main screen rebuild
  keeps its start time, so the black box no longer logs it as "0 seconds".

## [1.43.0-alpha] - 2026-09-26

- **Photo playback: "Send to phone" works without enlarging a view first.** It sends the
  enlarged photo, or the surround photo when nothing is enlarged.
- **Diagnostics: the "Share" button is gone.** The head unit has no app that accepts a share,
  so it always failed. Use "Send to phone", or "Save" and take the report off the USB drive.
- **Diagnostics: the black box now includes the previous log file.** When the log had just
  rolled over to a new file, the report showed only the few lines since then and left out what
  happened before.

## [1.42.0-alpha] - 2026-09-26

- **Developer options stay on once turned on.** Restarts and updates no longer turn them off.
  They turn off only when you tap "Safety notice" in About again and confirm, clear the app's
  data, or uninstall and reinstall (they are left out of Android backups so a reinstall does
  not bring them back).
- **Diagnostics: "Send to phone"** (developer options), the same QR transfer as in photo and
  video playback. Scan the code and the phone opens a download page for the report; tap
  Download and the .json file is on the phone. Each tap saves a fresh copy of the report on
  screen.

## [1.41.0-alpha] - 2026-09-26

- **"Keep recording when the screen goes off" is now on by default.** It is there for the
  car's sentry mode: the car stays awake with the screen dark, and recording should keep going.
- An interrupted recording is resumed while the screen is off again, as soon as the surround
  view is back (1.39.0 had made it wait for the screen). While it waits to resume, the cameras
  count as in use by recording, so the super mirror no longer releases them at screen-off.
- The black box summary at screen-on now says how many times recording stopped during the
  screen-off stretch, not just whether it is recording now.

## [1.40.0-alpha] - 2026-09-26

- **Fisheye correction on the live surround view and in video playback** (experimental).
  A "Fisheye" button in the action rail on the main screen; video playback gets the same
  button, which was hidden until now. It is one switch with the button in photo playback,
  and all three use the projection, field of view and strength under Settings -> Interface.
  Only the screen changes: recordings and photos on the drive stay as the camera took them.
  Each lane is redrawn in up to 24 x 24 patches, so watch for stutter on the live view.

## [1.39.0-alpha] - 2026-09-26

- **New in Settings -> System: "Keep recording when the screen goes off"** (off by default).
  If you are recording when the screen goes off, manual or automatic, it keeps recording. It
  never wakes the car: recording pauses while the car sleeps and carries on when it wakes. The
  black box notes how long the screen was off, how long the car slept, and whether recording
  kept going. The developer-only "Screen-off recording" is unchanged.
- An interrupted recording is no longer resumed while the screen is off; it waits for the
  screen to come on instead of competing for the cameras.
- If a recording stops while the screen is off, the cameras are released as usual.
- The 10-second screen-off stop now checks whether the screen is really off, so a recording is
  not stopped right after the car wakes up.

## [1.38.0-alpha] - 2026-09-26

- **Cameras open and close on their own threads; the main thread no longer waits.** Closing a
  camera once blocked the main thread for 13.6 s, freezing the main screen, the super mirror
  and the floating button. Now each camera's open and close run on that camera's thread, a
  reopen waits for the previous close, and a camera that is stuck only stalls itself.
- **Exit always finishes within 3 seconds.** If cleanup or a camera close is stuck, the app
  still quits and the black box says what was stuck.
- Black box records which thread is stuck and where (main or a camera) when it is blocked for
  more than 2 s, when the display stops producing frames while the screen is on, what changed
  when the system changes configuration, and when each camera has actually closed after the
  screen goes off.

## [1.37.0-alpha] - 2026-09-26

- **Diagnostics keep only what is still open.** Removed the probes whose answers are known
  and written down: vehicle signals (ignition, gear, handbrake are structurally out of
  reach), shutdown broadcasts (never sent), encoder and decoder capability, and floating
  window positions. The diagnostics page loses "Request car permissions", "Snapshot" and
  "Compare"; the app no longer declares or asks for car permissions. The JSON export drops
  the raw system property and settings dumps (schema 2).
- Black box: routine counters (broadcasts, foreground service wake-ups) are gone; earlier
  process exits are listed once instead of at every start; service starts are logged only
  when the system restarts a service.
- The report's recent log covers minutes instead of about two seconds: it drops the
  container's call tracing and codec setup chatter, and no longer skips the log lines of our
  own screens. Stall snapshots filter the same noise.
- Periodic log lines (per-camera frame rate every 5 s, encoded frame counts) are down to once
  a minute or removed.

## [1.36.0-alpha] - 2026-09-26

- **Cabin views are one whole picture in both playback screens.** Tapping an enlarged cabin
  view goes back to the grid instead of zooming into a quarter; only the surround view is a
  2×2 grid. Photo playback also stops applying fisheye correction to cabin photos.
- **Rear cabin recordings are no longer mirrored.** Android flips the picture of any camera
  that reports itself as front-facing (the rear cabin one does), and the recorder drew that
  flipped picture, time overlay included. The normal view is now what the camera sees,
  unmirrored, same as photos; the flip is undone where it comes in (recording, preview,
  preview-grab photos). Recordings made before this version stay mirrored.
- Preview: with "Mirror" on in the profile editor (the default for both cabins), the rear
  cabin is now mirrored like the front one. Before, the system flip and the switch cancelled
  out, so the same switch did opposite things on the two cabins.

## [1.35.0-alpha] - 2026-09-26

- **Video playback shows every camera, laid out like photo playback**: surround on the
  left, cabin cameras stacked on the right. A camera with no files in that recording is
  hidden. All of them play together, kept in step by time, with the surround view setting
  the pace.
- Taps work as in photo playback: tap a view to enlarge it (on the surround view, the lane
  you tapped), tap again to go back. A new button under the player steps through the views;
  Back returns to the grid.
- The recording info moved from the corner of the picture to the title bar.
- "Send to phone" sends the current clip of the enlarged camera (surround in the grid).
- Deleting or sharing a recording includes its cabin files, and the sizes in the list count
  them. Before, only the surround files were deleted and the cabin files stayed on the drive.
- Play after a recording has finished starts it again from the beginning.
- Floating button: the default position is the spot set in the car (top right), stored as a
  distance from the top-right corner so it stays there on other screen sizes. Applies to new
  installs and "Reset floating windows"; a position you dragged to is kept.
- Removed what was left of the old "open app" floating button (merged into this one in
  0.45.0).

## [1.34.0-alpha] - 2026-09-26

- **One principle for the whole app: it keeps running in the state you set.** Parking,
  errors and a full drive are exceptions where it adjusts by its own rules, and once the
  exception is over it goes back to your state. Written down as section 0 of the lifecycle
  spec.
- **So after the car wakes, the super mirror reconnects by itself again**, and the screen-on
  handling the car never announces is replayed: the main screen comes back if it left for
  screen-off, and recording stopped at screen-off resumes. This includes the car's own
  wake two hours after parking. The Developer option "Reconnect cameras on wake" (1.28.0)
  is gone -- there is nothing left for it to decide.
- **Recording you started by hand is resumed after an interruption too**, not only
  auto-record, once the surround view is back. Only recording you stopped yourself is left
  stopped.
- Settings -> Super mirror: "Button mode" now sits just above "Reset view and position".
- Settings -> Floating button: the default button size is now 92 dp (was 90). A size you
  have already set is kept; "Reset floating windows" applies the new default.

## [1.33.0-alpha] - 2026-09-26

- **When recording is interrupted, the app says why, and picks it back up as soon as the
  surround view is back.** Until now it said nothing, checked every thirty seconds, and
  resumed as soon as any camera was connected. Now, with auto-record on, an interruption
  shows the reason -- no picture after recording started, or the recorder stopping on its
  own -- and that it will resume; the app then watches the surround camera every two
  seconds and restarts recording the moment it is delivering pictures again, whether or not
  the main screen is showing. A full storage device and the screen-off rule keep their own
  messages and are not resumed this way.
- **Resuming now gives up after three failures in a row, and says so.** The old counter was
  reset whenever recording started, so recording that started but never received a picture
  could be restarted forever, rebuilding the surround camera's session every time. A resume
  now only counts as successful once a minute has been recorded.

## [1.32.0-alpha] - 2026-09-26

- **Cameras are released only when nothing is using them -- now everywhere.** The register
  of who is using the cameras (preview, recording, super mirror, floating windows, blind
  spot) has existed since 1.17.0, but two places closed the cameras without asking it.
  When the main screen was destroyed while not recording, the whole camera manager was
  torn down even with the super mirror showing the surround view; the mirror went dark and
  its watchdog reopened the camera two seconds later. When blind spot finished, it checked
  itself and recording but not the mirror. Both now ask the register first.
- **Every head unit reboot is now recorded.** Parking is normally deep sleep and the app
  survives it. A real reboot is rare, and whether the app can come back after one on its
  own has been seen only once. At each start the black box now notes which boot it is in,
  and when that has changed, how many minutes after boot the app first ran and what
  started it.

## [1.31.0-alpha] - 2026-09-26

- **Exit now means exit.** Until now the app came back by itself within fifteen minutes
  of pressing exit: the fifteen-minute keep-alive job was never cancelled, the foreground
  service broadcast a request to restart itself every time it was stopped (including on
  exit), and the system restarts services marked sticky. Exiting now records that you did,
  cancels the job, and every path that could bring the app back -- the service's start
  point, the keep-alive broadcasts, the earliest-starting provider, the job itself, and
  each service when the system restarts it -- checks first and does nothing. It lasts until
  you open the app yourself or the head unit genuinely boots. The super mirror, the
  recording button and blind spot now stop on exit as well.
- The lifecycle is now written down as a spec -- what boot autostart and auto-record are
  defined to do, and a table of where the app still differs -- in
  `docs/lifecycle-spec.md`.

## [1.30.0-alpha] - 2026-09-26

- **Recording in progress when the screen goes dark no longer has the super mirror pulled
  off the surround camera.** Since 1.24.0 the mirror detached itself at screen-off, which
  rebuilds that camera's session. If a rebuild during recording fails to configure, the
  camera drops optional outputs and retries -- the second screen, then the mirror, and when
  neither is left, the recording output. The preview carries on and nothing on screen
  says the recording stopped. On 1.19 the mirror was still attached at screen-off and would
  have been the one dropped. This is the only change since 1.19 that touches a recording
  already running at screen-off, and a likely cause of manual recording stopping in
  sentry mode, though not yet caught in a log. While recording, the camera is never closed
  anyway, so the mirror now waits and detaches once recording ends.
- Dropping the mirror or the recording output after a failed session is now written to
  the black box.

## [1.29.0-alpha] - 2026-09-26

- **The black box now says why recording stopped.** Recording starts and stops were never
  recorded, so "recording stopped in sentry mode" could not be traced to a cause. Now:
  every start and stop, and at screen-off which rule applied -- manual recording left
  alone, screen-off recording in effect, or auto-record with screen-off recording not in
  effect and a stop due in ten seconds.
- **Screen-off recording that is stored on but not in effect is now called out.** It only
  works in the process where Developer options were unlocked, and unlocking is deliberately
  not saved, so every update quietly takes it out of effect. The black box's switch line at
  each process start now says so when that is the case.
- Fixed: with auto-record and screen-off recording in effect, the super mirror's
  screen-off step (added in 1.24.0) closed the cameras that the main screen deliberately
  keeps active so recording can start at once when the screen comes back.

## [1.28.0-alpha] - 2026-09-25

- **After the car wakes, the cameras wait for you by default.** Waking from deep sleep and
  the car lighting its own screen while parked -- it does this about two hours after it
  first falls asleep, for about two minutes -- look identical to the app: the screen is on
  and no screen-on broadcast arrives. So the super mirror now stays on "tap to resume"
  until you tap it, and the main screen opens its preview when you open it, as usual. A
  new switch under Settings -> System, "Reconnect cameras on wake", brings back 1.27.0's
  automatic reconnect; like screen-off recording, it is locked off unless Developer
  options are unlocked.
- **The black box now records what the camera service thinks.** For each camera: when it
  becomes busy or free, and whether that was us. The state the surround view gets stuck in
  -- only a head unit restart clears it, while the cabin cameras keep working -- has never
  been caught in a log; if it happens again, an export before restarting will say whether
  something other than the app is holding it. Also recorded: disconnects and errors, how
  long closing a camera took when it took over half a second and on which thread, and how
  often a camera was reconnected automatically.
- The error logged as "-4 (out of resources)" was never about resources: -4 is the base
  code's own number for the camera service disconnecting the app. Label corrected.

## [1.27.0-alpha] - 2026-09-24

- **Fixed: after the car had been parked, the super mirror stayed on "tap to resume" and
  tapping it did nothing.** This was introduced in 1.24.0. The mirror remembered "the
  screen is dark" when the screen went off and waited for the screen-on broadcast to clear
  it -- but after deep sleep that broadcast never arrives. The black box shows the release
  four times out of four and the screen-on broadcast zero times out of four, while the
  heartbeat reports the screen on within thirty seconds of each wake. With the flag stuck,
  every path to the camera was refused, including your tap. It now asks the system whether
  the screen is on instead of trusting a flag, so it comes back within two seconds of the
  screen lighting up, broadcast or not.
- **The main screen had the same blind spot** (this one predates the fork): its screen-on
  handling never ran after deep sleep, so cameras were not reopened and the fifteen-second
  "move to background" step still fired after waking, thinking the screen was off. It now
  checks the real screen state first, and runs the screen-on handling it missed.
- **The black box now keeps the scene of an ANR.** Today's session ended with the app not
  responding -- the dialog you saw was Android's "app isn't responding" -- and nothing said
  where the main thread was stuck. The next time the app starts after an ANR, the main
  thread's stack from that moment is copied into the black box.
- **Diagnostics now show every setting.** A new section lists the switches that decide
  when the camera is used, whether Developer options are unlocked, and the raw value of
  every setting. The black box records the same switches each time the process starts and
  a line whenever one is changed, so any stretch of the timeline can be matched to the
  settings it ran under.

## [1.26.0-alpha] - 2026-09-23

- **Boot autostart no longer means "the head unit never sleeps".** The persistent wake lock
  was held whenever that switch was on, which is a second thing the switch never said it
  did -- and the expensive one: parked, the head unit spends about four fifths of its time
  in deep sleep, and the lock replaces all of it with time awake on the 12V battery. The
  lock is now its own switch under Developer options, off by default, and boot autostart
  means only what its name says.
- Waking from sleep is written down as a usable trigger in the platform notes. Nothing runs
  during deep sleep, but the moment the head unit wakes, the gap between elapsed real time
  and uptime says exactly how long it slept -- enough to rebuild a camera session that
  predates the sleep on purpose, instead of waiting for a watchdog to notice the frames
  stopped.

## [1.25.0-alpha] - 2026-09-23

- **"Prevent deep sleep" is gone from Settings.** What it would have prevented, measured
  over the last 26 hours of head unit uptime, is 20.8 hours of deep sleep -- all of it
  while parked, and all of it spent on the 12V battery instead. The same black box shows
  the process coming out of two deep sleeps with the same process id it went in with, so
  it does not need the switch to survive. It had never been read by anything except the
  settings screen drawing it, so removing it changes no behaviour; it only takes away a
  switch that could only do harm. The evidence is written down in the platform notes so
  nobody has to work it out again.
- Note for whoever reads the notes next: the same wake lock is still held when **boot
  autostart** is on, which means that switch also means "the head unit never deep-sleeps".
  That is not what its name says, and it is left alone pending a decision.

## [1.24.0-alpha] - 2026-09-23

Read from the car: the head unit deep-sleeps whenever it is parked -- 20.8 hours out of the
last 26 -- and the app survives it, same process id either side. What did not survive was
the camera.

- **The super mirror lets go of the camera when the screen goes dark, and takes it back
  when the screen comes on.** Two seconds after the screen went off it was already showing
  "tap to resume", because a dark screen has no frames to show -- but it still held its
  claim on the camera, so the step that releases cameras fifteen seconds after screen-off
  reported "someone still wants it" and left the camera open. It then went into deep sleep
  that way. On waking, the session belonged to a previous life: closing it blocked inside
  binder, then DISCONNECTED, then error -4 (out of resources), and the watchdog needed 9.4
  seconds to get a picture back. The unlucky version of that is the one that needed the
  head unit restarted.
- **Cameras are released 1.5 seconds after the screen goes dark, not 15.** The 15-second
  task runs on a clock that stops during deep sleep, and the head unit was asleep six
  seconds after screen-off -- so that task actually ran nineteen minutes later, on waking.
  The mirror does the same check itself, because after you exit the app there is no main
  screen left to do it.
- **The black box now covers the night.** Two thirds of it was the once-a-minute keep-alive
  routine, which meant a 48KB export held about three hours -- and the hours worth reading
  are the ones you were asleep for. Those lines are counted now instead of listed, a
  heartbeat is written when something changes rather than every minute, and the export
  holds 128KB.

## [1.23.2-alpha] - 2026-09-23

- **Tapping an enlarged lane goes straight back to the grid**, instead of stopping at the
  whole surround photo with the cabin views still hidden. That state is somewhere to pass
  through, not somewhere to be: having looked at one lane, you want the whole picture back,
  and there was no reason to spend a second tap on it. Back does the same in one press. For
  a group with only a surround photo nothing changes -- the grid holds that one photo
  anyway, so the two looked identical to begin with.

## [1.23.1-alpha] - 2026-09-23

- Fixed: two hints still told you to double-tap -- the one under the photo list and the one
  that asks you to pick a lane before sending a photo to a phone. Nothing double-taps any
  more; the string is named after what it says now, not after the gesture it used to
  describe.

## [1.23.0-alpha] - 2026-09-23

- **One tap gets you there in photo playback**, the way the preview already worked. Tap a
  lane of the surround photo and it fills the area with that lane enlarged -- no more
  double-tapping to enlarge and then tapping again to pick the lane. Tap a cabin photo and
  it fills the area. Tap the picture again to go back to the whole photo, tap beside it, or
  press back, to return to the grid.
- **Faster, because it no longer waits to see whether you tap twice.** Keeping a
  double-tap gesture means every single tap must sit through the ~300ms double-tap window
  first. That wait was the whole difference in feel between the preview and photo playback.
- The second view is gone: enlarging now hides the other boxes instead of loading the same
  file into a separate full-screen ImageView, so a picture is decoded once rather than once
  per enlarge.

## [1.22.0-alpha] - 2026-09-23

- **The super mirror's buttons are half again as large** and the group sits one button
  higher. A button you press while driving is pressed from the corner of your eye, and the
  48dp minimum is a phone number, not a car one. The window's minimum size in this mode
  grows with them.
- **Fixed: the boxes in photo playback were in the wrong places.** Three nested layouts
  were each forcing a 16:10 shape on the same content, so no box ended up the size or the
  position it was given. Shape is the picture's business now; the boxes only do layout, and
  they match the preview frame for frame.
- **Fixed: a camera with no picture for that moment still took up a box.** This was claimed
  in 1.20.0 but only the layout comment said so -- the code kept the box and wrote "no
  picture" in it. Now the box goes, and with both cabin boxes gone the surround view takes
  the whole area.
- **Fixed: tapping a lane of a surround photo did not enlarge it.** The picture only moved.
  The viewport was handing an ImageView matrix source coordinates measured in the view,
  while that matrix maps the picture's own pixels -- the two are now separate calls, and
  mixing them again trips a test.

## [1.21.0-alpha] - 2026-09-23

- **Button mode for the super mirror**, off by default, under Settings -> Super mirror. It
  replaces swiping the middle third with four buttons laid out the way the car is: front on
  top, rear below it, left and right to the sides. Position is the answer, so there is
  nothing to read. The current view is the Zeekr orange one. The buttons appear when you
  touch the window and go five seconds later, they stay the same size however the window is
  resized, and in this mode the window will not shrink below them.

## [1.20.0-alpha] - 2026-09-23

- **Photo playback is laid out like the preview**: the surround view on the left, the cabin
  cameras stacked on the right, in the same proportions. A camera with no picture for that
  moment leaves no empty box.
- **Tap a cell of a surround photo to enlarge it, tap again to go back** -- the gesture
  continuous playback already had. Cabin pictures are a single view with nothing to divide,
  so a tap there does nothing rather than pretending to zoom.
- The four cells are named by direction now -- front, rear, left, right -- instead of "top
  left", "bottom left", "bottom right". Which cell faces which way was confirmed on the car
  long ago and the super mirror is built on it; only these labels had not caught up. Naming
  them by position was also its own trap, since "top left" and the surround view's own
  "left" are two different things.

## [1.19.0-beta] - 2026-09-22

Everything from the alphas since 1.9.0-beta, gathered into one beta.

- **Clips that lost power mid-recording can be repaired.** A segment cut short is not
  damaged -- every frame is on the disk -- but the index is only written when recording stops
  normally, so no player will open it. Developer options can rebuild that index in place,
  using a healthy clip of the same camera, and rolls the file back untouched if the result
  does not read.
- **A camera that goes quiet is reopened.** The existing recovery was driven by camera
  callbacks and went deaf exactly when the camera stopped reporting -- the case where the
  mirror froze, the preview went blank and recording would not start until the app was
  restarted. A watchdog outside that path now watches only whether frames arrive. When the
  camera cannot be opened at all, it says so instead of retrying forever, and tells you when
  restarting the head unit is what clears it.
- **The super mirror no longer shows a stale picture as if it were live**: after a few
  seconds without a new frame it dims and offers a tap to reconnect. Pushed to the edge it
  stops streaming altogether and shows its name down the strip.
- **Recording no longer starts on its own.** Opening playback and coming back, rebuilding the
  screen, or half a minute passing could each start a recording you had stopped. "Start
  recording automatically" now means what it says: once at startup, and afterwards only
  picking up a recording that stopped by itself.
- **Photo playback is its own screen**, so opening it lets the cameras close instead of
  leaving them capturing behind a picture. Back steps out one layer at a time.
- **Recordings and photos are named after their camera** -- `surround`, `cabinfront`,
  `cabinrear` -- rather than `front`, `back` and `left`, which read like directions and are
  not. Files already on the drive keep working.
- The app comes back to the front when the screen does, the cameras' open state is decided
  in one place rather than four, and diagnostics now records what the head unit actually
  does with the app's lifecycle requests -- useful if you are reporting a problem.
- Malay joins the interface languages, and the app name drops "car version" on the device.

## [1.18.0-alpha] - 2026-09-20

- **Recordings and photos are named after the camera they came from**: `surround`,
  `cabinfront`, `cabinrear`. The old names were `front`, `back` and `left`, which read like
  directions and are not: `front` is the whole surround composite -- a 2x2 picture that has
  its own front, back, left and right inside it -- while `back` is the front cabin and `left`
  is the rear one. Files written from now on carry the new names; **files already on the
  drive keep working**, since both spellings resolve to the same camera and land in the same
  group.
- The boxes in photo playback are labelled with the camera's name rather than a direction,
  for the same reason.

## [1.17.0-alpha] - 2026-09-20

- **One register decides whether the cameras stay open.** Four places used to answer that
  question with their own conditions, and two of them disagreed: with the super mirror on,
  the screen-off routine closed the cameras after fifteen seconds and the mirror's watchdog
  reopened them two seconds later, every time the screen went off, all night. Preview,
  recording and the mirror now register while they need the cameras, the overlay windows are
  asked directly since their own service already tracks them, and the cameras close only
  when nobody holds a claim. Behaviour is otherwise unchanged -- what ends is the closing and
  reopening.
- The continuous playback screen's name comes from the string resources now, like every
  other screen's.

## [1.16.0-alpha] - 2026-09-20

- **Photo playback is its own screen now**, the way continuous playback already was. It used
  to be a panel inside the main screen, which only hid the recording layer -- so the main
  screen never paused and the cameras kept capturing at full rate behind a picture nobody
  could see. Opening it now sends the main screen to the background, and unless something
  else wants the cameras, they close.
- Back now steps out one layer at a time there: out of multi-select, then out of the
  single-lane view, then out of the screen. Before, back left the screen outright from
  anywhere, which made a multi-selection look like it had been committed.

## [1.15.0-alpha] - 2026-09-20

- **Records what actually happens to the app, in Diagnostics section 2.6.** Startup,
  keep-alive and exit have been rebuilt in layers, and whether any of it works cannot be read
  off the code: the app can only ask -- start a service, hold a wake lock, register for a
  broadcast -- and whether this head unit obeys, quietly ignores or refuses is something only
  the car can say. So every request and its outcome are now written side by side, with three
  clocks on each line: awake time, accumulated deep sleep, and the process id. A night parked
  answers several questions at once -- how long the unit really slept, whether the process
  survived, what restarted it if not, and which of the thirty keep-alive broadcasts ever
  arrive. Nothing acts on any of it; it only records.

## [1.14.0-alpha] - 2026-09-20

- **Watches the vehicle's ignition state**, as a second route to the question the shutdown
  probe is asking: knowing that power is about to go lets the clip being recorded be closed
  properly instead of being left without an index. Turn signals and doors are out of reach on
  this head unit (`signature|privileged`), but ignition, gear and the parking brake sit under
  `CAR_POWERTRAIN`, which is a `normal` permission -- so the app now asks for it at startup,
  silently, since normal permissions do not prompt. It then registers for change callbacks
  and reads the current values, without checking first whether it is allowed: what the
  permission check claims and what the car actually returns have not always agreed here, and
  the disagreement is the interesting part. Everything it learns, including every refusal,
  goes to Diagnostics section 2.5, and ignition changes are written into the same timeline as
  the shutdown broadcasts in 2.4.

## [1.13.2-alpha] - 2026-09-19

Both changes come from one incident on the car: no camera would open -- mirror frozen,
preview blank, recording refusing to start -- while the car's own 360 view kept working.
Restarting the app, clearing its data and reinstalling all did nothing; restarting the head
unit fixed it instantly. So the stuck thing was a stale claim inside the camera service,
not anything this app stores.

- **The watchdog no longer hammers a camera that cannot be opened at all.** It was meant for
  a camera that opens and then goes quiet; a camera that never opened is the business of the
  open path, which has its own backoff. It also stops for good after three rounds instead of
  retrying every minute forever -- against a wedged camera service that only makes recovery
  harder, and fills the log.
- **"Tap to resume" says why when it cannot.** Tapping and getting nothing is what sends
  people to reinstall the app, which cannot help when the claim is held elsewhere. It now
  reports the camera's own error, and for a camera held by something else it says plainly
  that restarting the head unit clears it.

## [1.13.1-alpha] - 2026-09-19

- Reverted: "Keep recording after the screen goes off" is behind Developer options again, as
  it was before 1.13.0. Stopping ten seconds after the screen goes off is the behaviour the
  owner wants by default, and a switch that can quietly keep the cameras running all night
  is not one to leave where it can be flipped by accident.

## [1.13.0-alpha] - 2026-09-19

- **The app comes back when the screen does.** Fifteen seconds after the screen goes off it
  closes the cameras and sends itself to the background, which was always deliberate; what
  was missing is the other half. Getting into the car meant finding the head unit's home
  screen and tapping the icon again. It now returns by itself -- and if the screen was
  reclaimed while the car was parked, it is started again, the process still being held up
  by the foreground service. Only a screen that left *because of* the screen going off comes
  back: turning the display on is not by itself a reason for this app to take over the car's
  screen.
- **"Keep recording after the screen goes off" is no longer locked behind Developer options.**
  Whether recording continues after you park is the owner's call, not something to hide.
  Default is still off; with it off, recording stops ten seconds after the screen does, as
  before. With it on, recording continues until the power is cut or the drive fills up --
  which is the point, and also the cost.
- The super mirror's usage guide is the first row of its settings page, above the switches
  it explains.

## [1.12.1-alpha] - 2026-09-19

- The docked mirror strip is readable against any wallpaper: a fixed dark fill with the
  Zeekr orange down the edge that faces the desktop. It had been using the app's own surface
  colour, which is near-white by day and disappeared into light wallpapers -- matching the
  settings screen says nothing about standing out from whatever the strip happens to float
  over, so it no longer follows the day/night theme at all.

## [1.12.0-alpha] - 2026-09-19

- **Recording no longer starts by itself.** Opening video playback and coming back to the
  main screen started a recording, because returning to the foreground was treated as a
  reason to record whenever "Start recording automatically" was on -- it checked neither
  whether you had stopped recording yourself nor whether anything had been recording in the
  first place. Three more paths did the same thing: rebuilding the main screen (night mode,
  a language change, closing and reopening it) re-armed the one-shot auto start, forgot that
  you had pressed stop, and the 30-second safety check would start a recording that had
  never been running. The setting now means what it says: start once when the app starts,
  and afterwards only pick up a recording that stopped on its own. A recording you stopped
  stays stopped until you start it again.
- **Shutdown probe** (Diagnostics, section 2.4). Records whether the head unit tells the app
  anything before it powers down -- if it does, the clip being recorded can be closed
  properly instead of being left without an index. It only records; it does not act on the
  signal yet.
- The docked mirror strip now reads "Super mirror" in every language, in the app's own
  colours, a little larger.

## [1.11.0-alpha] - 2026-09-19

- **A camera that quietly stops producing frames is now reopened.** The app already had
  self-healing for this, but every path into it is driven by a camera callback, and it only
  arms itself when a session finishes configuring -- so when the callbacks stop coming, which
  is what a stalled camera on this head unit looks like, the recovery is deaf. That is the
  "came back to the car, mirror frozen, preview blank, recording will not start, only a
  restart helps" case. A watchdog outside that state machine now looks only at whether frames
  are arriving, and reopens the camera after eight seconds without one, three tries before it
  backs off for a minute.
- **The super mirror no longer shows a stale picture as if it were live.** A TextureView keeps
  the last frame forever, so a dead camera looks exactly like a quiet road. After 2.5 seconds
  without a new frame the window dims and reads "Paused - tap to resume"; a tap reconnects.
- **A docked mirror stops streaming.** Pushed to the edge, the 72px sliver shows the name
  "Super mirror" down its length instead of a picture, and that camera output is dropped --
  if nothing else needs the camera, it closes entirely. Bringing it back costs the few tenths
  of a second it takes to rebuild the session.

## [1.10.0-alpha] - 2026-09-18

- **Repair clips that lost power mid-recording**, under Developer options. A segment cut
  short by a power loss keeps every frame it recorded; what it lacks is the index, which is
  only written when recording stops normally, so no player will open it. The index is
  rebuilt from the frames themselves and appended in place, with the decoder parameters and
  the frame rate taken from a healthy clip of the same camera. The repaired file is read
  back before it is accepted, and rolled back byte for byte if it does not. It refuses to
  run while recording, and never touches files this app did not record.
- The main screen tiles read **Take photo**, **Videos** and **Photos** -- in English the
  capture and playback tiles used to be "Photo" and "Photos", side by side.
- The app name is now just **Zeekr Shortcut** on the device: the drawer, the launcher and
  the notifications. About and the documentation still carry the car-version name.
- The drawer header drops the logo and the byline, and shows the app's other-language name
  in small text under it.

## [1.9.0-beta] - 2026-09-17

Changes since 1.0.0:

- **Steadier recording and interface.**
  - Recording keeps going when the main screen is rebuilt (night mode, a language change) or
    closed. It stops only when you tap Stop or quit the app.
  - The record button no longer hangs on "Starting…". If recording does not start, the app
    retries once by itself.
  - Storage is checked every time a clip finishes. With a video storage cap set, the oldest
    recordings are deleted to stay under it; with no cap, nothing is deleted and recording
    stops when the drive is full. Only files this app recorded are ever deleted.
  - Settings: Language is under Interface, Diagnostics under System, and the former Advanced
    options are in Developer options. About opens directly.
- **Fisheye correction test options** for photo playback: a switch in the top right, and the
  projection, field of view and strength under Settings -> Interface. Only the surround view
  is corrected, and only on screen; recordings and photos on the drive are not changed.
- **Malay interface.** Native Malay speakers: if anything reads wrong, please report it.

## [1.8.1-alpha] - 2026-09-17

- Fixed: with the surround + cabin profile and only one cabin camera turned on, rebuilding
  the main screen (night mode, language) brought back an empty pane for the camera that is
  off. Hiding it was only done when the cameras were first set up, not when a rebuilt screen
  picked up the ones already running. The surround-only layout has no cabin panes and was
  not affected.

## [1.8.0-alpha] - 2026-09-17

- **Recording no longer stops when the main screen is rebuilt or closed.** Switching to night
  mode, changing the language, or the system reclaiming the screen while the app is in the
  background all rebuild the main screen, and that used to take the recording down with it:
  the new screen then tried to resume recording, which is how the button could hang on
  "Starting…". The cameras and recorders now stay up through it, and the new screen simply
  shows what they are doing -- recording, with the timer carrying on from when it began.
- Closing the main screen (back out of it, or swipe it away from recent apps) keeps
  recording too; the notification and the floating button show that it is still running.
  Recording stops only when you tap Stop or long-press to quit the app.
- While the preview is being handed from the old screen to the new one, the camera session
  is reconfigured, which may leave a gap of a fraction of a second in the recording.

## [1.7.0-alpha] - 2026-09-17

- **Storage is checked every time a clip is finished, not once an hour.** Between hourly
  checks the recordings could outgrow the cap by a whole hour of video. With a cap set, the
  oldest clips are now deleted so that the next clip still fits under it, and a margin of
  two clips is always kept free on the drive.
- **No cap now means what it says: nothing is deleted.** When the drive runs out of room,
  recording stops and says why. Previously the drive simply filled up and recording failed
  without a word -- one way the record button could hang on "Starting…".
- Before recording starts, the app makes sure at least one clip will fit. With a cap it
  clears the oldest clips first; without one it refuses and explains.
- While recording, free space is also checked every 30 seconds, for a drive that fills up
  in the middle of a clip.
- **Only this app's own recordings are ever deleted** -- files named like
  `20260917_101500_front.mp4`. The old cleanup deleted anything it found in the folder.
  Clips are deleted a whole minute at a time, oldest first, never the one being written.
- If a drive is full of other things, so that deleting every old recording still would not
  free enough, nothing is deleted and recording stops.
- The README claimed the oldest files were cleaned up when the drive fills. Without a cap
  that was never true; it now describes both cases.

## [1.6.1-alpha] - 2026-09-17

- **Fixed: the record button could stay on "Starting…" for good after returning to the app,
  while nothing was being recorded.** Recording is only counted as started once the first
  data is written, and that wait had no time limit: if the data never came, the button
  waited forever. The usual way in is leaving the app while recording and coming back after
  the screen has been rebuilt (the head unit switching to night mode, for one), when the
  new screen tries to resume recording and the attempt does not take. Tapping the button
  then showed "Recording error" -- that was the empty clip being cleaned up -- and a second
  tap started recording properly.
- Now, if no data arrives within 10 seconds, the app stops the attempt quietly and tries
  once more by itself. If that also fails it says so and waits for you, rather than retrying
  forever.
- Returning to the app also checks that the recorder is really recording when the screen
  says it is. If not, the button goes back to Start recording and a message says recording
  stopped while the app was in the background.

## [1.6.0-alpha] - 2026-09-17

- Check for updates: when a newer version is found, the dialog shows what changed, taken
  from the GitHub release page. If you skipped versions, each one in between is listed,
  newest first (up to five). The parts every release repeats -- getting started, safety,
  credits -- are left out, and so is the markup, so what remains is the changes.
- About: thanks to Gabriel, from the same owners' club, for testing the app and sending
  feedback.

## [1.5.1-alpha] - 2026-09-17

- Diagnostics: the vehicle-signal probe now tries every way in and reports what came back,
  rather than trusting the permission check. It reads each property through the untyped
  getter, through the typed ones, and -- this is new -- at every area id the property
  declares, so a zoned property like the doors is no longer written off after a single
  read at area 0. Each line says what the permission check claimed next to what the call
  actually returned, and the section ends with a one-line verdict per signal.
- The reason for the change is the in-app update: it was blocked by a permission check that
  said no, while handing the APK to the installer worked. A check that says no is a
  question, not an answer.

## [1.5.0-alpha] - 2026-09-16

- **Fixed: cabin photos were being corrected as if they were four views in one frame.**
  The correction asked the profile whether a camera records a 2x2 grid, and that flag is
  on for every camera by default -- including the cabin ones, which never produce a grid.
  A cabin photo was therefore cut in four and each quarter warped separately. It now looks
  at the picture instead: only a frame whose cells are square is treated as a grid.
  Present since 1.2.0, and in the quartered form since 1.2.1.
- Settings -> Interface -> Fisheye correction: a third projection, "Whole circle". It puts
  a ray at tan(angle/2) instead of tan(angle), so the entire fisheye circle fits in the
  frame; straight lines come out less straight than with "Straight lines" but nothing is
  cut. Up to 180 degrees, like the wide one.
- Settings -> Interface -> Correction strength: 10 to 100. Below 100 the picture is
  interpolated back towards the untouched original, which is the knob to reach for when a
  projection straightens too much or too little.
- All three projections put the same angle at the frame edge, so switching between them
  changes how the middle is laid out, not how much you see.

## [1.4.0-alpha] - 2026-09-16

- Settings -> Interface -> Fisheye correction: pick how the picture is straightened.
  "Straight lines" is the projection used so far: every straight line in the world comes
  out straight, and whatever falls outside the chosen field is cut. "Wide" wraps the
  picture on a cylinder instead: upright things stay upright and the horizon curves a
  little, which buys a much wider view to the left and right.
- Settings -> Interface -> Corrected field of view: 90 to 140 degrees for straight lines,
  90 to 180 for wide. The slider follows the projection, so what it shows is what is in
  effect.
- Both settings apply to photo playback only for now. Turning the correction on and off
  stays where it was, in the top right of photo playback.

## [1.3.0-alpha] - 2026-09-16

- Developer options: "Also save the raw frame". With it on, taking a photo also writes the
  frame exactly as the camera handed it over -- four views in one strip, not cut apart, no
  stamp -- to photos/raw, next to a text file recording what the app made of it: the frame
  size, whether it was taken for a composite stream, the rectangle of each lane, and the
  recording settings in force. It is off by default and costs one extra file per photo.
- The raw folder is outside what photo playback scans, so these files do not show up as
  duplicates of the photo you just took.

## [1.2.3-alpha] - 2026-09-16

- Photo playback: the fisheye correction now keeps a 140 degree field instead of 110, so
  less of the picture is cut away at the edges. The correction itself is unchanged; the
  super mirror keeps its own setting.

## [1.2.2-alpha] - 2026-09-16

- Photo playback: straight lines stay straight under fisheye correction. The picture is
  now remapped pixel by pixel instead of through a mesh of small patches. Each patch was
  linear inside and the slope jumped at its border, which turned a straight line into a
  chain of short segments that reads as a wave. A photo is corrected once, so it can
  afford the exact arithmetic; the super mirror keeps the patches because it has to keep
  up with thirty frames a second.
- Sampling is bilinear, so the correction softens the picture slightly rather than
  showing stair steps.

## [1.2.1-alpha] - 2026-09-16

- Photo playback: the fisheye correction now straightens as much as the super mirror does.
  It is the same straight-line projection at the same 110 degree field of view, so the two
  look alike; what falls outside that field is cut.
- Photo playback: only the surround photo is corrected. The cabin cameras are left alone.
- Photo playback: turning the correction on or off no longer blanks the picture while the
  new one is prepared.
- Malay: the photo button on the main screen reads "Ambil foto" and the drawer entry reads
  "Lihat foto". Both said "Foto" before, which did not say which was which.

## [1.2.0-alpha] - 2026-09-16

- **Fisheye correction in photo playback.** A button in the top right turns it on and off.
  It only changes what is on screen: the files on the USB drive are untouched.
- A surround photo holds all four views in one 2x2 image, so each quarter is corrected on
  its own. Correcting the whole frame at once would treat four lenses as one and pull the
  views towards the middle of the picture.
- The correction keeps as much of the picture as possible: the whole fisheye circle stays,
  and only the four corners outside that circle are cut. It uses a different projection
  from the super mirror, whose straight-line correction cannot fit the whole circle at all.

## [1.1.0-alpha] - 2026-09-16

- **Malay interface.** Every screen is translated: Settings, the stream profile editor,
  playback, the super mirror, diagnostics, dialogs and notifications. Pick it in
  Settings -> System -> Language, or let it follow the head unit when that is set to
  Malay. Text sizes are the same as in English.

## [1.0.0] - 2026-09-15

First stable release. Download the `.apk` below and sideload it through App Lab.

A surround-view dash cam for the ZEEKR 7X head unit. App Lab gives third-party apps the four surround cameras as one stitched strip; this app splits it back into four views and records them.

### Main features

- **Dash cam**: records the surround view as a 2×2 grid, plus the front and rear cabin cameras if you turn them on. Recordings go to a USB drive in 1–10 minute clips.
- **Recording quality**: three presets (save space, balanced, sharpest), each showing GB per hour and how long your drive will last. Frame rate, bitrate, clip length and codec can be tuned per camera.
- **Main screen**: tap any view to fill the preview, tap again to go back. Photos use each camera's full resolution.
- **Super mirror**: a floating window showing one camera enlarged. Drag it, pinch to resize, swipe to change camera or framing, and dock it at the screen edge.
- **Playback**: continuous playback across clips, photo review, and sending a clip or photo to your phone by QR code over the local network.
- **Floating button**: shows recording state and opens the app from anywhere; tap and long-press actions are configurable.
- **Updates**: check for new versions in Settings, with or without beta releases.
- Chinese and English interface; action buttons on the driver's side.

## [0.62.0-alpha] - 2026-09-15

- The action column on the main screen is as wide in the surround + cabin layout as in the
  surround-only one (380dp, was 300dp). In English the record button and the two playback
  buttons did not fit. The surround and cabin views give up that width.

## [0.61.0-alpha] - 2026-09-15

- Fixed: saving a diagnostics report crashed the app, and it restarted a few seconds later.
  The "saved" message was shown from a background thread, which Android does not allow.
- Fixed: after the app restarted or the interface language changed, the surround preview
  could show the whole strip, unsplit and stretched. When the main screen reused cameras
  the super mirror had already opened, the step that passes the stream size to the surround
  view sat behind a check the surround camera also passes, so it never ran.
- Diagnostics and saved logs list the last few reasons the app process exited (crash,
  killed, low memory and so on) and the crash from the previous run, if any.

## [0.60.0-alpha] - 2026-09-15

- Tap-to-enlarge in the surround + cabin layout grows each view from where it actually is on
  screen: a surround view from its own cell, a cabin camera from its pane, and back the same
  way. The surround view used to grow from its position in the surround-only layout, and the
  cabin cameras had no transition. Start and end points are measured, so the transition
  keeps working when view placement changes.

## [0.59.0-alpha] - 2026-09-15

- New app icon: a car seen from above inside four arcs, one for each camera view. It has a
  monochrome layer for themed icons on Android 13 and later, and the camera service
  notification uses the same mark instead of the Android robot.
- Removed icon files nothing used: per-density launcher bitmaps (the adaptive icon always
  applies from Android 8, and the app needs 9), the template robot and an EVCam wordmark.

## [0.58.1-beta] - 2026-09-15

Changes since 0.36.1-beta:

- Fixed: updating from inside the app stopped at "Permission to install apps is required".
  The app asked Android first, and on the car the answer is no even though the installer
  opens. The download now goes straight to the system installer. Updating from 0.58.0 or
  earlier still needs this version installed by hand once.
- The "Surround" label on the main screen is at the top right of its pane; the menu key
  covered it. In the surround-only layout, a view label under the menu key moves aside.
- New look aligned with Zeekr OS: main screen, settings, playback and dialogs redesigned,
  larger text, action buttons on the driver's side.
- Stream profile editor in Settings -> Recording: choose a recording quality (save space,
  balanced, sharpest), tune each camera, and drag the surround views into place. Changes
  apply immediately.
- The surround + front and rear cabin profile is available to everyone. Cabin cameras
  support rotation, mirroring and fit, and start mirrored.
- Higher bitrates (medium is 10 Mbps on the surround grid). Photos use each camera's
  largest size.
- Main screen: tap a view to fill the preview, tap again to go back. The bottom-right button
  hides the app; long-press it to quit.
- One floating button, with its tap and long-press actions set by you and a position lock.
- The super mirror has a picture guide, shown the first time it is turned on.
- Update checks can include or skip beta releases.
- Stall watch: a report is saved when the super mirror or a recording stops receiving frames.
- English interface reviewed: outdated text corrected, terms made consistent, explanations
  shortened.
- Known issues: cropping a surround view is disabled. After switching the interface language
  or opening Diagnostics, the surround preview may show the whole unsplit strip until the
  app is restarted.

## [0.58.0-beta] - 2026-09-14

First beta since 0.36.1. Highlights since then:

- New look aligned with Zeekr OS: main screen, settings, playback and dialogs redesigned,
  larger text, action buttons on the driver's side.
- Stream profile editor in Settings -> Recording: choose a recording quality (save space,
  balanced, sharpest), tune each camera, and drag the surround views into place. Changes
  apply immediately.
- The surround + front and rear cabin profile is available to everyone. Cabin cameras
  support rotation, mirroring and fit, and start mirrored.
- Higher bitrates (medium is 10 Mbps on the surround grid). Photos use each camera's
  largest size.
- Main screen: tap a view to fill the preview, tap again to go back. The bottom-right button
  hides the app; long-press it to quit.
- One floating button, with its tap and long-press actions set by you and a position lock.
- The super mirror has a picture guide, shown the first time it is turned on.
- Update checks can include or skip beta releases.
- Stall watch: a report is saved when the super mirror or a recording stops receiving frames.
- English interface reviewed: outdated text corrected, terms made consistent, explanations
  shortened.
- Known issues: cropping a surround view is disabled. After opening Diagnostics, the
  surround preview may show one whole frame until the app is restarted.

## [0.57.0-alpha] - 2026-09-14

- Diagnostics only, no behaviour change. The main screen logs what the surround preview
  draws (four views or one whole frame) and why, its lifecycle, and every change to which
  camera is the composite stream. The diagnostics report times each section and logs how
  long the screen froze while it was generated.
- Stall reports now include the main, camera and encoder thread stacks. On the car the
  system thread list left them out.

## [0.56.0-alpha] - 2026-09-14

- Long-press the hide button on the main screen to quit the app.
- The front and rear cabin cameras start mirrored in both built-in stream setups, including
  when a cabin camera is switched on later in the surround-only setup. Setups already saved
  keep their settings; Reset applies the new default. Mirroring flips the on-screen preview
  only, not recordings or photos.

## [0.55.0-alpha] - 2026-09-14

- Stall watch. If the super mirror shows no new frame for 1.5 s, or a recording gets no
  camera frame for 3 s, the app saves a report: camera and session state, frame counts,
  lost buffers, encoder and file-write timings, segment-switch time, thread stacks and the
  recent log. Save logs and the diagnostics report include these reports. It only records;
  nothing is restarted or repaired.

## [0.54.0-alpha] - 2026-09-14

- Update checks have an "Include beta releases" switch, on by default. On, they offer beta
  and stable releases, as before; off, stable releases only. Alpha builds are never offered.
  Check for updates in Settings is its own section now, showing the installed version.
- Removed the OkHttp library. Nothing used it, but it was still built into the APK.

## [0.53.0-alpha] - 2026-09-14

- The super mirror has a picture guide: five pages covering the three gesture zones, changing
  camera, framing, docking to the edge and zooming. Swipe to turn pages; tap outside the
  picture or press back to close at any time. It opens once, the first time the mirror is
  turned on from the drawer or Settings, and again from Settings -> Super mirror -> How to use,
  which works even while the mirror is off. It does not open when the mirror is turned on
  from the floating button, since the app is usually not in front then.
- Chinese and English builds each have their own set of pictures.

## [0.52.0-alpha] - 2026-09-14

- The bottom-right button on the main screen hides the app instead of quitting it, with a
  new icon: the old cross looked like both "close this page" and "quit". Quit moved to the
  bottom of the drawer and the bottom of the settings list.
- The grid button is gone and Photo takes the whole row. Tap a surround lane to fill the
  preview area with it, tap again to go back; the cabin cameras work the same way. An
  expanded view always fills, cropping the edges.
- Fixed: "Reset floating button layout" did nothing. It cleared the settings of the old
  main-screen floating window, which the merged button never reads. It now resets the
  button's own position and size and moves it straight away, to where the original "open
  app" button used to sit.
- New defaults (only for settings you have never changed): floating button size 90,
  opacity 95, recording duration hidden; rear-view fisheye correction off; prevent sleep
  off. Record with screen off is locked unless developer options are on.

## [0.51.1-alpha] - 2026-09-14

- Removed the segment progress bar and "clip xx%" from the status bar on the main screen.
  While recording it jumped between the real value and 100%, and the record button's ring
  already shows the same progress.

## [0.51.0-alpha] - 2026-09-13

- Photos always use the camera's largest size. They no longer follow the resolution chosen
  above it -- a photo is one still frame, it costs no continuous bandwidth, so there is no
  reason to step it down. The surround camera stays at 1280x5140, as before. The detail box
  shows the size it works out to.
- Save space is 10 fps (was 15); balanced is 20 fps (was unlimited). A newly created profile
  starts on balanced, so it reads as one of the three steps instead of none.
- The storage line now reads "recording 3, 26.6 Mbps in total, about 12.0 GB an hour" and
  says plainly when no camera is on. The total bit rate makes it obvious that the line
  follows what you change; one decimal place of GB alone could look like nothing happened.
- The three quality notes describe frame rate and bit rate instead of what you can make out
  in the picture.

## [0.50.1-alpha] - 2026-09-13

- Fixed: the cabin cameras showed a landing size of 2560x400. Whether a stream is split
  depends only on the camera id, and the editor passed the surround camera's id whatever
  row it was drawing, so 1280x800 was cut into four lanes and reassembled 2x2. Their bit
  rate was computed from that wrong size too.
- Resolution is one setting now, applied to preview, recording and photos together. The
  profile still stores three, but choosing three times per camera only made it easy to end
  up with a profile that disagreed with itself. The list offers the sizes declared for both
  preview and photos -- a size declared for only one of them quietly falls back on the
  other side.
- Photo quality is fixed at 95 and the control is gone.

## [0.50.0-alpha] - 2026-09-13

- Adding a camera is gone. This car has three, so "add" was never a real event -- on and
  off is. All three cards are always there, dimmed when off. The surround-only profile
  starts with just the surround stream on; surround-plus-two starts with all three.
- Fixed: the two cabin cameras always read 0 kbps whatever the bit rate was set to, and the
  hours-left estimate did not change when they were switched on or off. Their "auto"
  resolution does have an answer -- photos take the largest declared size, the preview
  takes the declared size closest to 1280x800, and recording follows the preview -- so it
  is worked out rather than left blank.
- No Save button: a change takes effect when you make it. Reset, next to the quality
  heading, is the way back. The checks that used to appear when saving now sit under the
  storage estimate.
- The quality section is named "Recording quality", and photo quality became a row of
  choices -- it was printed but could not be changed.
- Fixed: the placement page opened blank. It is pushed over the editor, so it is not the
  editor's child and could not find the profile being edited.

## [0.49.0-alpha] - 2026-09-13

- The stream profile editor asks what you want before it asks for numbers. Pick one of
  three -- save space, balanced, sharpest -- and it sets frame rate and bit rate on every
  camera at once, with the cost written under each: gigabytes per hour, and how long the
  stick you have in the car will last. Each camera is a card; one that differs from the
  preset is marked. Open a card and its knobs appear in place as rows of segments. No
  dialogs.
- Lane placement is a stage you drag. Drag a cell to move it, drag a corner to resize it.
  It snaps to the edges, halves and quarters of the frame and to the other cells' edges,
  and draws the line it snapped to. Surround lanes only -- the cabin panes' position and
  size are not driven by the profile yet, and a control that changes nothing is worse than
  no control.
- Cropping a surround lane is still switched off; it rendered as snow and the cause is not
  found yet. The row says so instead of hiding.

## [0.48.0-alpha] - 2026-09-13

- The surround-plus-two-cabin stream profile is available to everyone. It was behind
  developer options as unfinished; rotation, mirroring and pane fill now work on the cabin
  cameras and have been checked on the vehicle. "Custom" stays a developer option -- it
  asks you to wire each camera by hand and exists for troubleshooting.

## [0.47.2-alpha] - 2026-09-13

- Fixed: "fit" left two sets of bars, so the long edge never reached the pane. The view was
  shrunk to the picture's shape before rotation, and the matrix then fitted the rotated
  picture inside that. The view now takes the shape the picture will have after rotating,
  which leaves one set of bars and puts the long edge against the pane.
- The transform is recomputed when the preview view is re-laid out, which it is right after
  its aspect ratio changes.

## [0.47.1-alpha] - 2026-09-13

- Fixed: adding only the rear cabin showed the front cabin's picture in it. Each cabin role
  is pinned to its own camera; the previous release filled the gap with the first spare
  camera instead, which is worse than leaving it empty because the pane and the label were
  both right. A cabin pane with no camera configured is hidden now, and the other one takes
  the column.
- Fixed: "fill" did not fill. The view itself is shrunk to the picture's shape before the
  matrix ever runs, so a quarter-turned picture could only ever fill that already-shrunk
  view. The pane's shape now follows the lane's choice, and the matrix is told the buffer's
  real shape so it can account for the stretch.
- The floating button keeps a dot in the middle when idle, in grey. An empty ring alone did
  not read as a button. Red still appears only while recording.

## [0.47.0-alpha] - 2026-09-13

- Fixed: rotation and mirroring on the cabin cameras (fourth attempt). Every attempt keyed
  the decision off the car model, which defaults to the single-stream Zeekr and only
  changes if someone picks the three-stream option by hand -- so the main screen took a
  different branch and wrote an identity matrix over the one built from the profile. The
  question is now "does the profile have a lane for this camera", and if it does, nothing
  but the camera writes its transform.
- Fixed: panes were labelled by direction, not by what they show. "front/back/left" name a
  lane of the surround strip in one place and a camera slot in another; the badges wanted
  the second and used the first, so the surround pane read "front", the front cabin read
  "back" and the rear cabin read "left". Photo review had the same labels hardcoded. Both
  now ask the same place, which answers with the camera's role.
- Fixed: whichever cabin camera you added, the picture appeared in the first cabin pane.
  The slot plan only knew the order of camera ids; it now follows the profile.
- Cabin 1 and Cabin 2 are the front cabin and the rear cabin. Cameras the app recognises
  carry those names; anything else -- the custom model's four, or a camera found later --
  is still yours to name.
- Each lane chooses how it fills its pane: fit (whole picture, bars at the sides) or fill
  (covers the pane, the excess cropped). A quarter-turned cabin camera shrinks to a strip
  under "fit", which is what it was doing with no way to say otherwise.
- Diagnostics reports each camera's lane and what the last attempt to apply it did.

## [0.46.2-alpha] - 2026-09-13

- Fixed, fourth attempt: rotation and mirroring on the cabin cameras. Every attempt so far
  keyed the decision off the car model, and that setting defaults to the single-stream
  Zeekr and only changes if someone picks the three-stream option by hand -- so the main
  screen took a different branch, and that branch wrote an identity matrix over the one
  built from the profile. The question is no longer "which car model is this" but "does
  the profile have a lane for this camera"; if it does, the camera owns its transform and
  nothing else writes one.
- Diagnostics reports each camera's lane and what the last attempt to apply it did. Three
  fixes in a row came back as "no effect" for three different reasons, each costing a
  release to find out. Now the report says which link is broken.

## [0.46.1-alpha] - 2026-09-13

- Reverted 0.45.2's clip change. Moving the lane's clip ahead of the transform was meant to
  cure the static that crop produced; it broke rotation instead -- every cell showed the
  whole strip. The clip is back where rotation is known to work.
- Crop is switched off. Three attempts to fix it by reading the code each broke something
  else, and the arithmetic checks out, so whatever is wrong is in how the renderer clips a
  TextureView inside a transformed canvas -- not visible in the source and only visible on
  the vehicle. Saved crop values are untouched; the drawing paths treat them as zero, and
  the editor says the row is unavailable and why. What is known, and the cheap experiments
  to try next, are written down in docs/profile-todo.md.

## [0.46.0-alpha] - 2026-09-13

- The floating button has the record button's ring: a track around the edge with the
  segment's progress running along it while recording. Idle it is a plain grey outline --
  the look of the open-the-app button it replaced, which is also what it does by default.
  Red is reserved for recording.
- The floating button's position can be locked. Parked where you want it, the next touch
  is usually an accident, and it sits on the picture. The lock only stops dragging; tap
  and long press still work.

## [0.45.2-alpha] - 2026-09-13

- Fixed: cropping a surround lane turned that pane into static. The mask added in 0.44.1
  clipped the lane inside the transformed coordinate space, which is a different path
  through the renderer; it only showed up once a crop made that clip stop coinciding with
  the cell. The clip now happens before the transform, on the rectangle the lane occupies
  on screen -- same masking, one coordinate space, plain axis-aligned rectangles.
- The floating button's size range moved up by half: 48-150dp instead of 32-100, and the
  default with it. It was too small on the vehicle even at the top of the old range.
- The main screen's menu key uses the same numbers as the one in every other title bar --
  48dp, 10dp in, 8dp down. It is measured from the picture's edge rather than the card's,
  because the card's top-left corner is where the action rail sits on left-hand drive.
- "Back to recording" in Settings no longer carries its own arrow; there is already one in
  the title bar above it.

## [0.45.1-alpha] - 2026-09-13

- Reverted 0.45's crop placement. Keeping the frame still while the crop filled it turned a
  lane into static on the vehicle; the cause is not understood yet, so the old behaviour is
  back -- the picture resizes and shifts as you crop, which is wrong but is a picture. The
  mask fix and the rotated-axis mapping stay.
- Fixed: rotation and mirroring still did nothing to the cabin cameras. Twice the transform
  was written from the main screen and twice it lost -- first overwritten, then apparently
  never reached the view. It is built inside SingleCamera now, at the same three points
  that used to overwrite it, which are the ones known to run.
- The main screen has no title bar. Its 64dp held a menu key, the app name and the profile
  name; the menu key now floats on the picture where it already was, the name sits at the
  top of the action rail, and the profile name joined the status bar, where "what is
  running right now" already lives. The picture is 64dp taller.
- The status bar spans the whole picture area instead of just the surround pane.
- Fixed: the floating button's size and text-size sliders did nothing. Settings started the
  service with an action the service only listened for as a broadcast.
- Fixed: changing opacity sometimes made the floating button vanish, and turning the
  recording time off closed the button entirely. Both were the same race -- two commands,
  hide and show, each on its own thread. Style changes are applied in place now.
- The floating button's background follows the main screen's record button: neutral when
  idle, a quiet red while recording, with red only ever on the dot.
- The drawer has a floating-button switch under the mirror, and no longer has a diagnostics
  entry. "Recording status readout" moved to Interface, where it belongs -- it is the chip
  on the picture, not part of the floating button.

## [0.45.0-alpha] - 2026-09-13

- One floating button instead of two. It shows whether recording is running -- red while
  it records, a hollow ring when idle -- and what a tap and a long press do is yours to
  set: open the app, start/stop recording, take a photo, or toggle the mirror. Both
  default to opening the app, because brushing a button should never stop a dashcam
  recording. Drag, size, opacity and the recording time beside it all stay; the time is a
  switch now. Anyone who had only the old open-the-app button keeps a button.

## [0.44.1-alpha] - 2026-09-13

- Fixed: rotating a lane made the neighbouring lanes appear beside it. A lane keeps its
  own shape inside its cell, so there is empty space at the sides -- and that space holds
  the pixels of the lanes above and below it on the same strip. Upright, the strip runs
  vertically and the side margins happen to be empty; rotate it a quarter turn and the
  strip runs across, filling them. Clipping to the cell never helped: the leak was already
  inside the cell. Each lane is now clipped to its own window in the strip, which no
  rotation can widen, and the margin is painted.
- Crop no longer moves the picture. The cell used to be re-fitted to whatever was left
  after cropping, so trimming the top made the whole lane shrink and shift -- which reads
  as crop being broken rather than as a trimmed bumper. The frame now stays where it was
  and the remainder fills it, the excess centre-cropped rather than stretched, the way the
  rear-view mirror fills its window. Trimming top and bottom therefore also trims a little
  from the sides.
- Fixed: rotation still did nothing to the cabin cameras. An inherited rule mirrors the
  "back" slot unconditionally and writes the matrix straight onto the view, which erased
  the one built from the profile -- and in the three-stream profile that slot is the first
  cabin camera. That rule now applies only where the profile does not drive the lane. The
  transform is also recomputed when the view is re-laid out, which it is right after the
  aspect ratio is set.
- The status bar sits on the picture again, along its bottom edge, on a soft dark gradient
  -- on the main screen and in video review, the two screens whose content is the picture.
  As its own row it cost them 48dp of height, and in video review it had pushed the
  transport controls down. Settings keeps it as a row: there it sits below text, not on a
  picture.
- Diagnostics reports what the encoders actually allow: the sizes and bitrate range each
  one declares, whether it will take the surround grid's size, and the profile/levels it
  advertises. The ceiling in the code was inherited, never checked against the hardware,
  and an encoder that disagrees does not complain -- it quietly lowers the quality.
- Removed the inherited fisheye correction: a second camera pipeline, about 1800 lines,
  behind a flag that nothing could ever set. It rendered the camera into an intermediate
  GL surface, which is the very thing that crashes on this head unit -- which is why the
  rear-view mirror's own correction was written the way it was, as a mesh over the existing
  view. That one stays and is the basis for anything we do with distortion later. The
  fullscreen preview keeps its zoom, centre and rotation sliders, which work; the two that
  fed the deleted shader are gone.

## [0.44.0-alpha] - 2026-09-13

- Bitrate has four tiers instead of three, and the whole table moved up: very low 2.7,
  low 5.4, medium 10, high 20 Mbps on the surround grid. Medium is the default and is
  double what it was. The old ceiling was 8 Mbps for a 6.6-megapixel frame -- 0.033 bits
  per pixel, about a seventh of what an ordinary dashcam spends on 1080p. The detail was
  being recorded and then compressed away, which is why the picture looked soft rather
  than small.
- One bitrate formula. There were two: the encoder's, and one computed next to it whose
  result was thrown away unless "force H.264" was on -- so that compatibility switch was
  quietly the sharpest setting in the app.
- Recording no longer declares HEVC Level 4, which tops out at 1920x1080. The surround
  grid is three times that, and an encoder that believes the declaration may hold its own
  rate control down to match.
- Fixed: re-preparing after a forced camera reopen built the recorder from the preview
  size with no four-up rearrangement and the frame rate hard-coded to 25. One reopen and
  the rest of the session recorded a preview-sized strip, with nothing in the log to say
  so. Both paths build the recorder the same way now.
- Fixed: crop cut the wrong edge on a rotated lane. Crop, zoom and pan were read in the
  source picture's axes while the user sets them looking at the rotated one, so after a
  quarter turn "crop 20% off the top" took it off the left -- which on the vehicle is
  indistinguishable from crop not working at all. The mapping is its own tested function
  now, shared by both drawing paths.
- Fixed: rotation and mirroring had no effect on the two cabin cameras. Their transform
  came from the old per-camera preview correction and nothing read their lane in the
  profile, so the editor showed 90 degrees while the picture never moved. Rotation,
  mirroring, crop, zoom and pan now all apply; position and size still wait for the main
  screen layout to come from the profile, and the editor says so.
- The confirm-before-save preview applies the same transform, so what it shows is what the
  main screen will show.

## [0.43.2-alpha] - 2026-09-13

- The last four places that set a text size in code now read the scale: the profile preview check's note, the update dialog's progress line, the lane map's labels and the phone-share page. Sizes still set in code are either burned into a frame or chosen by the user.
- Removed an unused layout left over from upstream, and added a test that fails on a plain Button or an android:backgroundTint in a core screen -- the shape of what sat unnoticed in the large-screen layout for four months.

## [0.43.1-alpha] - 2026-09-12

- Photo and video review keep their actions in the title bar after all. The action rail 0.43.0 moved them to costs 380dp on a screen whose content is the picture, and the title bar had the room. Both screens still share one layout for them.
- The first-launch guide was set in the page-title size, which read oversized and cramped; it is body text with proportional line spacing now. Its content is current too: the diagnostics report comes from the drawer, and the button side and the mirror's gestures each get a line.

## [0.43.0-alpha] - 2026-09-12

- Settings has a title bar again: the menu key sits where every other screen keeps it, and turns into back inside a sub-screen, whose name it shows. The status bar from the main screen runs along the bottom.
- Photo and video review moved their actions -- refresh, multi-select, home -- into an action rail on the right, and the selection actions with them. Both screens include the same rail, so they cannot drift apart. Transport controls stay under the video, where the picture they act on is.
- Video review shows the status bar too, so recording state and free space are visible while watching.
- The status bar itself is now one layout instead of a copy per main layout.
- The UI spec lives in the repo (docs/ui-spec.md): the five zones, which screens use which, every token value, and a table saying plainly what does not follow it yet.

## [0.42.1-alpha] - 2026-09-12

- Fixed: photo review's list was a sliver. The layout that survived yesterday's cleanup sized that list for a phone (200dp fixed); it now uses the same width as the settings and video-review lists.
- Photo review's text steps line up with the rest: lane badges match the ones on the main screen, and the empty-state hint is no longer larger than a page title with its own subtitle bigger still.

## [0.42.0-alpha] - 2026-09-12

- Fixed: photo review was still showing its pre-redesign toolbar on the vehicle. The head unit picks the large-screen copy of that layout, and only the base copy had been redesigned — so the vector icons and rounded tiles landed in 0.38.0 for everyone except the car. Those stale copies are gone; there is one layout now.
- Fixed: the stale copy also carried hardcoded Chinese, which the test missed because it only scanned the base layout folder. It scans every variant now.
- About rewritten: thanks first, then what the app is built on, where the source is, what happens to your recordings and the three times the app goes online, storage advice, and the safety notice.

## [0.41.1-alpha] - 2026-09-12

- Settings text is back to its previous size. The section is a dense list read while parked, so it sits one step below the rest of the scale; every other screen keeps 0.41.0's sizes.
- Fixed: video review, About and Diagnostics ignored the language setting and stayed in the system language. The app's language reaches AppCompat activities only, and those three were plain ones. About and Diagnostics also still carried the system theme, so their colours now match as well.

## [0.41.0-alpha] - 2026-09-12

- Text and icons are a size up: the scale moves 12/13/15/18/22/24 -> 14/16/18/21/26/28 and icons follow, after comparing against the head unit's own settings screens.
- Switches: white thumb, orange track when on. Material's own switch tints the thumb and washes the track, which is where the pale orange came from.
- Fixed: dialogs looked reddish. Material 3 tints elevated surfaces with the primary colour, and ours is Zeekr orange.
- Fixed: switching day/night dropped you back to the main screen and made the playback screens rescan. The screen you had open comes back, and clip durations are remembered, so there is nothing to rescan.
- Video review has the same controls as photo review: the menu button where the main screen keeps it, plus refresh, multi-select and home. Multi-select deletes several recordings at once.
- Developer options: the photo-channel test and the preview resource sampler are gone. Each was built to answer one question about a feature that has since shipped, and both questions are answered.

## [0.40.0-alpha] - 2026-09-12

- Text sizes come from one named scale of six steps. Core screens had eight sizes, three pairs of them one sp apart. Page titles are now larger than the section headings inside the page; they used to be the same size.
- Settings -> Interface -> Button side is a row with both choices on it: one tap to switch, and you can see what the other option is without opening anything.
- Settings lists deal their rows in when a section opens, and the status bar rolls a number over instead of swapping it. Both are decorative, so both stop while recording and when the system has animations turned off.
- The floating record button and the preview window's button follow the palette: neutral ground, red only on the dot that marks recording. They were iOS red/green and blinking green, neither of which is in the palette, and both of which said "red means button" instead of "red means recording".

## [0.39.1-alpha] - 2026-09-12

- Fixed: settings dialogs had no confirm button (video and photo limits, licence plate, button side, and the first-launch driver-side question). They were framework dialogs, whose button bar this head unit does not draw. Every dialog is now a Material dialog - what the dialogs that always worked (camera mapping, device name) were already using. A test keeps it that way.
- Dropdown settings (video stream profile, storage location, button side) now ask for confirmation. They used to apply the moment you touched an entry, with no way back.
- Fixed: dialog buttons were clipped along the top, so only their bottom corners looked rounded.
- Text inputs in dialogs share one style (licence plate, storage limits, device name, problem description). They were two different-looking boxes. Filled buttons all use the same orange.

## [0.39.0-alpha] - 2026-09-12

- First launch asks which side the driver sits on and puts the action rail on that side. Existing installs are asked once.
- Settings -> Interface: button side, and "Reduce motion while recording" (on by default).
- Record button is disabled when there is nowhere to record (no USB drive). The status bar shows the fps cap, bitrate tier and free space.
- Settings rows redesigned: section icons, values on the right, switches, chevrons.
- Stream profile editor in two panes (streams / lanes) with a lane map.
- Drawer regrouped; the rear-view switch toggles in place.
- Dialogs share one style; destructive buttons are red.
- About, Diagnostics and Timeline use the shared title bar. Fixed white-on-light text in day mode.
- Four-up: the tapped lane grows out of its cell.
- English UI: playback, notifications, diagnostics, image adjustment, the profile editor's save checks, update errors and the developer section no longer show Chinese. A test blocks new hardcoded text.
- Removed unused layouts and code.

## [0.38.0-alpha] - 2026-09-11

- New look aligned with Zeekr OS: warm greys, Zeekr orange accent, flat cards. Day and night follow the system.
- Main screen rebuilt on one skeleton: title bar (menu top-left), preview, action rail, status bar.
- Record button: red only on the dot and the clip ring. The dot morphs circle to square; the ring fills per clip.
- Status bar shows clip progress; the recording chip shows elapsed time and clip number.
- Vector icons replace the text glyphs.
- Settings -> System -> Button side: action rail on the left or right.
- Transitions: settings sections move along the list, sub-pages and full screens zoom in.
- Fixed: in the surround + cabin layout, single view hid the cabin labels and lane placement could move them.
- One theme for day and night (the night copy had drifted); a test keeps the two colour sets in step.

## [0.37.13-alpha] - 2026-09-05

- Fixed: the four lane labels stayed pinned to the corners of the screen when a lane was
  moved or resized, so a label could sit on someone else's picture. Each label now follows
  its own lane.
- Fixed: opening the editor before the cameras had started described the surround-view
  stream as not split, which hid the per-lane controls. Whether a stream splits is a
  property of the camera, not of whether it happens to be open.

## [0.37.12-alpha] - 2026-09-05

- The stream profile editor has moved out of developer options into Settings -> Recording,
  and is built like the rest of Settings. So has "Photos through the image channel", which
  is what makes the photo resolution mean anything.
- Fixed: rotation, mirroring, position, size, crop and pan were stored per lane and read by
  nobody. The four-up view drew a hard-coded 2x2 and ignored all of it, so changing them in
  the editor did nothing. They now draw what they say.
- Each lane of a split stream is edited on its own - front, rear, left and right each have
  their own placement, rotation, mirroring, crop and pan. They were one setting for the
  whole camera, which cannot express "mirror the rear view only".
- "auto" and "max" now print the size they resolve to, everywhere a resolution is shown or
  chosen, next to what a split stream lands as on disk.
- Removed the recording layout choice. A stream that splits is always stored as the 2x2
  grid; the strip loses half the detail and playback zoom assumes the grid anyway.

## [0.37.11-alpha] - 2026-09-05

- Camera and stream parameters now live in one place. Frame rate, bitrate, codec, segment
  length, which cameras record and the recording layout each had a setting of their own
  while the profile editor showed its own copy of the same thing. Recording now reads the
  profile, per camera, and those settings are gone from Settings.
- Fixed: frame rate, bitrate, segment length and codec in the profile editor had no effect
  at all. Recording still read the old global settings, so the editor showed one value and
  the camera used another.
- Removed "Low-resolution preview". Each camera's preview size is set in the profile, and
  that switch could silently shrink it below what the editor showed.
- A camera that is enabled in the profile is the camera that records. Choosing them
  separately allowed a camera that was open, and holding a stream, for nothing.
- Fixed: "auto" for recording copied the preview size, so setting the preview to 640x480
  recorded 1280x240. The surround-view stream's "auto" is now the size that keeps the most
  detail per lane, whatever the preview is set to.
- Fixed: photo resolution had no effect unless a developer option was on. Photos now go
  through the camera's JPEG channel by default; if the session cannot take that extra
  stream, it is the first thing dropped, so the picture is never lost for a photo.
- Fixed: "max" as a preview resolution resolved to nothing and fell back to the old rule.
- The profile editor prints what a size lands as: the per-lane size, and the size the file
  will actually be after the four lanes are rearranged into the 2x2 grid.

## [0.37.10-alpha] - 2026-09-05

- Fixed: the four camera labels on the main screen stayed Chinese in an English interface.
  They were written into the code instead of the string table, as were the names in the
  recording-camera setting, the fullscreen preview, the profile editor and the playback zoom.
- The recording resolution setting still pointed at a developer option removed in 0.37.9.
- Fixed: with three cameras, a photo group showed only two of them until you refreshed and
  then switched to another photo and back. A refresh rebuilt the list, but the preview still
  held the photo group from the previous scan.
- Photos now reach the drive as soon as they are taken. Each camera slept its own camera
  thread for up to two seconds after decoding the picture, so the third photo landed 2.6
  seconds after the shutter - late enough for the photo screen to miss it, and long enough
  to hold up that camera's session callbacks.

## [0.37.9-alpha] - 2026-09-05

- Removed the developer-only surround-view stream size. Every resolution now lives in the
  profile editor, and having a second place to set the same thing could only disagree.
- Fixed: a surround-view photo on "max" came out 7680x1080. Max picked the size with the
  most pixels, but on this camera every size holds the same four views, so 3840x2160 stores
  each square view squashed to 3840x540. Max now picks by how much detail a lane actually
  keeps, which is 1280x5140.
- The editor shows what "auto" and "max" resolve to, instead of leaving it to be guessed.
- Release descriptions are generated in English. The heading and the install line were
  still Chinese while everything around them had been translated.

## [0.37.8-alpha] - 2026-09-05

- Photos now carry EXIF again: capture time, make and model, size, the app version, and
  which camera took them. Stamping the badge means decoding and re-encoding the camera's
  JPEG, which discards whatever the camera wrote, so it is written back.
- The frame-rate options in the profile editor use the same wording as the setting: a plain
  number, without "up to".
- Clearing photo test samples also clears the folder used before 0.36.8, which the button
  could not reach.

## [0.37.7-alpha] - 2026-09-05

- Restored the changelog entries for 0.37.0 through 0.37.6. They were written
  against an anchor that had stopped matching, so seven releases went out with an
  empty description.

## [0.37.6-alpha] - 2026-09-05

- Fixed: cabin photos were rearranged into the four-up grid. The composer assumed every
  picture came from the surround-view camera; it is now told which camera took it.
- Fixed: cameras added to a profile had nowhere to appear. The screen layout and the camera
  limit were still chosen from the stored car model rather than the profile.
- Fixed: surround-view photos came out 1080x1080 whatever the settings said. The composer
  assumed the four lanes were square, which they are only at 1280x5140.
- The photo row in the editor says when the image channel is off, because the photo
  resolution has no effect in that case.

## [0.37.5-alpha] - 2026-09-05

- Splitting is now decided by the camera alone. The surround-view stream carries the same
  four-lane content at every resolution - confirmed at 1280x5140, 3840x2160 and 1600x900 -
  so resolution only changes sharpness, never the arrangement.
- Fixed: the profile editor reported "not split" for any size outside the old table while
  the preview split it anyway.

## [0.37.4-alpha] - 2026-09-05

- Fixed: recording and photo resolution had no effect, and changing the preview resolution
  moved all three. Only the preview stream was wired to the profile.
- The save check no longer opens a dialog just to say the check passed.
- Replaced the measured frame rate, which was always zero because the main screen is paused
  while the editor is open, with a real preview of the new configuration.
- The editor can add and remove cameras, and set frame rate, bitrate, segment length,
  rotation and mirroring.

## [0.37.3-alpha] - 2026-09-05

- Developer options -> Edit profile: cameras and their three streams, each stream showing
  its own parameters and whether it will be split into the four-up grid.
- Saving is checked first, then confirmed against a live preview with a countdown that
  expires. A configuration that leaves you without a picture cannot be cancelled by hand,
  so the default is to discard.
- Switching the stream configuration now switches profile.

## [0.37.2-alpha] - 2026-09-05

- Which camera setup runs is decided by the profile, not by the stored car model.
- Each camera's preview size comes from its profile entry.

## [0.37.1-alpha] - 2026-09-05

- Fixed: Current profile kept showing the first translation, so switching the stream
  configuration appeared to do nothing.
- The custom stream configuration is no longer labelled as the ZEEKR 7X preset.

## [0.37.0-alpha] - 2026-09-05

Groundwork for making camera and stream settings a profile you can edit and save.

- Camera and stream parameters now have a data model: which cameras are used, what each of
  the three streams (preview, recording, photo) is set to, and where each pane sits.
- Existing settings are translated into a default profile, viewable under developer options.
- Removed an ImageReader field that was declared and closed but never given a surface or
  attached to a session. Photos never went through it.

## [0.36.10-alpha] - 2026-09-04

- Developer options: added a preview resource sampler. It records per-camera frame counts
  and how many cameras are open once a second, tagged with which screen was on top, and
  reports it grouped by screen — so whether the preview stream keeps running in the
  background can be measured rather than timed by hand.

## [0.36.9-alpha] - 2026-09-04

- Photos can now be taken through the camera's own JPEG channel at each camera's largest
  size, instead of grabbing the preview. Off by default, under developer options, because
  it keeps an extra output stream open per camera.
- Fixed: the plate number was stamped but clipped off the badge, which is a fixed-width
  strip. The badge is now sized from the text.
- Fixed: settings dialogs with buttons (plate number, storage limits, recording cameras)
  showed no visible Save button. They are now built the same way as every other dialog in
  the app instead of relying on a theme attribute.
- The night-mode theme was a full rewrite of the day theme and had drifted; it now carries
  the same dialog and preference attributes.
- Photo test samples go next to the photos on the USB drive, and can be cleared from the
  test screen.
- Removed the send-to-phone connectivity test. The feature works on the vehicle; the
  diagnostics report still lists the local addresses.

## [0.36.8-alpha] - 2026-09-04

- Developer options: added a photo capture test. It takes a real JPEG from every camera at
  every declared size and reports what came back and which EXIF tags it carries.
- Removed the camera capability list and the resolution test. Every declared size runs at
  about 30 fps, so both tools have answered their question; the diagnostics report still
  lists what each camera declares.
- Removed the per-lane crop inset. It had a setter and nothing that ever called it.

## [0.36.7-alpha] - 2026-09-03

- The split table now lists camera and size together, and only the two combinations
  confirmed on the vehicle: the composite camera at 1280×5140 and at 3840×2160.
  Two sizes this head unit never declares were removed.
- Combinations outside the table are never split. Aspect ratio is used only to identify
  which camera is the composite one, never to decide how to split a frame.
- No frame is split until the composite camera has been identified.
- Fixed: the 2×2 grid size assumed square lanes. At 3840×2160 a lane is 3840×540,
  so the grid is now sized from the lane's real width and height.

## [0.36.6-alpha] - 2026-09-03

- Splitting the surround-view stream is now decided by one thing only: which camera the
  frame came from and what size it is. 3840×2160 is split into four equal lanes on the
  composite camera and left whole on the cabin cameras, which declare the same size.
- The lane order is the same at every size: front, rear, left, right.

## [0.36.5-alpha] - 2026-09-03

- Unlocking developer options now asks for the password on the first tap instead of
  after twenty.
- Every remaining dialog passes an explicit theme, so none of them can end up with
  invisible buttons — the settings dialogs were fixed in 0.36.4, this covers the rest.

## [0.36.4-alpha] - 2026-09-03

- A forced surround-view stream size is now split into the 2×2 grid like the native one.
  3840×2160 carries the same four lanes as 1280×5140, but 16:9 never passed the strip test.
- Fixed: settings dialogs (plate number, dropdowns) had invisible OK and Cancel buttons.
- Removed the "stream probe result" row from Settings; Developer options → Camera
  capabilities covers the same ground properly.
- Camera detection still goes by aspect ratio alone, so a declared size cannot make a
  cabin camera look like the composite one.

## [0.36.2-alpha] - 2026-09-03

- Added an optional plate number, stamped into recordings and photos next to the app name.
  Up to 10 characters, uppercase letters and digits.
- Photo watermarks now carry the same information as video: app name, version, plate,
  date and time, and size.
- Fixed: the bitrate summary disappeared after changing the setting.
- The target bitrate is now computed from the size actually being encoded.
- Frame rate: the native option shows the rate the stream declares.
- Recording resolution is greyed out in the composite configuration, where it has no effect.

## [0.36.1-beta] - 2026-09-03

- Fixed: "native frame rate" passed 0 to the encoder and the camera, forcing the lowest
  bitrate and the slowest exposure range.
- The hardware frame-rate ceiling now comes from the camera instead of a hard-coded 25.
- The video watermark drops the target bitrate and keeps the measured one.
- Fixed: the surround-view stream size shown on screen was the probe result, not the size
  actually in use.
- Download and share failures are now visible instead of a toast that flashes past.

## [0.36.0-beta] - 2026-09-03

- "Native frame rate" now means no limit at all; the other options are a ceiling, not a target.
- Fixed: video playback was hidden behind the status bar.
- Developer options: the surround-view stream size can be overridden.

## [0.35.0-alpha] - 2026-09-03

- Fixed the real cause of low frame rates: our own throttle halved them whenever the camera's
  frame interval was not a multiple of the target.

## [0.34.0-alpha] - 2026-09-03

- Fixed: the resolution test counted no frames.
- The resolution test now measures frame rate as well.

## [0.33.0-alpha] - 2026-09-03

- Fixed: the measured frame rate was never actually computed.
- Fixed: the rate shown for the native option was a constant unrelated to the camera.
- Developer options: added a resolution test that opens each declared size for real.

## [0.32.1-alpha] - 2026-09-03

- Camera capabilities now measure the rate the camera delivers, with a glossary for each field.

## [0.32.0-alpha] - 2026-09-03

- Developer options: added a camera capability list.

## [0.31.3-alpha] - 2026-09-03

- Fixed: the share test screen had no way out.
- Fixed: the watermark showed the configured frame rate, not the recorded one.
- The share dialog explains the same-network requirement and which segment is sent.

## [0.31.2-alpha] - 2026-09-02

- Local network addresses and port availability are included in the diagnostics report.

## [0.31.1-alpha] - 2026-09-02

- Send to phone is available from photo and video playback.

## [0.31.0-alpha] - 2026-09-02

- Groundwork for send to phone, with a connectivity test screen in developer options.

## [0.30.0-beta] - 2026-09-02

- Update checks consider beta and stable releases only.
- Fixed: the rear-view mirror window size was never saved after a pinch.

## [0.29.1-alpha] - 2026-09-02

- Fixed: the mirror stayed blurry after the window was resized.

## [0.29.0-alpha] - 2026-09-02

- Fixed: "do not record without a USB drive" only covered one of nine entry points.
- English UI for everything outside Settings.

## [0.28.0-alpha] - 2026-09-02

- The first-launch guide now describes this app, in both languages.

## [0.27.0-alpha] - 2026-09-02

- English UI for Settings, with a language option (system / Chinese / English).

## [0.26.1-alpha] - 2026-09-02

- Check for updates moved to the top level of Settings.

## [0.26.0-alpha] - 2026-09-02

- Check for updates now reads this repository's releases, downloads the APK and opens the
  installer directly.

## [0.25.2-alpha] - 2026-09-02

- Restored the custom layout and preview-correction entry points lost in the settings rebuild.

## [0.25.1-alpha] - 2026-09-02

- Fixed: developer options did nothing when tapped, and appeared only after leaving Settings.

## [0.25.0-alpha] - 2026-09-02

- Fixed: going back from a settings sub-screen jumped all the way to the recording screen.

## [0.24.0-alpha] - 2026-09-02

- Fixed: cameras could fail to open at all in custom mode.

## [0.23.0-alpha] - 2026-09-02

- Fixed: the rear-view mirror switch could turn on without the window appearing.

## [0.22.0-alpha] - 2026-09-02

- Camera setup consolidated into a single path. No behaviour change.

## [0.21.1-alpha] - 2026-09-01

- Recording decisions moved out of the main screen. No behaviour change.

## [0.21.0-alpha] - 2026-09-01

- Settings rebuilt as two panes: sections on the left, content on the right.

## [0.20.0-alpha] - 2026-09-01

- Recording to internal storage is now developer-only; a USB drive is required otherwise.

## [0.19.2-alpha] - 2026-09-01

- Fixed: the rear-view mirror did not reappear after restarting the app.

## [0.19.1-alpha] - 2026-08-30

- Fixed: the low / medium / high bitrate setting never took effect.

## [0.19.0-alpha] - 2026-08-30

- Fixed: field of view did nothing while fisheye correction was off.
- Video watermark: live bitrate, plus the app name and version in the top-left corner.

## Earlier versions

0.1.0 through 0.18.0 built the app up from the EVCam fork: splitting the ZEEKR composite
stream into a 2×2 grid, the rear-view mirror window, recording and playback, storage handling,
and the move to a preference-based settings screen. Those releases are no longer published.
